#!/usr/bin/env python3

import os
import re
import shutil
import sqlite3
from datetime import datetime

DB_PATH = "/u01/Medical/instance/medical.db"

# ============================================================
# CHANGE ONLY THIS
# ============================================================
CLAIM_ID = 31
# ============================================================


def backup_database():
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = (
        f"{DB_PATH}.before_claim_{CLAIM_ID}_delete_{timestamp}"
    )

    shutil.copy2(DB_PATH, backup_path)

    print(f"[BACKUP] {backup_path}")
    return backup_path


def quote_identifier(value):
    """Safely quote a SQLite table/column identifier."""
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", value):
        raise ValueError(f"Unsafe SQLite identifier: {value}")
    return f'"{value}"'


def get_tables(conn):
    rows = conn.execute("""
        SELECT name
        FROM sqlite_master
        WHERE type = 'table'
          AND name NOT LIKE 'sqlite_%'
    """).fetchall()

    return [row[0] for row in rows]


def get_columns(conn, table):
    table_q = quote_identifier(table)

    rows = conn.execute(
        f"PRAGMA table_info({table_q})"
    ).fetchall()

    return [
        {
            "name": row[1],
            "type": row[2],
            "pk": row[5],
        }
        for row in rows
    ]


def find_claim_table(conn):
    tables = get_tables(conn)

    # Prefer the normal claim table names.
    preferred = [
        "claim",
        "claims",
        "medical_claim",
        "medical_claims",
    ]

    for table in preferred:
        if table not in tables:
            continue

        columns = get_columns(conn, table)
        names = {c["name"] for c in columns}

        if "id" in names or "claim_id" in names:
            return table

    # Fallback: look for a table with a primary key named id
    # and a claim-like name.
    for table in tables:
        if "claim" not in table.lower():
            continue

        columns = get_columns(conn, table)
        names = {c["name"] for c in columns}

        if "id" in names or "claim_id" in names:
            return table

    raise RuntimeError(
        "Could not automatically locate the claim table."
    )


def get_primary_key(conn, table):
    columns = get_columns(conn, table)

    for column in columns:
        if column["pk"] == 1:
            return column["name"]

    for candidate in ["id", "claim_id"]:
        if any(c["name"] == candidate for c in columns):
            return candidate

    raise RuntimeError(
        f"Could not determine primary key for table '{table}'."
    )


def find_claim_id_columns(conn, claim_table):
    """
    Discover columns in other tables that reference claims.

    Uses both SQLite foreign-key metadata and conventional
    claim_id column naming.
    """

    references = []

    for table in get_tables(conn):

        if table == claim_table:
            continue

        columns = get_columns(conn, table)
        column_names = {c["name"] for c in columns}

        # ----------------------------------------------------
        # Explicit SQLite FK definitions
        # ----------------------------------------------------

        table_q = quote_identifier(table)

        fk_rows = conn.execute(
            f"PRAGMA foreign_key_list({table_q})"
        ).fetchall()

        for fk in fk_rows:
            # SQLite:
            # id, seq, table, from, to, on_update, on_delete, match
            referenced_table = fk[2]
            from_column = fk[3]
            to_column = fk[4]

            if referenced_table == claim_table:
                references.append(
                    (
                        table,
                        from_column,
                        "foreign-key"
                    )
                )

        # ----------------------------------------------------
        # Conventional claim_id columns
        # ----------------------------------------------------

        for column in column_names:

            normalized = column.lower()

            if normalized in {
                "claim_id",
                "medical_claim_id",
            }:
                already = any(
                    r[0] == table and r[1] == column
                    for r in references
                )

                if not already:
                    references.append(
                        (
                            table,
                            column,
                            "claim_id"
                        )
                    )

    return references


def count_rows(conn, table, column, claim_id):
    table_q = quote_identifier(table)
    column_q = quote_identifier(column)

    return conn.execute(
        f"""
        SELECT COUNT(*)
        FROM {table_q}
        WHERE {column_q} = ?
        """,
        (claim_id,)
    ).fetchone()[0]


def main():

    if not os.path.isfile(DB_PATH):
        raise FileNotFoundError(
            f"Database not found: {DB_PATH}"
        )

    print("=" * 72)
    print("DELETE ONE MEDICAL CLAIM AND ITS RECEIPTS")
    print("=" * 72)
    print()
    print(f"Database : {DB_PATH}")
    print(f"Claim ID : {CLAIM_ID}")
    print()

    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")

    try:

        # ----------------------------------------------------
        # Locate claim table
        # ----------------------------------------------------

        claim_table = find_claim_table(conn)
        claim_pk = get_primary_key(conn, claim_table)

        print(
            f"[CLAIM TABLE] {claim_table}.{claim_pk}"
        )

        # ----------------------------------------------------
        # Verify claim exists
        # ----------------------------------------------------

        claim_table_q = quote_identifier(claim_table)
        claim_pk_q = quote_identifier(claim_pk)

        claim = conn.execute(
            f"""
            SELECT *
            FROM {claim_table_q}
            WHERE {claim_pk_q} = ?
            LIMIT 1
            """,
            (CLAIM_ID,)
        ).fetchone()

        if claim is None:
            print()
            print(
                f"[NOT FOUND] Claim #{CLAIM_ID} does not exist."
            )
            return

        print(
            f"[FOUND] Claim #{CLAIM_ID}"
        )
        print()

        # ----------------------------------------------------
        # Find all dependent records
        # ----------------------------------------------------

        references = find_claim_id_columns(
            conn,
            claim_table
        )

        print("[RELATED RECORDS]")

        total_related = 0

        for table, column, method in references:

            count = count_rows(
                conn,
                table,
                column,
                CLAIM_ID
            )

            if count:
                print(
                    f"  {table}.{column}: "
                    f"{count} record(s)"
                )

                total_related += count

        if total_related == 0:
            print("  No related child records found.")

        print()

        # ----------------------------------------------------
        # Confirmation
        # ----------------------------------------------------

        print("WARNING:")
        print(
            f"This will permanently delete CLAIM #{CLAIM_ID}"
        )
        print(
            "and all database records directly associated "
            "with this claim."
        )
        print()

        confirmation = input(
            f"Type DELETE CLAIM {CLAIM_ID} to continue: "
        ).strip()

        if confirmation != f"DELETE CLAIM {CLAIM_ID}":
            print()
            print("[CANCELLED] Nothing was deleted.")
            return

        print()
        print("[DELETING]")

        # ----------------------------------------------------
        # Delete child records first
        # ----------------------------------------------------

        deleted_total = 0

        # Delete deepest dependencies first where possible.
        #
        # Tables containing receipts/files are intentionally
        # included because they normally have claim_id.

        for table, column, method in references:

            table_q = quote_identifier(table)
            column_q = quote_identifier(column)

            cursor = conn.execute(
                f"""
                DELETE FROM {table_q}
                WHERE {column_q} = ?
                """,
                (CLAIM_ID,)
            )

            deleted = cursor.rowcount

            if deleted:
                print(
                    f"  [DELETED] {deleted} row(s) "
                    f"from {table}"
                )

            deleted_total += max(deleted, 0)

        # ----------------------------------------------------
        # Delete the claim itself
        # ----------------------------------------------------

        cursor = conn.execute(
            f"""
            DELETE FROM {claim_table_q}
            WHERE {claim_pk_q} = ?
            """,
            (CLAIM_ID,)
        )

        if cursor.rowcount != 1:
            raise RuntimeError(
                "Claim deletion did not affect exactly one claim."
            )

        print(
            f"  [DELETED] Claim #{CLAIM_ID}"
        )

        # ----------------------------------------------------
        # Commit everything
        # ----------------------------------------------------

        conn.commit()

        # ----------------------------------------------------
        # Verify
        # ----------------------------------------------------

        remaining = conn.execute(
            f"""
            SELECT COUNT(*)
            FROM {claim_table_q}
            WHERE {claim_pk_q} = ?
            """,
            (CLAIM_ID,)
        ).fetchone()[0]

        print()
        print("=" * 72)

        if remaining == 0:
            print("SUCCESS")
            print("=" * 72)
            print(
                f"Claim #{CLAIM_ID} has been deleted."
            )
            print(
                f"Related database records deleted: "
                f"{deleted_total}"
            )
            print()
            print(
                "A database backup was created before deletion."
            )
        else:
            print("WARNING")
            print("=" * 72)
            print(
                f"Claim #{CLAIM_ID} still exists."
            )

    except Exception:

        conn.rollback()

        print()
        print("=" * 72)
        print("ERROR")
        print("=" * 72)
        print(
            "Transaction rolled back. "
            "No partial deletion was committed."
        )

        raise

    finally:
        conn.close()


if __name__ == "__main__":
    main()