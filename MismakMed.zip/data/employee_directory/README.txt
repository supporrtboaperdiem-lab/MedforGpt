Authoritative employee directory supplied for the Medical Reimbursement system.

File: bo_ldap_users.xlsx
Source: Bank of Abyssinia LDAP/employee directory export supplied by the system administrator.

The application can bootstrap the Employee table from this file when the Employee table is empty.
Administrators can also use Employee Directory -> Import Employee Directory to refresh the directory.
