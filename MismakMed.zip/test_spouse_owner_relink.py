"""Regression tests for spouse-first beneficiary ownership resolution."""
from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import patch

from app.services.spouse_directory_service import SpouseDirectoryService


class SpouseOwnerRelinkTests(TestCase):
    def test_spouse_claim_relinks_to_employee_attached_to_matched_spouse(self):
        wrong_employee = SimpleNamespace(id=202, full_name="Wrong Employee")
        spouse_owner = SimpleNamespace(id=101, full_name="Mesfin Negash Bereded")
        spouse_row = SimpleNamespace(
            employee_number="00025",
            employee_name="Mesfin Negash Bereded",
            spouse_name="Senait Asresahegn Engdasew",
            is_active=True,
        )
        item = SimpleNamespace(employee_id=202)
        claim = SimpleNamespace(
            id=1,
            patient_name="Senait Asresahegn Engdasew",
            beneficiary_name="Senait Asresahegn Engdasew",
            beneficiary_type="SPOUSE",
            coverage_percentage=90,
            employee=wrong_employee,
            employee_id=202,
            employee_owner_name="Wrong Employee",
            receipts=[],
            items=[item],
            status="APPROVED",
        )

        with patch.object(SpouseDirectoryService, "_resolve_employee_for_spouse", return_value=spouse_owner):
            changed = SpouseDirectoryService.classify_claim_as_spouse(claim, [spouse_row])

        self.assertTrue(changed)
        self.assertEqual(claim.employee_id, spouse_owner.id)
        self.assertIs(claim.employee, spouse_owner)
        self.assertEqual(claim.employee_owner_name, spouse_owner.full_name)
        self.assertEqual(item.employee_id, spouse_owner.id)
        self.assertEqual(claim.beneficiary_type, "SPOUSE")

    def test_regular_employee_claim_is_not_reclassified(self):
        employee = SimpleNamespace(id=202, full_name="Other Employee Name")
        spouse_row = SimpleNamespace(
            employee_number="00025",
            employee_name="Mesfin Negash Bereded",
            spouse_name="Senait Asresahegn Engdasew",
            is_active=True,
        )
        claim = SimpleNamespace(
            id=2,
            patient_name="Other Employee Name",
            beneficiary_name="Other Employee Name",
            beneficiary_type="EMPLOYEE",
            coverage_percentage=100,
            employee=employee,
            employee_id=employee.id,
            employee_owner_name=employee.full_name,
            receipts=[],
            items=[],
            status="PENDING_REVIEW",
        )

        changed = SpouseDirectoryService.classify_claim_as_spouse(claim, [spouse_row])

        self.assertFalse(changed)
        self.assertEqual(claim.employee_id, employee.id)
        self.assertEqual(claim.beneficiary_type, "EMPLOYEE")

    def test_duplicate_spouse_name_for_different_owners_is_held_for_review(self):
        wrong_employee = SimpleNamespace(id=202, full_name="Wrong Employee")
        row_one = SimpleNamespace(
            employee_number="00025", employee_name="Mesfin Negash Bereded",
            spouse_name="Senait Asresahegn Engdasew", is_active=True,
        )
        row_two = SimpleNamespace(
            employee_number="00030", employee_name="Serbela Ali Mustfa",
            spouse_name="Senait Asresahegn Engdasew", is_active=True,
        )
        claim = SimpleNamespace(
            id=3,
            patient_name="Senait Asresahegn Engdasew",
            beneficiary_name="Senait Asresahegn Engdasew",
            beneficiary_type="SPOUSE",
            coverage_percentage=90,
            employee=wrong_employee,
            employee_id=wrong_employee.id,
            employee_owner_name=wrong_employee.full_name,
            receipts=[],
            items=[SimpleNamespace(employee_id=wrong_employee.id)],
            status="APPROVED",
        )

        changed = SpouseDirectoryService.classify_claim_as_spouse(claim, [row_one, row_two])

        self.assertTrue(changed)
        self.assertEqual(claim.status, "PENDING_REVIEW")
        self.assertIsNone(claim.employee_id)
        self.assertIsNone(claim.employee_owner_name)
        self.assertIsNone(claim.items[0].employee_id)
