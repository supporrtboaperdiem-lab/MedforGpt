
from sqlalchemy import inspect, text
from sqlalchemy.exc import SQLAlchemyError
from app import create_app
from app.extensions import db


def main():
    email = input("Enter the email address to delete: ").strip()

    if not email or "@" not in email:
        print("Invalid email address.")
        return

    if input(f'Type DELETE to delete "{email}": ').strip() != "DELETE":
        print("Cancelled.")
        return

    app = create_app()

    with app.app_context():
        try:
            user = db.session.execute(
                text("""
                    SELECT id, username, email
                    FROM users
                    WHERE lower(email) = lower(:email)
                """),
                {"email": email}
            ).mappings().first()

            if not user:
                print("User not found.")
                return

            uid = user["id"]

            print(f"\nID: {uid}")
            print(f"Username: {user['username']}")
            print(f"Email: {user['email']}")

            # Identify references from tables other than users.
            inspector = inspect(db.engine)
            other_references = []

            for table in inspector.get_table_names():
                for fk in inspector.get_foreign_keys(table):
                    if fk.get("referred_table") != "users":
                        continue

                    for column in fk.get("constrained_columns", []):
                        if table == "users":
                            continue

                        count = db.session.execute(
                            text(
                                f'SELECT COUNT(*) FROM "{table}" '
                                f'WHERE "{column}" = :uid'
                            ),
                            {"uid": uid}
                        ).scalar()

                        if count:
                            other_references.append(
                                (table, column, count)
                            )

            if other_references:
                print("\nDeletion stopped. Other tables reference this user:")
                for table, column, count in other_references:
                    print(f"  {table}.{column}: {count} record(s)")
                print("No changes were committed.")
                return

            # Remove approval/rejection references from other user rows.
            # Preserve the other users and their accounts.
            db.session.execute(
                text("""
                    UPDATE users
                    SET role_approved_by = NULL
                    WHERE role_approved_by = :uid
                """),
                {"uid": uid}
            )

            db.session.execute(
                text("""
                    UPDATE users
                    SET role_rejected_by = NULL
                    WHERE role_rejected_by = :uid
                """),
                {"uid": uid}
            )

            # Delete only the selected account.
            db.session.execute(
                text("DELETE FROM users WHERE id = :uid"),
                {"uid": uid}
            )

            db.session.commit()
            print(f"\nSUCCESS: Deleted {email} (ID {uid}).")

        except SQLAlchemyError as exc:
            db.session.rollback()
            print("\nDatabase operation failed; changes rolled back.")
            print(str(exc))

        except Exception as exc:
            db.session.rollback()
            print("\nUnexpected error; changes rolled back.")
            print(repr(exc))


if __name__ == "__main__":
    main()