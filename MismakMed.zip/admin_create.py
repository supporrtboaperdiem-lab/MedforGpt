import getpass
import sys
from datetime import datetime

from app import create_app
from app.extensions import db
from app.models.user import User
from app.models.role import Role


app = create_app()

EMAIL = "support.boamedical@bankofabyssinia.com"


def create_administrator():
    print("=" * 60)
    print("CREATE ADMINISTRATOR")
    print("=" * 60)
    print(f"Email: {EMAIL}")

    password = getpass.getpass("Enter administrator password: ")
    confirm = getpass.getpass("Confirm administrator password: ")

    if not password:
        print("ERROR: Password cannot be empty.")
        return False

    if password != confirm:
        print("ERROR: Passwords do not match.")
        return False

    with app.app_context():

        # --------------------------------------------------
        # Find Administrator role
        # --------------------------------------------------

        role = Role.query.filter(
            db.func.lower(Role.name) == "administrator"
        ).first()

        if not role:
            print(
                "ERROR: The 'Administrator' role does not exist "
                "in the database."
            )
            return False

        print(f"Administrator role ID: {role.id}")

        # --------------------------------------------------
        # Check whether user already exists
        # --------------------------------------------------

        user = User.query.filter(
            db.func.lower(User.email) == EMAIL.lower()
        ).first()

        if user:

            print()
            print("User already exists.")
            print(f"Username: {user.username}")
            print(f"Current role: {user.role_name}")
            print(f"Active: {user.is_active}")
            print(
                f"Role approval: "
                f"{user.role_approval_status}"
            )

            answer = input(
                "\nConvert this existing user to Administrator? "
                "[y/N]: "
            ).strip().lower()

            if answer != "y":
                print("No changes made.")
                return False

            user.role_id = role.id
            user.is_active = True
            user.role_status = "APPROVED"
            user.role_approval_status = "APPROVED"
            user.role_approved_at = datetime.utcnow()
            user.role_rejected_at = None
            user.role_rejection_reason = None
            user.set_password(password)

            db.session.commit()

            print()
            print("=" * 60)
            print("ADMINISTRATOR UPDATED SUCCESSFULLY")
            print("=" * 60)
            print(f"Email: {user.email}")
            print(f"Username: {user.username}")
            print(f"Role: {user.role_name}")
            print(f"Active: {user.is_active}")
            print(
                f"Approval: "
                f"{user.role_approval_status}"
            )
            print("=" * 60)

            return True

        # --------------------------------------------------
        # Create new administrator
        # --------------------------------------------------

        username = input(
            "Enter username for administrator: "
        ).strip()

        if not username:
            print("ERROR: Username cannot be empty.")
            return False

        full_name = input(
            "Enter administrator full name: "
        ).strip()

        if not full_name:
            print("ERROR: Full name cannot be empty.")
            return False

        # Check username
        existing_username = User.query.filter(
            db.func.lower(User.username) ==
            username.lower()
        ).first()

        if existing_username:
            print(
                f"ERROR: Username '{username}' already exists."
            )
            return False

        user = User(
            username=username,
            full_name=full_name,
            email=EMAIL,
            role_id=role.id,
            is_active=True,
            role_status="APPROVED",
            role_approval_status="APPROVED",
            role_approved_at=datetime.utcnow()
        )

        user.set_password(password)

        db.session.add(user)
        db.session.commit()

        print()
        print("=" * 60)
        print("ADMINISTRATOR CREATED SUCCESSFULLY")
        print("=" * 60)
        print(f"Email:     {user.email}")
        print(f"Username:  {user.username}")
        print(f"Full name: {user.full_name}")
        print(f"Role:      {user.role_name}")
        print(f"Active:    {user.is_active}")
        print(
            f"Approval:  "
            f"{user.role_approval_status}"
        )
        print("=" * 60)

        return True


if __name__ == "__main__":

    try:
        success = create_administrator()
        sys.exit(0 if success else 1)

    except Exception as e:

        with app.app_context():
            db.session.rollback()

        print()
        print("=" * 60)
        print("ERROR")
        print("=" * 60)
        print(str(e))
        print("=" * 60)

        sys.exit(1)