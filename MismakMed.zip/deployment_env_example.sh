#!/usr/bin/env bash
# Source this from ~/.bash_profile or copy the exports into ~/.bash_profile.
# Replace every placeholder before use. Do not commit real secrets.

export PYTHONUNBUFFERED=1
export SECRET_KEY='REPLACE_WITH_REAL_SECRET_KEY'
export DATABASE_URL='sqlite:///instance/medical.db'

export LDAP_SERVER='REPLACE_WITH_LDAP_SERVER'
export LDAP_PORT='389'
export LDAP_BASE_DN='REPLACE_WITH_BASE_DN'
export LDAP_DOMAIN='REPLACE_WITH_DOMAIN'
export LDAP_USERNAME='REPLACE_WITH_LDAP_USERNAME'
export LDAP_PASSWORD='REPLACE_WITH_LDAP_PASSWORD'
export LDAP_CONNECT_TIMEOUT='5'

export MAIL_SERVER='REPLACE_WITH_MAIL_SERVER'
export MAIL_PORT='587'
export MAIL_USERNAME='REPLACE_WITH_MAIL_USERNAME'
export MAIL_PASSWORD='REPLACE_WITH_MAIL_PASSWORD'
export MAIL_USE_TLS='true'
export MAIL_CONNECT_TIMEOUT_SECONDS='5'

# Kaggle/Cloudflare Quick Tunnel: change only this URL when the tunnel changes.
export OLLAMA_SERVER_URL='https://YOUR-TUNNEL.trycloudflare.com/v1/chat/completions'
export OLLAMA_API_KEY='REPLACE_WITH_AI_API_KEY'
export OLLAMA_MODEL='gemma-4-26B-A4B-it-Q4_K_M.gguf'
export OLLAMA_HEALTH_TIMEOUT_SECONDS='2'
export OLLAMA_CONNECT_TIMEOUT_SECONDS='3'
export OLLAMA_READ_TIMEOUT_SECONDS='0'
# Number of receipt AI requests processed concurrently in one multi-receipt submission.
# Start at 4; raise only if the Ollama host has enough GPU/CPU capacity.
export OLLAMA_MAX_CONCURRENT_REQUESTS='4'
