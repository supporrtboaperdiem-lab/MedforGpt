import smtplib
from email.message import EmailMessage


SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587

SENDER_EMAIL = "supporrt.boaperdiem@gmail.com"
APP_PASSWORD = "xljlbwtellvifjzs"

RECEIVER_EMAIL = "maklitosh22@gmail.com"


msg = EmailMessage()

msg["Subject"] = "Welcome to BOA Perdiem System"
msg["From"] = SENDER_EMAIL
msg["To"] = RECEIVER_EMAIL

msg.set_content(
    "Welcome to the BOA Perdiem System!"
)

msg.add_alternative(
    """
    <html>
    <body style="font-family: Arial, sans-serif;">

        <h2 style="color: #007bff;">
            Welcome to BOA Perdiem System
        </h2>

        <p>
            Dear User,
        </p>

        <p>
            Welcome to the BOA Perdiem System.
            Your email notification system is working successfully.
        </p>

        <p>
            This is a test message sent from the
            Medical Reimbursement System mailer.
        </p>

        <br>

        <p>
            Kind Regards,<br>
            <strong>BOA Perdiem System</strong>
        </p>

    </body>
    </html>
    """,
    subtype="html"
)


print("[MAIL] Connecting to Gmail SMTP...")
print(f"[MAIL] From: {SENDER_EMAIL}")
print(f"[MAIL] To:   {RECEIVER_EMAIL}")

try:

    with smtplib.SMTP(
        SMTP_SERVER,
        SMTP_PORT,
        timeout=5
    ) as server:

        print("[MAIL] Starting TLS...")
        server.starttls()

        print("[MAIL] Logging into Gmail...")
        server.login(
            SENDER_EMAIL,
            APP_PASSWORD
        )

        print("[MAIL] Sending email...")

        server.send_message(msg)

    print()
    print("[MAIL] SUCCESS!")
    print(
        f"[MAIL] Email successfully sent to {RECEIVER_EMAIL}"
    )

except Exception as e:

    print()
    print("[MAIL][ERROR]")
    print(str(e))