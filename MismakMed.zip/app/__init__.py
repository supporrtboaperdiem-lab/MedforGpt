import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

from flask import Flask
from sqlalchemy import inspect, text
import sqlalchemy as sa

from app.config import config_by_name, normalize_database_uri
from app.extensions import db, migrate, csrf, login_manager
from app.routes.auth import auth_bp
#from app.cli import register_cli


def create_app(config_name="development"):

    app = Flask(__name__)

    config_class = config_by_name.get(
        config_name,
        config_by_name["development"]
    )

    app.config.from_object(config_class)

    # Normalize relative SQLite URLs so ``sqlite:///instance/medical.db``
    # always resolves inside the Medical project, regardless of the shell
    # working directory (bash, Gunicorn, systemd, etc.).
    app.config["SQLALCHEMY_DATABASE_URI"] = normalize_database_uri(
        app.config.get("SQLALCHEMY_DATABASE_URI")
    )

    init_extensions(app)
    ensure_claim_category_column(app)
    ensure_beneficiary_and_description_columns(app)
    ensure_employee_directory_and_claim_item_columns(app)
    ensure_optics_and_claim_schema(app)
    ensure_claim_receipt_date_column(app)
    ensure_receipt_fraud_columns(app)
    ensure_rejection_cleanup_columns(app)
    ensure_consultation_tables(app)
    ensure_spouse_directory_table(app)
    bootstrap_bundled_employee_directory(app)
    bootstrap_bundled_spouse_directory(app)
    cleanup_rejected_records(app)
    register_blueprints(app)
    configure_logging(app)
    #register_cli(app)

    return app


@login_manager.user_loader
def load_user(user_id):

    from app.models.user import User

    return User.query.get(
        int(user_id)
    )


def init_extensions(app):

    db.init_app(app)

    migrate.init_app(
        app,
        db
    )

    csrf.init_app(app)

    login_manager.init_app(app)


def ensure_claim_category_column(app):

    """
    Safely adds only the claim-workflow columns required
    by the current application.

    Existing tables/data are preserved.
    """

    with app.app_context():

        try:

            inspector = inspect(
                db.engine
            )

            if "medical_claims" not in (
                inspector.get_table_names()
            ):

                return


            columns = {
                column["name"]
                for column in inspector.get_columns(
                    "medical_claims"
                )
            }


            # =================================================
            # CATEGORY
            # =================================================

            if "category" not in columns:

                db.session.execute(
                    text(
                        "ALTER TABLE medical_claims "
                        "ADD COLUMN category VARCHAR(20) "
                        "NOT NULL DEFAULT 'NORMAL'"
                    )
                )


            # =================================================
            # SUBMITTER
            # =================================================

            if "submitted_by_id" not in columns:

                db.session.execute(
                    text(
                        "ALTER TABLE medical_claims "
                        "ADD COLUMN submitted_by_id INTEGER "
                        "REFERENCES users(id)"
                    )
                )


            db.session.commit()


        except Exception:

            db.session.rollback()

            raise


def ensure_beneficiary_and_description_columns(app):
    """
    Backward-compatible schema upgrade for spouse reimbursement and
    per-item service descriptions. Existing data is preserved.
    """
    with app.app_context():
        try:
            inspector = inspect(db.engine)
            tables = set(inspector.get_table_names())


            if "medical_claims" in tables:
                claim_columns = {c["name"] for c in inspector.get_columns("medical_claims")}
                additions = {
                    "beneficiary_type": "VARCHAR(20) NOT NULL DEFAULT 'EMPLOYEE'",
                    "beneficiary_name": "VARCHAR(200)",
                    "employee_owner_name": "VARCHAR(200)",
                    "coverage_percentage": "NUMERIC(5,2) NOT NULL DEFAULT 100",
                }
                for name, definition in additions.items():
                    if name not in claim_columns:
                        db.session.execute(text(
                            f"ALTER TABLE medical_claims ADD COLUMN {name} {definition}"
                        ))

            if "medical_claim_items" in tables:
                item_columns = {c["name"] for c in inspector.get_columns("medical_claim_items")}
                additions = {
                    "service_description": "TEXT",
                    "reimbursable_amount": "NUMERIC(12,2) NOT NULL DEFAULT 0",
                }
                for name, definition in additions.items():
                    if name not in item_columns:
                        db.session.execute(text(
                            f"ALTER TABLE medical_claim_items ADD COLUMN {name} {definition}"
                        ))

            # Backfill legacy records so the new report columns do not
            # make historical claims appear to have zero reimbursement.
            if "medical_claims" in tables:
                claim_columns = {c["name"] for c in inspector.get_columns("medical_claims")}
                if {"beneficiary_type", "beneficiary_name", "employee_owner_name", "coverage_percentage"}.issubset(claim_columns):
                    db.session.execute(text(
                        "UPDATE medical_claims SET "
                        "beneficiary_type = COALESCE(beneficiary_type, 'EMPLOYEE'), "
                        "beneficiary_name = COALESCE(beneficiary_name, patient_name), "
                        "coverage_percentage = COALESCE(coverage_percentage, 100)"
                    ))

            if "medical_claim_items" in tables:
                item_columns = {c["name"] for c in inspector.get_columns("medical_claim_items")}
                if {"service_description", "reimbursable_amount", "receipt_price"}.issubset(item_columns):
                    db.session.execute(text(
                        "UPDATE medical_claim_items SET "
                        "service_description = COALESCE(service_description, service_name), "
                        "reimbursable_amount = CASE "
                        "WHEN reimbursable_amount IS NULL OR reimbursable_amount = 0 THEN receipt_price "
                        "ELSE reimbursable_amount END"
                    ))

            db.session.commit()
        except Exception:
            db.session.rollback()
            raise


def ensure_employee_directory_and_claim_item_columns(app):
    """Backward-compatible columns for the imported employee directory and AI item metadata."""
    with app.app_context():
        try:
            inspector = inspect(db.engine)
            tables = set(inspector.get_table_names())
            if "employees" in tables:
                cols = {c["name"] for c in inspector.get_columns("employees")}
                additions = {
                    "employee_id":"VARCHAR(100)", "employee_number":"VARCHAR(100)", "username":"VARCHAR(150)",
                    "user_principal_name":"VARCHAR(255)", "email":"VARCHAR(255)", "first_name":"VARCHAR(100)",
                    "middle_name":"VARCHAR(100)", "last_name":"VARCHAR(100)", "job_title":"VARCHAR(255)",
                    "department":"VARCHAR(255)", "company":"VARCHAR(255)", "office":"VARCHAR(255)",
                    "division":"VARCHAR(255)", "employee_type":"VARCHAR(100)", "mobile":"VARCHAR(100)",
                    "telephone":"VARCHAR(100)", "business_address":"VARCHAR(500)", "city":"VARCHAR(100)",
                    "state_region":"VARCHAR(100)", "country":"VARCHAR(100)", "manager":"VARCHAR(255)", "description":"TEXT",
                }
                for name, definition in additions.items():
                    if name not in cols:
                        db.session.execute(text(f"ALTER TABLE employees ADD COLUMN {name} {definition}"))
            if "medical_claim_items" in tables:
                cols = {c["name"] for c in inspector.get_columns("medical_claim_items")}
                additions = {
                    "item_category":"VARCHAR(100) DEFAULT 'MEDICAL_SERVICE'",
                    "unit_price":"NUMERIC(12,2)",
                    "employee_id":"INTEGER REFERENCES employees(id)",
                    "receipt_id":"INTEGER REFERENCES medical_claim_receipts(id)",
                    "institution_id":"INTEGER REFERENCES institutions(id)",
                }
                for name, definition in additions.items():
                    if name not in cols:
                        db.session.execute(text(f"ALTER TABLE medical_claim_items ADD COLUMN {name} {definition}"))
            db.session.commit()
        except Exception:
            db.session.rollback()
            raise



def ensure_claim_receipt_date_column(app):
    """Add and backfill the receipt's printed date without changing existing claims."""
    with app.app_context():
        try:
            inspector = inspect(db.engine)
            tables = set(inspector.get_table_names())
            if "medical_claim_receipts" not in tables:
                return
            cols = {c["name"] for c in inspector.get_columns("medical_claim_receipts")}
            if "receipt_date" not in cols:
                db.session.execute(text("ALTER TABLE medical_claim_receipts ADD COLUMN receipt_date DATETIME"))
                db.session.commit()
            # Backfill historical receipts from the already stored AI extraction.
            from app.models.claim import MedicalClaimReceipt
            import json
            from datetime import datetime
            rows = MedicalClaimReceipt.query.filter(MedicalClaimReceipt.receipt_date.is_(None)).all()
            changed = 0
            for receipt in rows:
                try:
                    payload = json.loads(receipt.ai_extraction_json or "{}")
                    raw = ((payload.get("document") or {}).get("receipt") or {}).get("receipt_date")
                    if not raw:
                        continue
                    value = str(raw).strip().replace("Z", "+00:00")
                    parsed = None
                    try:
                        parsed = datetime.fromisoformat(value)
                    except Exception:
                        for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%m/%d/%Y", "%d.%m.%Y"):
                            try:
                                parsed = datetime.strptime(str(raw).strip(), fmt); break
                            except ValueError:
                                pass
                    if parsed:
                        receipt.receipt_date = parsed
                        changed += 1
                except Exception:
                    continue
            if changed:
                db.session.commit()
        except Exception:
            db.session.rollback()
            raise

def ensure_receipt_fraud_columns(app):
    """Install/backfill receipt fraud fields without deleting existing data.

    This runtime guard is intentional because bundled/older databases may be
    at an earlier Alembic revision. The formal Alembic migration is also
    included for normal deployments. Existing receipt.created_at is retained
    as the historical upload timestamp when uploaded_at is empty.
    """
    with app.app_context():
        try:
            inspector = inspect(db.engine)
            if "medical_claim_receipts" not in set(inspector.get_table_names()):
                return
            cols = {c["name"] for c in inspector.get_columns("medical_claim_receipts")}
            additions = {
                "uploaded_at": "DATETIME",
                "file_sha256": "VARCHAR(64)",
                "image_phash": "VARCHAR(64)",
                "receipt_metadata_fingerprint": "VARCHAR(64)",
                "receipt_metadata_key": "VARCHAR(500)",
            }
            for name, definition in additions.items():
                if name not in cols:
                    db.session.execute(text(f"ALTER TABLE medical_claim_receipts ADD COLUMN {name} {definition}"))
            db.session.commit()

            from app.models.claim import MedicalClaimReceipt
            from app.services.duplicate_detector import DuplicateDetector
            import json

            rows = MedicalClaimReceipt.query.all()
            changed = False
            # The model/database enforces UNIQUE(file_sha256). Older receipt rows
            # can point to the same underlying file, so blindly backfilling every
            # hash in one transaction can make application startup fail. Keep the
            # first hash and leave subsequent exact duplicates NULL; the existing
            # row remains the canonical exact-file duplicate match.
            known_file_hashes = {
                str(receipt.file_sha256).strip()
                for receipt in rows
                if getattr(receipt, "file_sha256", None)
            }
            for receipt in rows:
                if receipt.uploaded_at is None and receipt.created_at is not None:
                    receipt.uploaded_at = receipt.created_at
                    changed = True
                try:
                    payload = json.loads(receipt.ai_extraction_json or "{}")
                    if not receipt.receipt_metadata_fingerprint:
                        receipt.receipt_metadata_fingerprint = DuplicateDetector.metadata_fingerprint(payload)
                        changed = True
                    if not receipt.receipt_metadata_key:
                        receipt.receipt_metadata_key = DuplicateDetector._metadata_identifier_key(payload)
                        changed = True
                except Exception:
                    payload = {}
                try:
                    if receipt.file_path and Path(receipt.file_path).is_file():
                        if not receipt.file_sha256 or not receipt.image_phash:
                            computed_sha256 = DuplicateDetector.sha256_file(receipt.file_path)
                            computed_phash = DuplicateDetector._image_phash(receipt.file_path)
                            if not receipt.file_sha256 and computed_sha256:
                                if computed_sha256 not in known_file_hashes:
                                    receipt.file_sha256 = computed_sha256
                                    known_file_hashes.add(computed_sha256)
                                    changed = True
                                # else: leave this duplicate row's SHA-256 NULL to
                                # satisfy the unique constraint without losing it.
                            if not receipt.image_phash and computed_phash:
                                receipt.image_phash = computed_phash
                                changed = True
                except Exception:
                    pass
            if changed:
                db.session.commit()

            # Exact file hashes are the non-negotiable duplicate guard. NULL
            # values are allowed for legacy rows whose files are no longer
            # available.
            db.session.execute(text(
                "CREATE UNIQUE INDEX IF NOT EXISTS uq_medical_claim_receipts_file_sha256 "
                "ON medical_claim_receipts(file_sha256) WHERE file_sha256 IS NOT NULL"
            ))
            db.session.commit()
        except Exception:
            db.session.rollback()
            raise


def bootstrap_bundled_employee_directory(app):
    """Load the bundled authoritative employee directory on a fresh install.

    The import runs only when the Employee table is empty, so an existing
    installation is never overwritten automatically. Administrators can use
    the Employee Directory import screen to refresh an existing directory.
    """
    with app.app_context():
        try:
            from app.models.employee import Employee
            bundled = Path(app.root_path).parent / "data" / "employee_directory" / "bo_ldap_users.xlsx"
            if not bundled.is_file():
                return
            if Employee.query.count() > 0:
                return
            from app.services.employee_directory_service import EmployeeDirectoryService
            result = EmployeeDirectoryService.import_excel(bundled)
            app.logger.info(
                "Bundled employee directory loaded: %s imported, %s updated, %s skipped",
                result.get("imported", 0), result.get("updated", 0), result.get("skipped", 0),
            )
        except Exception:
            app.logger.exception("Failed to bootstrap bundled employee directory")
            raise



def ensure_optics_and_claim_schema(app):
    """Backward-compatible schema for optics policy and nullable optics institution."""
    with app.app_context():
        try:
            inspector = inspect(db.engine)
            tables = set(inspector.get_table_names())
            if "medical_claims" in tables:
                cols_info = {c["name"]: c for c in inspector.get_columns("medical_claims")}
                cols = set(cols_info)
                additions = {
                    "optics_lens_type":"VARCHAR(30)",
                    "optics_frame_price":"NUMERIC(12,2)",
                    "optics_lens_price":"NUMERIC(12,2)",
                    "optics_frame_reimbursable":"NUMERIC(12,2)",
                    "optics_lens_reimbursable":"NUMERIC(12,2)",
                    "optics_reimbursable_total":"NUMERIC(12,2)",
                }
                for name, definition in additions.items():
                    if name not in cols:
                        db.session.execute(text(f"ALTER TABLE medical_claims ADD COLUMN {name} {definition}"))
                db.session.commit()

                # Existing SQLite installations were created with institution_id
                # NOT NULL. Use Alembic's batch operation to safely rebuild only
                # that table while preserving all existing claim rows/indexes.
                refreshed = inspect(db.engine)
                institution_col = next((c for c in refreshed.get_columns("medical_claims") if c["name"] == "institution_id"), None)
                if institution_col and institution_col.get("nullable") is False:
                    from alembic.migration import MigrationContext
                    from alembic.operations import Operations
                    connection = db.engine.connect()
                    transaction = connection.begin()
                    try:
                        context = MigrationContext.configure(connection)
                        operations = Operations(context)
                        with operations.batch_alter_table("medical_claims") as batch:
                            batch.alter_column("institution_id", existing_type=sa.Integer(), nullable=True)
                        transaction.commit()
                    except Exception:
                        transaction.rollback()
                        raise
                    finally:
                        connection.close()
            db.session.commit()
        except Exception:
            db.session.rollback()
            raise

def ensure_rejection_cleanup_columns(app):
    """Add only the creator column required for price-list action emails."""
    with app.app_context():
        try:
            inspector = inspect(db.engine)
            tables = set(inspector.get_table_names())

            if "price_list_batches" in tables:
                columns = {c["name"] for c in inspector.get_columns("price_list_batches")}
                if "created_by_id" not in columns:
                    db.session.execute(text(
                        "ALTER TABLE price_list_batches "
                        "ADD COLUMN created_by_id INTEGER "
                        "REFERENCES users(id)"
                    ))
                    db.session.commit()
        except Exception:
            db.session.rollback()
            raise


def ensure_consultation_tables(app):
    """
    Create the live-consultation tables when missing and safely upgrade an
    existing SQLite consultation table when the Python model has gained
    columns.  This intentionally changes only the consultation schema and
    preserves all existing application tables and data.
    """
    with app.app_context():
        try:
            from app.models.medical_consultation import MedicalConsultation, MedicalPresence

            # Create the tables if this is a new installation.
            db.create_all()

            inspector = inspect(db.engine)
            tables = set(inspector.get_table_names())

            if "medical_consultations" not in tables:
                return

            existing = {
                column["name"]
                for column in inspector.get_columns("medical_consultations")
            }

            # SQLite's create_all() does NOT alter an already-existing table.
            # The current consultation model requires these columns. Add only
            # columns that are actually missing; never drop or recreate the table.
            required_columns = {
                "token": "VARCHAR(96)",
                "requester_id": "INTEGER REFERENCES users(id)",
                "receiver_id": "INTEGER REFERENCES users(id)",
                # Legacy consultation schema compatibility. Some existing
                # installations have a required medical_officer_id column.
                # Keep it present and synchronize it with receiver_id rather
                # than dropping/recreating the user's table.
                "medical_officer_id": "INTEGER REFERENCES users(id)",
                "status": "VARCHAR(20) NOT NULL DEFAULT 'PENDING'",
                "offer": "TEXT",
                "answer": "TEXT",
                "requester_candidates": "TEXT NOT NULL DEFAULT '[]'",
                "receiver_candidates": "TEXT NOT NULL DEFAULT '[]'",
                "created_at": "DATETIME",
                "updated_at": "DATETIME",
                "last_activity_at": "DATETIME",
                "accepted_at": "DATETIME",
                "started_at": "DATETIME",
                "ended_at": "DATETIME",
                "duration_seconds": "INTEGER NOT NULL DEFAULT 0",
                "ended_by_id": "INTEGER REFERENCES users(id)",
                "end_reason": "VARCHAR(100)",
                # Older installations already have this NOT NULL column.
                # Add it when missing so the ORM and legacy database schema
                # stay compatible without dropping or recreating the table.
                "expires_at": "DATETIME",
            }

            changed = False

            for column_name, definition in required_columns.items():
                if column_name in existing:
                    continue

                db.session.execute(
                    text(
                        f"ALTER TABLE medical_consultations "
                        f"ADD COLUMN {column_name} {definition}"
                    )
                )
                changed = True

            if changed:
                db.session.commit()

            # If expires_at was introduced on an existing table, backfill it
            # from created_at. New rows are explicitly assigned a 30-minute
            # invitation expiry by the consultation service.
            inspector = inspect(db.engine)
            consultation_columns = {
                column["name"]
                for column in inspector.get_columns("medical_consultations")
            }
            if "expires_at" in consultation_columns:
                db.session.execute(
                    text(
                        "UPDATE medical_consultations "
                        "SET expires_at = datetime(COALESCE(created_at, CURRENT_TIMESTAMP), '+30 minutes') "
                        "WHERE expires_at IS NULL"
                    )
                )
                db.session.commit()

            # Older consultation databases may already contain
            # medical_officer_id values while receiver_id was introduced later.
            # Backfill only missing receiver_id values; never overwrite an
            # existing receiver assignment.
            inspector = inspect(db.engine)
            consultation_columns = {
                column["name"]
                for column in inspector.get_columns("medical_consultations")
            }
            if "medical_officer_id" in consultation_columns and "receiver_id" in consultation_columns:
                db.session.execute(
                    text(
                        "UPDATE medical_consultations "
                        "SET receiver_id = medical_officer_id "
                        "WHERE receiver_id IS NULL "
                        "AND medical_officer_id IS NOT NULL"
                    )
                )
                db.session.commit()

            # Re-inspect after ALTER TABLE so the next check uses the actual
            # database schema.
            inspector = inspect(db.engine)

            # medical_presence is also created by create_all(), but explicitly
            # ensure it exists in case the database was created before the
            # presence model was introduced.
            if "medical_presence" not in inspector.get_table_names():
                MedicalPresence.__table__.create(
                    bind=db.engine,
                    checkfirst=True
                )
                db.session.commit()

        except Exception:
            db.session.rollback()
            raise




def ensure_spouse_directory_table(app):
    """Create the dedicated spouse directory table without touching existing data."""
    with app.app_context():
        from app.models.spouse_directory import SpouseDirectory
        SpouseDirectory.__table__.create(db.engine, checkfirst=True)


def bootstrap_bundled_spouse_directory(app):
    """Load the supplied spouse workbook once at startup when it is bundled with the project."""
    with app.app_context():
        bundled = Path(app.root_path).parent / "data" / "spouse list.xlsx"
        if not bundled.exists():
            return
        try:
            from app.services.spouse_directory_service import SpouseDirectoryService
            result = SpouseDirectoryService.import_excel(bundled)
            app.logger.info(
                "Bundled spouse directory loaded: %s imported, %s updated, %s skipped",
                result["imported"], result["updated"], result["skipped"],
            )
        except Exception:
            app.logger.exception("Bundled spouse directory load failed")


def cleanup_rejected_records(app):
    """Permanently remove previously rejected users/claims/price lists."""
    with app.app_context():
        try:
            from app.models.claim import MedicalClaim
            from app.models.price_list_batch import PriceListBatch
            from app.models.user import User
            import os

            rejected_claims = MedicalClaim.query.filter(
                MedicalClaim.status.in_(["REJECTED", "DECLINED"])
            ).all()

            claim_paths = []
            for claim in rejected_claims:
                legacy = getattr(claim, "receipt_file_path", None)
                if legacy:
                    claim_paths.append(legacy)
                for receipt in getattr(claim, "receipts", []) or []:
                    if getattr(receipt, "file_path", None):
                        claim_paths.append(receipt.file_path)

            for claim in rejected_claims:
                db.session.delete(claim)

            rejected_batches = PriceListBatch.query.filter(
                PriceListBatch.status.in_(["REJECTED", "DECLINED"])
            ).all()

            for batch in rejected_batches:
                db.session.delete(batch)

            rejected_users = User.query.filter(
                User.role_approval_status == "REJECTED"
            ).all()

            rejected_user_ids = {user.id for user in rejected_users}

            user_claim_paths = []

            if rejected_user_ids:
                user_claims = MedicalClaim.query.filter(
                    MedicalClaim.submitted_by_id.in_(rejected_user_ids)
                ).all()

                user_claim_paths = []
                for claim in user_claims:
                    legacy = getattr(claim, "receipt_file_path", None)
                    if legacy:
                        user_claim_paths.append(legacy)
                    for receipt in getattr(claim, "receipts", []) or []:
                        if getattr(receipt, "file_path", None):
                            user_claim_paths.append(receipt.file_path)

                for claim in user_claims:
                    db.session.delete(claim)

                User.query.filter(
                    User.role_approved_by.in_(rejected_user_ids)
                ).update(
                    {User.role_approved_by: None},
                    synchronize_session=False,
                )
                User.query.filter(
                    User.role_rejected_by.in_(rejected_user_ids)
                ).update(
                    {User.role_rejected_by: None},
                    synchronize_session=False,
                )

                for user in rejected_users:
                    db.session.delete(user)

            db.session.commit()

            for path in claim_paths + user_claim_paths:
                if path and os.path.isfile(path):
                    try:
                        os.remove(path)
                    except OSError:
                        pass

        except Exception:
            db.session.rollback()
            raise

def register_blueprints(app):

    from app.routes.main import main_bp
    from app.routes.employee import employee_bp
    from app.routes.institution import institution_bp
    from app.routes.price_list import price_list_bp
    from app.routes.claim import claim_bp
    from app.routes.reports import reports_bp
    from app.routes.consultation import consultation_bp
    from app.routes.pharmacy_exclusions import pharmacy_exclusions_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(employee_bp)
    app.register_blueprint(institution_bp)
    app.register_blueprint(price_list_bp)
    app.register_blueprint(claim_bp)
    app.register_blueprint(reports_bp)
    app.register_blueprint(consultation_bp)
    app.register_blueprint(pharmacy_exclusions_bp)
    app.register_blueprint(auth_bp)


def configure_logging(app):

    log_dir = Path("logs")

    log_dir.mkdir(
        exist_ok=True
    )

    file_handler = RotatingFileHandler(
        log_dir / "app.log",
        maxBytes=1024 * 1024,
        backupCount=5
    )

    formatter = logging.Formatter(
        "%(asctime)s %(levelname)s: %(message)s "
        "[in %(pathname)s:%(lineno)d]"
    )

    file_handler.setFormatter(
        formatter
    )

    file_handler.setLevel(
        app.config.get(
            "LOG_LEVEL",
            "INFO"
        )
    )

    app.logger.addHandler(file_handler)
