"""Simple, human-friendly information for claim review expense items.

This is intentionally short and non-technical. It is review assistance only;
it is not a prescribing or treatment recommendation.
"""

import re


MEDICINE_INFO = {
    "paracetamol": {
        "family": "Pain reliever / fever reducer",
        "about": "Used to reduce pain and fever. It is commonly found in tablets, capsules and liquid medicines.",
        "common_use": "Headache, fever, body aches and other mild to moderate pain.",
        "note": "Use only according to the package or clinician instructions; too much can harm the liver.",
    },
    "acetaminophen": {
        "family": "Pain reliever / fever reducer",
        "about": "The same medicine commonly known as paracetamol in many countries. It reduces pain and fever.",
        "common_use": "Headache, fever, body aches and other mild to moderate pain.",
        "note": "Avoid taking more than the recommended amount, especially when other medicines also contain acetaminophen.",
    },
    "ibuprofen": {
        "family": "Anti-inflammatory pain reliever (NSAID)",
        "about": "A medicine that can reduce pain, fever and inflammation.",
        "common_use": "Pain, fever, muscle or joint inflammation and some headaches.",
        "note": "It may irritate the stomach and is not suitable for everyone. Follow clinician or package directions.",
    },
    "amoxicillin": {
        "family": "Penicillin-type antibiotic",
        "about": "An antibiotic used for certain bacterial infections. It does not treat viral illnesses such as ordinary colds.",
        "common_use": "Certain infections of the ear, throat, chest, teeth, skin or urinary system when prescribed.",
        "note": "Take only when prescribed and complete the prescribed course unless a clinician tells you otherwise.",
    },
    "azithromycin": {
        "family": "Macrolide antibiotic",
        "about": "An antibiotic used for selected bacterial infections.",
        "common_use": "Some respiratory, skin and other bacterial infections when prescribed.",
        "note": "It should be used for bacterial infections when appropriate; follow the prescribed dose and duration.",
    },
    "metformin": {
        "family": "Biguanide diabetes medicine",
        "about": "Helps lower blood sugar by improving the body's response to insulin and reducing glucose made by the liver.",
        "common_use": "Type 2 diabetes and, in some cases, other conditions under medical supervision.",
        "note": "Usually taken with food as directed. Kidney problems can affect whether it is appropriate.",
    },
    "amlodipine": {
        "family": "Calcium-channel blocker",
        "about": "Helps relax blood vessels so blood can flow more easily.",
        "common_use": "High blood pressure and some types of chest pain.",
        "note": "Take as prescribed. Swollen ankles, dizziness or other effects should be discussed with a clinician if troublesome.",
    },
    "omeprazole": {
        "family": "Acid-reducing medicine (proton-pump inhibitor)",
        "about": "Reduces the amount of acid produced by the stomach.",
        "common_use": "Heartburn, reflux and some stomach-ulcer conditions.",
        "note": "Use for the recommended period and follow the package or clinician instructions.",
    },
    "diclofenac": {
        "family": "Anti-inflammatory pain reliever (NSAID)",
        "about": "Reduces pain and inflammation.",
        "common_use": "Muscle, joint and other inflammatory pain.",
        "note": "Can affect the stomach and other organs in some people. Use the recommended dose and duration.",
    },
    "atorvastatin": {
        "family": "Statin / cholesterol-lowering medicine",
        "about": "Helps lower LDL cholesterol and reduce cardiovascular risk.",
        "common_use": "High cholesterol and prevention of some heart and blood-vessel problems.",
        "note": "Take as prescribed. Unusual severe muscle pain should be reported to a clinician.",
    },
    "ciprofloxacin": {
        "family": "Fluoroquinolone antibiotic",
        "about": "An antibiotic used for selected bacterial infections.",
        "common_use": "Certain urinary, intestinal and other bacterial infections when specifically prescribed.",
        "note": "Not appropriate for every infection. Follow the prescription carefully and report significant tendon or nerve symptoms.",
    },
    "doxycycline": {
        "family": "Tetracycline antibiotic",
        "about": "An antibiotic used for several types of bacterial infections and some other conditions.",
        "common_use": "Certain respiratory, skin and other bacterial infections when prescribed.",
        "note": "Follow the directions carefully; some products and foods can affect how it is taken.",
    },
    "cefixime": {
        "family": "Cephalosporin antibiotic",
        "about": "An antibiotic used for certain bacterial infections.",
        "common_use": "Some throat, ear, urinary and other bacterial infections when prescribed.",
        "note": "Use only when prescribed and complete the prescribed course unless told otherwise.",
    },
}

SERVICE_INFO = {
    "consultation": ("Medical consultation", "A visit with a healthcare professional to assess symptoms, medical history and treatment needs."),
    "laboratory": ("Laboratory test", "A test performed on blood, urine, or another sample to help check a health condition or monitor treatment."),
    "blood test": ("Laboratory blood test", "A laboratory test using a blood sample to check selected health markers."),
    "x-ray": ("X-ray imaging", "An imaging test that uses a small amount of radiation to create pictures of bones and some internal structures."),
    "ultrasound": ("Ultrasound", "An imaging test that uses sound waves to create pictures of structures inside the body."),
    "ct scan": ("CT scan", "An imaging test that combines many X-ray images to create detailed pictures of the body."),
    "mri": ("MRI scan", "An imaging test that uses a strong magnetic field and radio waves to create detailed body images."),
    "surgery": ("Surgical procedure", "A medical procedure in which a healthcare professional treats or examines part of the body using an operation."),
    "dental": ("Dental service", "A service involving examination, prevention or treatment of teeth, gums or other parts of the mouth."),
    "physiotherapy": ("Physiotherapy", "Treatment using guided movement and physical techniques to improve function, mobility and recovery."),
}


def _clean(value):
    return re.sub(r"\s+", " ", str(value or "").strip().lower())


def _medicine_key(name):
    text = _clean(name)
    # Prefer exact/common generic-name matches, including names with strength/form after them.
    for key in sorted(MEDICINE_INFO, key=len, reverse=True):
        if text == key or re.search(rf"\b{re.escape(key)}\b", text):
            return key
    return None


def get_item_information(item):
    name = str(getattr(item, "service_name", "") or "").strip()
    category = _clean(getattr(item, "item_category", "") or "")
    description = str(getattr(item, "service_description", "") or "").strip()

    is_medicine = any(word in category for word in ("medicine", "drug", "pharmacy"))
    medicine_key = _medicine_key(name) if is_medicine or medicine_key_from_name(name) else None
    if medicine_key:
        info = MEDICINE_INFO[medicine_key]
        return {
            "type": "medicine",
            "title": name or medicine_key.title(),
            "family": info["family"],
            "about": info["about"],
            "common_use": info["common_use"],
            "note": info["note"],
        }

    text = _clean(name + " " + description)
    for key, (title, about) in SERVICE_INFO.items():
        if key in text:
            return {
                "type": "service",
                "title": title,
                "about": about,
                "description": description or name,
            }

    return {
        "type": "service",
        "title": name or "Medical service",
        "about": "A medical expense identified from the submitted receipt.",
        "description": description or "No additional description was captured from the receipt.",
    }


def medicine_key_from_name(name):
    return bool(_medicine_key(name))
