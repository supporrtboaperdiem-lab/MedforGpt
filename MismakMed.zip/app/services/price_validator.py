from app.models import PriceList


class PriceValidator:


    def validate(
        self,
        institution_id,
        service_name,
        claimed_amount
    ):

        price = PriceList.query.filter_by(
            institution_id=institution_id,
            service_name=service_name
        ).first()


        if not price:

            return {
                "status": "REJECTED",
                "approved_amount": 0,
                "reason": "Service not approved"
            }


        if claimed_amount <= price.approved_price:

            return {
                "status": "APPROVED",
                "approved_amount": claimed_amount
            }


        return {
            "status": "PARTIAL",
            "approved_amount": price.approved_price,
            "difference":
                claimed_amount - price.approved_price
        }