"""
Medical Reimbursement Engine

Core intelligent reimbursement processor.

Responsibilities
----------------
1. OCR receipt processing
2. Service extraction
3. Intelligent price matching
4. Validation
5. Reimbursement calculation
6. JSON output
"""

from __future__ import annotations

import re
import json
import math
import logging
import unicodedata

from decimal import Decimal
from decimal import ROUND_HALF_UP

from dataclasses import dataclass
from dataclasses import field

from datetime import datetime

from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple
from typing import Any

from rapidfuzz import fuzz
from rapidfuzz import process

from sqlalchemy import or_

from app import db

from app.models.employee import Employee
from app.models.institution import Institution
from app.models.price_list import PriceList
from app.models.receipt import Receipt
from app.models.receipt_item import ReceiptItem

from app.services.ocr_service import OCRService

logger = logging.getLogger(__name__)

# ----------------------------
# Constants
# ----------------------------

MAX_PRICE_DIFFERENCE = Decimal("0.05")

FUZZY_MATCH_THRESHOLD = 90

FUZZY_FALLBACK = 82

MAX_QTY = 500

IGNORE_WORDS = {

    "cash",

    "change",

    "balance",

    "thank",

    "invoice",

    "receipt",

    "subtotal",

    "vat",

    "discount",

    "patient",

    "amount",

    "total",

    "grand",

    "payment",

    "paid",

    "date",

    "doctor",

    "tax",

    "phone",

    "mobile",

    "address",

    "fax",

    "www",

    "email"

}

@dataclass
class ExtractedService:

    line_number: int

    raw_text: str

    service_name: str

    quantity: Decimal

    unit_price: Decimal

    total_price: Decimal

    code: Optional[str] = None

    category: Optional[str] = None

    confidence: float = 0.0

@dataclass
class MatchedService:

    receipt_service: ExtractedService

    matched_price: Optional[PriceList]

    approved_price: Decimal

    claimed_price: Decimal

    variance: Decimal

    approved: bool

    reason: str = ""

@dataclass
class ReceiptSummary:

    institution: Optional[Institution]

    receipt_number: str

    receipt_date: Optional[datetime]

    employee: Optional[Employee]

    total_claimed: Decimal

    total_approved: Decimal

    total_discount: Decimal

    services: List[MatchedService] = field(default_factory=list)

    warnings: List[str] = field(default_factory=list)

    errors: List[str] = field(default_factory=list)

@dataclass
class ReceiptSummary:

    institution: Optional[Institution]

    receipt_number: str

    receipt_date: Optional[datetime]

    employee: Optional[Employee]

    total_claimed: Decimal

    total_approved: Decimal

    total_discount: Decimal

    services: List[MatchedService] = field(default_factory=list)

    warnings: List[str] = field(default_factory=list)

    errors: List[str] = field(default_factory=list)

class ReimbursementEngine:

    """
    Complete reimbursement engine.

    Entire reimbursement workflow starts here.
    """

    def __init__(self):

        self.ocr = OCRService()

        logger.info("Reimbursement Engine initialized.")

    def process_receipt(

        self,

        receipt_path: str,

        institution_id: int,

        employee_id: Optional[int] = None,

    ) -> ReceiptSummary:

        logger.info("Processing receipt...")

        institution = Institution.query.get(institution_id)

        if institution is None:

            raise ValueError("Institution not found.")

        employee = None

        if employee_id:

            employee = Employee.query.get(employee_id)

        ocr_result = self.ocr.extract(receipt_path)

        normalized_lines = self.normalize_lines(ocr_result)

        metadata = self.extract_metadata(normalized_lines)

        services = self.extract_services(normalized_lines)

        summary = ReceiptSummary(

            institution=institution,

            employee=employee,

            receipt_number=metadata["receipt_number"],

            receipt_date=metadata["receipt_date"],

            total_claimed=Decimal("0"),

            total_approved=Decimal("0"),

            total_discount=Decimal("0"),

        )

        summary.services = self.match_services(

            services,

            institution.id,

        )

        self.calculate_totals(summary)

        return summary
    
    def normalize_lines(

        self,

        ocr_result,

    ) -> List[str]:

        cleaned = []

        for line in ocr_result:

            if isinstance(line, dict):

                text = line.get("text", "")

            else:

                text = str(line)

            text = unicodedata.normalize(

                "NFKC",

                text,

            )

            text = text.replace("\t", " ")

            text = re.sub(r"\s+", " ", text)

            text = text.strip()

            if len(text) == 0:

                continue

            cleaned.append(text)

        return cleaned

    def extract_metadata(

        self,

        lines: List[str],

    ) -> Dict[str, Any]:

        receipt_number = ""

        receipt_date = None

        for line in lines:

            upper = line.upper()

            if not receipt_number:

                m = re.search(

                    r"(INV|RCPT|RECEIPT|BILL)[\s:#-]*([A-Z0-9\-]+)",

                    upper,

                )

                if m:

                    receipt_number = m.group(2)

            if receipt_date is None:

                date_match = re.search(

                    r"(\d{2}[/-]\d{2}[/-]\d{4})",

                    line,

                )

                if date_match:

                    try:

                        receipt_date = datetime.strptime(

                            date_match.group(1),

                            "%d/%m/%Y",

                        )

                    except:

                        try:

                            receipt_date = datetime.strptime(

                                date_match.group(1),

                                "%d-%m-%Y",

                            )

                        except:

                            pass

        return {

            "receipt_number": receipt_number,

            "receipt_date": receipt_date,

        }

    # ==========================================================
    # SERVICE EXTRACTION
    # ==========================================================

    def extract_services(
        self,
        lines: List[OCRLine],
        institution=None,
    ) -> List[ReceiptService]:

        services = []

        matcher = PriceListMatcher(institution)

        for line in lines:

            text = line.text.strip()

            if len(text) < 2:
                continue

            amount = self.extract_last_amount(text)

            if amount is None:
                continue

            cleaned_name = self.clean_service_name(text)

            if len(cleaned_name) < 3:
                continue

            match = matcher.find_best_match(cleaned_name)

            service = ReceiptService()

            service.raw_text = text
            service.cleaned_name = cleaned_name

            service.quantity = self.extract_quantity(text)

            service.unit_price = self.extract_unit_price(
                text,
                amount,
                service.quantity,
            )

            service.total_price = amount

            if match is not None:

                service.service = match.service
                service.service_code = match.code
                service.confidence = match.confidence
                service.category = match.category
                service.is_matched = True

            else:

                service.service = cleaned_name
                service.service_code = None
                service.confidence = 0
                service.category = None
                service.is_matched = False

            services.append(service)

        services = self.merge_duplicate_services(services)

        return services

    # ==========================================================
    # QUANTITY
    # ==========================================================

    def extract_quantity(self, text: str) -> float:

        upper = text.upper()

        patterns = [

            r"\bQTY[: ]+(\d+)",

            r"\bX\s*(\d+)",

            r"\b(\d+)\s*PCS",

            r"\b(\d+)\s*TAB",

            r"\b(\d+)\s*CAP",

            r"\b(\d+)\s*VIAL",

            r"\b(\d+)\s*AMP",

            r"\b(\d+)\s*DOSE",

        ]

        for pattern in patterns:

            m = re.search(pattern, upper)

            if m:

                try:

                    return float(m.group(1))

                except:

                    pass

        return 1.0

    # ==========================================================
    # UNIT PRICE
    # ==========================================================

    def extract_unit_price(

        self,

        text: str,

        total_price: float,

        quantity: float,

    ) -> float:

        amounts = self.extract_all_amounts(text)

        if len(amounts) >= 2:

            candidate = amounts[-2]

            if candidate <= total_price:

                return candidate

        if quantity > 1:

            try:

                return round(total_price / quantity, 2)

            except:

                pass

        return total_price

    # ==========================================================
    # AMOUNT EXTRACTION
    # ==========================================================

    def extract_last_amount(

        self,

        text: str,

    ) -> Optional[float]:

        amounts = self.extract_all_amounts(text)

        if not amounts:

            return None

        return amounts[-1]

    def extract_all_amounts(

        self,

        text: str,

    ) -> List[float]:

        matches = re.findall(

            r"\(?-?\d[\d,]*\.?\d*\)?",

            text,

        )

        values = []

        for value in matches:

            number = value.replace(",", "")

            number = number.replace("(", "")

            number = number.replace(")", "")

            try:

                values.append(float(number))
            except:
                pass

        return values

    # ==========================================================
    # CLEAN SERVICE NAME
    # ==========================================================

    def clean_service_name(

        self,

        text: str,

    ) -> str:

        text = re.sub(

            r"\(?-?\d[\d,]*\.?\d*\)?",

            " ",

            text,

        )

        text = re.sub(

            r"\bQTY\b",

            " ",

            text,

            flags=re.I,

        )

        text = re.sub(

            r"\bTOTAL\b",

            " ",

            text,

            flags=re.I,

        )

        text = re.sub(

            r"\bAMOUNT\b",

            " ",

            text,

            flags=re.I,

        )

        text = re.sub(

            r"\bPRICE\b",

            " ",

            text,

            flags=re.I,

        )

        text = re.sub(

            r"\s+",

            " ",

            text,

        )

        return text.strip()

    # ==========================================================
    # MERGE DUPLICATES
    # ==========================================================

    def merge_duplicate_services(
        self,
        services: List[ReceiptService],
    ) -> List[ReceiptService]:

        merged = {}

        for service in services:

            key = (
                service.service_code
                if service.service_code
                else service.cleaned_name.lower()
            )

            if key not in merged:

                merged[key] = service
                continue

            existing = merged[key]

            existing.quantity += service.quantity
            existing.total_price += service.total_price

            if service.unit_price > existing.unit_price:
                existing.unit_price = service.unit_price

            if service.confidence > existing.confidence:
                existing.confidence = service.confidence

        return list(merged.values())

    # ==========================================================
    # CALCULATE TOTALS
    # ==========================================================

    def calculate_totals(
        self,
        services: List[ReceiptService],
    ) -> Dict:

        subtotal = 0.0

        for service in services:
            subtotal += service.total_price

        vat = 0.0
        discount = 0.0
        grand_total = subtotal

        return {
            "subtotal": round(subtotal, 2),
            "vat": round(vat, 2),
            "discount": round(discount, 2),
            "grand_total": round(grand_total, 2),
        }

    # ==========================================================
    # RECEIPT VALIDATION
    # ==========================================================

    def validate_receipt(
        self,
        receipt,
    ) -> List[str]:

        errors = []

        if receipt.employee is None:
            errors.append("Employee not assigned.")

        if receipt.institution is None:
            errors.append("Institution not assigned.")

        if receipt.receipt_date is None:
            errors.append("Receipt date missing.")

        if len(receipt.services) == 0:
            errors.append("No billable services found.")

        total = 0.0

        for service in receipt.services:

            if service.total_price <= 0:
                errors.append(
                    f"Invalid amount for {service.cleaned_name}"
                )

            total += service.total_price

        if total <= 0:
            errors.append("Receipt total is zero.")

        return errors

    # ==========================================================
    # PRICE VALIDATION
    # ==========================================================

    def validate_prices(
        self,
        receipt,
        institution,
    ):

        if institution is None:
            return

        matcher = PriceListMatcher(institution)

        for service in receipt.services:

            if not service.is_matched:
                continue

            expected = matcher.lookup_code(
                service.service_code
            )

            if expected is None:
                continue

            service.expected_price = expected.discounted_price

            difference = abs(
                service.total_price -
                expected.discounted_price
            )

            service.price_difference = difference

            if difference <= 1:

                service.price_status = "MATCH"

            elif difference <= 20:

                service.price_status = "CLOSE"

            else:

                service.price_status = "DIFFERENT"

    # ==========================================================
    # UNKNOWN SERVICES
    # ==========================================================

    def find_unknown_services(
        self,
        receipt,
    ) -> List[ReceiptService]:

        unknown = []

        for service in receipt.services:

            if not service.is_matched:
                unknown.append(service)

        return unknown

    # ==========================================================
    # RECEIPT SUMMARY
    # ==========================================================

    def build_summary(
        self,
        receipt,
    ) -> Dict:

        matched = 0
        unmatched = 0

        for service in receipt.services:

            if service.is_matched:
                matched += 1
            else:
                unmatched += 1

        totals = self.calculate_totals(
            receipt.services
        )

        return {

            "services": len(receipt.services),

            "matched": matched,

            "unmatched": unmatched,

            "match_rate": round(
                (
                    matched /
                    max(1, len(receipt.services))
                ) * 100,
                2,
            ),

            "subtotal": totals["subtotal"],

            "grand_total": totals["grand_total"],

        }

    # ==========================================================
    # DEBUG
    # ==========================================================

    def print_debug(
        self,
        receipt,
    ):

        print("=" * 70)

        print("Receipt Number :", receipt.receipt_number)
        print("Institution   :", receipt.institution)
        print("Date          :", receipt.receipt_date)

        print("=" * 70)

        for service in receipt.services:

            print(
                service.cleaned_name,
                service.total_price,
                service.is_matched,
                service.confidence,
            )

        print("=" * 70)

        summary = self.build_summary(receipt)

        print(summary)

        print("=" * 70)
    # ==========================================================
    # REIMBURSEMENT ENGINE
    # ==========================================================

    def calculate_reimbursement(
        self,
        receipt,
        employee,
        institution,
    ):

        result = ReimbursementResult()

        result.employee = employee
        result.receipt = receipt
        result.institution = institution

        result.original_amount = 0.0
        result.approved_amount = 0.0
        result.rejected_amount = 0.0

        yearly_balance = self.get_remaining_employee_balance(
            employee
        )

        result.available_balance = yearly_balance

        for service in receipt.services:

            line = self.evaluate_service(
                service,
                employee,
                institution,
                yearly_balance,
            )

            result.lines.append(line)

            result.original_amount += line.claimed_amount
            result.approved_amount += line.approved_amount
            result.rejected_amount += line.rejected_amount

            yearly_balance -= line.approved_amount

            if yearly_balance < 0:
                yearly_balance = 0

        result.remaining_balance = yearly_balance

        result.status = self.determine_status(result)

        return result

    # ==========================================================
    # EVALUATE SINGLE SERVICE
    # ==========================================================

    def evaluate_service(
        self,
        service,
        employee,
        institution,
        balance,
    ):

        line = ReimbursementLine()

        line.service = service.service
        line.code = service.service_code

        line.claimed_amount = service.total_price
        line.approved_amount = 0.0
        line.rejected_amount = service.total_price

        line.reason = None

        if not service.is_matched:

            line.reason = "Unknown Service"

            return line

        price = self.lookup_institution_price(
            institution,
            service.service_code,
        )

        if price is None:

            line.reason = "Price Not Found"

            return line

        eligible = min(

            service.total_price,

            price.discounted_price,

        )

        if balance <= 0:

            line.reason = "Annual Limit Exhausted"

            return line

        approved = min(

            eligible,

            balance,

        )

        line.approved_amount = approved

        line.rejected_amount = (

            line.claimed_amount -

            approved

        )

        if approved == line.claimed_amount:

            line.reason = "Approved"

        elif approved == 0:

            line.reason = "Rejected"

        else:

            line.reason = "Partially Approved"

        return line

    # ==========================================================
    # DETERMINE FINAL STATUS
    # ==========================================================

    def determine_status(
        self,
        result,
    ):

        if result.approved_amount == 0:

            return "REJECTED"

        if result.rejected_amount == 0:

            return "APPROVED"

        return "PARTIALLY APPROVED"

    # ==========================================================
    # LOOKUP PRICE
    # ==========================================================

    def lookup_institution_price(
        self,
        institution,
        code,
    ):

        return (

            PriceList.query

            .filter_by(

                institution_id=institution.id,

                code=code,

            )

            .first()

        )

    # ==========================================================
    # EMPLOYEE BALANCE
    # ==========================================================

    def get_remaining_employee_balance(
        self,
        employee,
    ):

        yearly_limit = employee.policy.annual_limit

        used = (

            db.session.query(

                func.sum(

                    Reimbursement.approved_amount

                )

            )

            .filter(

                Reimbursement.employee_id == employee.id,

                extract(

                    "year",

                    Reimbursement.created_at,

                )

                == datetime.now().year,

            )

            .scalar()

        )

        if used is None:

            used = 0

        remaining = yearly_limit - used

        if remaining < 0:

            remaining = 0

        return remaining

    # ==========================================================
    # DUPLICATE RECEIPT CHECK
    # ==========================================================

    def is_duplicate_receipt(
        self,
        receipt,
    ):

        if receipt.receipt_number is None:

            return False

        existing = (

            Receipt.query

            .filter_by(

                receipt_number=receipt.receipt_number,

            )

            .first()

        )

        return existing is not None

    # ==========================================================
    # DUPLICATE SERVICE CHECK
    # ==========================================================

    def duplicate_service(
        self,
        employee,
        service,
    ):

        existing = (

            ReimbursementService.query

            .filter_by(

                employee_id=employee.id,

                service_code=service.service_code,

            )

            .filter(

                ReimbursementService.service_date >=

                datetime.now() -

                timedelta(days=30)

            )

            .first()

        )

        return existing is not None
    
    # ==========================================================
    # POLICY VALIDATION
    # ==========================================================

    def validate_policy(
        self,
        employee,
        service,
        institution,
    ):

        policy = employee.policy

        validation = PolicyValidation()

        validation.allowed = True
        validation.reason = None

        # ------------------------------------------------------
        # Institution Coverage
        # ------------------------------------------------------

        if policy.allowed_institutions:

            if institution.id not in policy.allowed_institutions:

                validation.allowed = False
                validation.reason = "Institution Not Covered"

                return validation

        # ------------------------------------------------------
        # Service Category
        # ------------------------------------------------------

        if policy.excluded_categories:

            if service.category in policy.excluded_categories:

                validation.allowed = False

                validation.reason = "Excluded Category"

                return validation

        # ------------------------------------------------------
        # Service Code
        # ------------------------------------------------------

        if policy.excluded_service_codes:

            if service.service_code in policy.excluded_service_codes:

                validation.allowed = False

                validation.reason = "Excluded Service"

                return validation

        return validation

    # ==========================================================
    # WAITING PERIOD
    # ==========================================================

    def check_waiting_period(
        self,
        employee,
        service,
    ):

        waiting_days = employee.policy.waiting_period_days

        if waiting_days == 0:
            return True

        employment_days = (

            datetime.today().date() -

            employee.employment_date

        ).days

        return employment_days >= waiting_days

    # ==========================================================
    # DEPENDENT VALIDATION
    # ==========================================================

    def validate_dependent(
        self,
        claimant,
    ):

        if claimant is None:
            return False

        if claimant.relationship == "SELF":
            return True

        if claimant.active is False:
            return False

        if claimant.relationship == "CHILD":

            if claimant.age > 21:

                if not claimant.disabled:

                    return False

        return True

    # ==========================================================
    # ADMISSION VALIDATION
    # ==========================================================

    def validate_admission(
        self,
        receipt,
    ):

        bed_services = [

            "BED",

            "WARD",

            "ICU",

            "ROOM",

            "ADMISSION",

        ]

        for service in receipt.services:

            upper = service.cleaned_name.upper()

            for keyword in bed_services:

                if keyword in upper:

                    return True

        return False

    # ==========================================================
    # CHRONIC DISEASE LIMIT
    # ==========================================================

    def chronic_limit(
        self,
        employee,
        service,
    ):

        if employee.chronic_patient is False:

            return None

        policy = employee.policy

        if policy.chronic_limit is None:

            return None

        used = (

            db.session.query(

                func.sum(

                    Reimbursement.approved_amount

                )

            )

            .filter(

                Reimbursement.employee_id == employee.id,

                Reimbursement.chronic_case == True,

            )

            .scalar()

        )

        if used is None:

            used = 0

        remaining = (

            policy.chronic_limit -

            used

        )

        if remaining < 0:

            remaining = 0

        return remaining

    # ==========================================================
    # DAILY LIMIT
    # ==========================================================

    def exceeds_daily_limit(
        self,
        employee,
        amount,
    ):

        policy = employee.policy

        if policy.daily_limit is None:

            return False

        return amount > policy.daily_limit

    # ==========================================================
    # MONTHLY LIMIT
    # ==========================================================

    def monthly_total(
        self,
        employee,
    ):

        first_day = datetime.today().replace(day=1)

        total = (

            db.session.query(

                func.sum(

                    Reimbursement.approved_amount

                )

            )

            .filter(

                Reimbursement.employee_id == employee.id,

                Reimbursement.created_at >= first_day,

            )

            .scalar()

        )

        if total is None:

            total = 0

        return total

    # ==========================================================
    # FAMILY LIMIT
    # ==========================================================

    def remaining_family_limit(
        self,
        employee,
    ):

        if employee.family_id is None:

            return None

        family = employee.family

        used = (

            db.session.query(

                func.sum(

                    Reimbursement.approved_amount

                )

            )

            .join(Employee)

            .filter(

                Employee.family_id == family.id,

            )

            .scalar()

        )

        if used is None:

            used = 0

        remaining = (

            family.annual_limit -

            used

        )

        if remaining < 0:

            remaining = 0

        return remaining

    # ==========================================================
    # EXCLUSION RULES
    # ==========================================================

    def excluded_keywords(self):

        return [

            "COSMETIC",

            "BEAUTY",

            "PLASTIC SURGERY",

            "WHITENING",

            "TOOTHPASTE",

            "SOAP",

            "SHAMPOO",

            "LOTION",

            "CREAM",

            "MAKEUP",

            "PERFUME",

            "DEODORANT",

            "SUNSCREEN",

            "VITAMIN",

            "FOOD",

            "SNACK",

            "SOFT DRINK",

            "TRANSPORT",

            "PARKING",

            "PHONE",

            "AIRTIME",

        ]

    def is_excluded_service(
        self,
        service,
    ):

        upper = service.cleaned_name.upper()

        for keyword in self.excluded_keywords():

            if keyword in upper:

                return True

        return False
    
        # ==========================================================
    # FRAUD DETECTION
    # ==========================================================

    def detect_fraud(
        self,
        receipt,
        employee,
    ):

        fraud = FraudAnalysis()

        fraud.score = 0
        fraud.flags = []

        # ------------------------------------------------------
        # Duplicate Receipt Number
        # ------------------------------------------------------

        if self.is_duplicate_receipt(receipt):

            fraud.score += 50

            fraud.flags.append(
                "Duplicate Receipt Number"
            )

        # ------------------------------------------------------
        # Duplicate Services
        # ------------------------------------------------------

        duplicate_services = 0

        for service in receipt.services:

            if self.duplicate_service(employee, service):

                duplicate_services += 1

        if duplicate_services:

            fraud.score += duplicate_services * 10

            fraud.flags.append(
                f"{duplicate_services} Duplicate Services"
            )

        # ------------------------------------------------------
        # High Amount
        # ------------------------------------------------------

        total = sum(
            s.total_price
            for s in receipt.services
        )

        if total > 50000:

            fraud.score += 20

            fraud.flags.append(
                "High Claim Amount"
            )

        # ------------------------------------------------------
        # Too Many Services
        # ------------------------------------------------------

        if len(receipt.services) > 40:

            fraud.score += 15

            fraud.flags.append(
                "Abnormally High Number Of Services"
            )

        # ------------------------------------------------------
        # OCR Confidence
        # ------------------------------------------------------

        low = 0

        for service in receipt.services:

            if service.confidence < 60:

                low += 1

        if low:

            fraud.score += min(low, 20)

            fraud.flags.append(
                "Low OCR Confidence"
            )

        # ------------------------------------------------------
        # Unknown Services
        # ------------------------------------------------------

        unknown = len(self.find_unknown_services(receipt))

        if unknown:

            fraud.score += unknown * 5

            fraud.flags.append(
                "Unknown Services Present"
            )

        # ------------------------------------------------------
        # Future Date
        # ------------------------------------------------------

        if receipt.receipt_date:

            if receipt.receipt_date.date() > datetime.today().date():

                fraud.score += 50

                fraud.flags.append(
                    "Future Receipt Date"
                )

        # ------------------------------------------------------
        # Final Risk
        # ------------------------------------------------------

        if fraud.score >= 70:

            fraud.risk = "HIGH"

        elif fraud.score >= 35:

            fraud.risk = "MEDIUM"

        else:

            fraud.risk = "LOW"

        return fraud

    # ==========================================================
    # AI CONFIDENCE
    # ==========================================================

    def overall_confidence(
        self,
        receipt,
    ):

        if len(receipt.services) == 0:

            return 0

        total = 0

        for service in receipt.services:

            total += service.confidence

        return round(

            total /

            len(receipt.services),

            2,

        )

    # ==========================================================
    # RECEIPT QUALITY
    # ==========================================================

    def receipt_quality(
        self,
        receipt,
    ):

        confidence = self.overall_confidence(receipt)

        if confidence >= 95:

            return "Excellent"

        if confidence >= 85:

            return "Very Good"

        if confidence >= 70:

            return "Good"

        if confidence >= 50:

            return "Poor"

        return "Very Poor"

    # ==========================================================
    # FINAL REVIEW REQUIRED
    # ==========================================================

    def requires_manual_review(
        self,
        reimbursement,
        fraud,
    ):

        if fraud.risk == "HIGH":

            return True

        if reimbursement.status == "PARTIALLY APPROVED":

            return True

        if reimbursement.rejected_amount > 0:

            return True

        if reimbursement.approved_amount > 30000:

            return True

        return False

    # ==========================================================
    # GENERATE ENGINE REPORT
    # ==========================================================

    def generate_report(
        self,
        reimbursement,
        fraud,
    ):

        report = {}

        report["status"] = reimbursement.status

        report["claimed"] = reimbursement.original_amount

        report["approved"] = reimbursement.approved_amount

        report["rejected"] = reimbursement.rejected_amount

        report["remaining_balance"] = reimbursement.remaining_balance

        report["fraud_score"] = fraud.score

        report["fraud_risk"] = fraud.risk

        report["fraud_flags"] = fraud.flags

        report["manual_review"] = self.requires_manual_review(

            reimbursement,

            fraud,

        )

        report["generated"] = datetime.now()

        return report

    # ==========================================================
    # COMPLETE PIPELINE
    # ==========================================================

    def process_receipt(
        self,
        employee,
        institution,
        ocr_lines,
    ):

        receipt = Receipt()

        meta = self.extract_receipt_information(ocr_lines)

        receipt.receipt_number = meta["receipt_number"]

        receipt.receipt_date = meta["receipt_date"]

        receipt.services = self.extract_services(

            ocr_lines,

            institution,

        )

        self.validate_prices(

            receipt,

            institution,

        )

        reimbursement = self.calculate_reimbursement(

            receipt,

            employee,

            institution,

        )

        fraud = self.detect_fraud(

            receipt,

            employee,

        )

        report = self.generate_report(

            reimbursement,

            fraud,

        )

        return {

            "receipt": receipt,

            "reimbursement": reimbursement,

            "fraud": fraud,

            "report": report,

        }
    
        # ==========================================================
    # MATCH RECEIPT ITEMS TO PRICE LIST
    # ==========================================================

    def match_receipt_items(
        self,
        receipt_items,
        institution_id,
    ):
        """
        Match OCR receipt lines against institution price list.
        """

        price_list = self.price_service.get_price_lookup(institution_id)

        matched = []
        unmatched = []

        for item in receipt_items:

            result = self.match_single_item(
                item,
                price_list,
            )

            if result["matched"]:
                matched.append(result)
            else:
                unmatched.append(result)

        return matched, unmatched

    # ----------------------------------------------------------

    def match_single_item(
        self,
        item,
        price_lookup,
    ):

        service = item["service_name"]

        normalized = normalize_text(service)

        # Exact Match
        if normalized in price_lookup:

            price = price_lookup[normalized]

            return {
                "matched": True,
                "confidence": 1.00,
                "match_type": "exact",
                "receipt_item": item,
                "price_item": price,
            }

        # Fuzzy Match

        names = list(price_lookup.keys())

        best = process.extractOne(
            normalized,
            names,
            scorer=fuzz.token_sort_ratio,
        )

        if best:

            candidate, score, _ = best

            if score >= 92:

                return {
                    "matched": True,
                    "confidence": score / 100,
                    "match_type": "high_fuzzy",
                    "receipt_item": item,
                    "price_item": price_lookup[candidate],
                }

            if score >= 82:

                return {
                    "matched": True,
                    "confidence": score / 100,
                    "match_type": "medium_fuzzy",
                    "receipt_item": item,
                    "price_item": price_lookup[candidate],
                }

            if score >= 72:

                return {
                    "matched": True,
                    "confidence": score / 100,
                    "match_type": "low_fuzzy",
                    "receipt_item": item,
                    "price_item": price_lookup[candidate],
                }

        # Token Match

        token_result = self.token_match(
            normalized,
            price_lookup,
        )

        if token_result:

            return token_result

        return {
            "matched": False,
            "confidence": 0,
            "match_type": "none",
            "receipt_item": item,
            "price_item": None,
        }

    # ----------------------------------------------------------

    def token_match(
        self,
        service,
        lookup,
    ):

        service_tokens = set(service.split())

        best_score = 0
        best_name = None

        for name in lookup.keys():

            tokens = set(name.split())

            common = len(tokens & service_tokens)

            if common == 0:
                continue

            score = common / max(len(tokens), len(service_tokens))

            if score > best_score:
                best_score = score
                best_name = name

        if best_name and best_score >= 0.65:

            return {
                "matched": True,
                "confidence": best_score,
                "match_type": "token",
                "receipt_item": {
                    "service_name": service,
                },
                "price_item": lookup[best_name],
            }

        return None

    # ==========================================================
    # CALCULATE REIMBURSEMENT
    # ==========================================================

    def calculate_reimbursement(
        self,
        matched_items,
    ):

        approved = []

        rejected = []

        total_claim = Decimal("0")
        total_approved = Decimal("0")

        for match in matched_items:

            receipt = match["receipt_item"]
            price = match["price_item"]

            claimed = Decimal(str(receipt["unit_price"]))

            allowed = Decimal(str(price.discounted_price))

            payable = min(claimed, allowed)

            approved.append({

                "service": receipt["service_name"],

                "claimed_price": claimed,

                "approved_price": payable,

                "price_list_price": allowed,

                "quantity": receipt["quantity"],

                "line_total":

                    payable * Decimal(str(receipt["quantity"])),

                "confidence":

                    match["confidence"],

                "match_type":

                    match["match_type"],

            })

            total_claim += (
                claimed *
                Decimal(str(receipt["quantity"]))
            )

            total_approved += (
                payable *
                Decimal(str(receipt["quantity"]))
            )

        return {

            "approved_items": approved,

            "rejected_items": rejected,

            "total_claimed": total_claim,

            "total_approved": total_approved,

            "difference":
                total_claim - total_approved,

        }
    
    # ----------------------------------------------------------
    # VALIDATION
    # ----------------------------------------------------------

    def _validate_receipt(
        self,
        receipt: Receipt,
        institution: Institution,
    ) -> list[str]:

        errors = []

        if not receipt.items:
            errors.append("Receipt contains no billable items.")
            return errors

        total = Decimal("0")

        for item in receipt.items:

            if item.quantity <= 0:
                errors.append(
                    f"{item.service_name}: invalid quantity"
                )

            if item.unit_price < 0:
                errors.append(
                    f"{item.service_name}: invalid unit price"
                )

            total += item.total_price

        if receipt.total_amount:

            diff = abs(
                receipt.total_amount - total
            )

            if diff > Decimal("2"):
                errors.append(
                    "Receipt total does not match line items."
                )

        return errors

    # ----------------------------------------------------------
    # MATCH RECEIPT ITEMS
    # ----------------------------------------------------------

    def _match_services(
        self,
        receipt: Receipt,
        institution: Institution,
    ):

        services = (
            PriceList.query.filter_by(
                institution_id=institution.id
            )
            .all()
        )

        matcher = PriceMatcher(services)

        for item in receipt.items:

            result = matcher.match(item.service_name)

            if result:

                item.price_item = result

                item.matched = True

                item.service_code = result.code

                item.standard_price = Decimal(
                    str(result.price)
                )

            else:

                item.matched = False

    # ----------------------------------------------------------
    # PRICE VERIFICATION
    # ----------------------------------------------------------

    def _verify_prices(
        self,
        receipt: Receipt,
    ):

        for item in receipt.items:

            if not item.matched:
                continue

            expected = item.standard_price

            paid = item.unit_price

            tolerance = Decimal("1.00")

            if abs(expected - paid) <= tolerance:

                item.price_status = PriceStatus.MATCH

            elif paid < expected:

                item.price_status = PriceStatus.DISCOUNTED

            else:

                item.price_status = PriceStatus.OVERCHARGED

    # ----------------------------------------------------------
    # CALCULATE REIMBURSEMENT
    # ----------------------------------------------------------

    def _calculate_reimbursement(
        self,
        receipt: Receipt,
        employee,
    ):

        total = Decimal("0")

        approved = Decimal("0")

        rejected = Decimal("0")

        for item in receipt.items:

            total += item.total_price

            if not item.matched:

                item.reimbursable_amount = Decimal("0")

                rejected += item.total_price

                continue

            if item.price_status == PriceStatus.OVERCHARGED:

                item.reimbursable_amount = (
                    item.standard_price
                    * item.quantity
                )

            else:

                item.reimbursable_amount = (
                    item.total_price
                )

            approved += item.reimbursable_amount

        receipt.total_amount = total
        receipt.approved_amount = approved
        receipt.rejected_amount = rejected

        if employee:

            limit = Decimal(
                str(employee.coverage_limit)
            )

            if approved > limit:

                receipt.approved_amount = limit

                receipt.rejected_amount += (
                    approved - limit
                )

    # ----------------------------------------------------------
    # BUILD FINAL RESPONSE
    # ----------------------------------------------------------

    def _build_result(
        self,
        receipt: Receipt,
    ) -> dict:

        items = []

        for item in receipt.items:

            items.append({

                "service": item.service_name,

                "quantity": float(item.quantity),

                "unit_price": float(item.unit_price),

                "total_price": float(item.total_price),

                "matched": item.matched,

                "service_code": item.service_code,

                "price_status": (
                    item.price_status.value
                    if item.price_status
                    else None
                ),

                "approved": float(
                    item.reimbursable_amount
                ),

            })

        return {

            "receipt_number": receipt.receipt_number,

            "receipt_date": receipt.receipt_date,

            "items": items,

            "total_amount": float(
                receipt.total_amount
            ),

            "approved_amount": float(
                receipt.approved_amount
            ),

            "rejected_amount": float(
                receipt.rejected_amount
            ),

        }

    # ============================================================
    # RECEIPT TOTAL EXTRACTION
    # ============================================================

    def extract_totals(self, ocr_lines):

        subtotal = None
        discount = None
        tax = None
        total = None

        for line in ocr_lines:

            upper = line.upper()

            # ----------------------------
            # TOTAL
            # ----------------------------
            if any(
                key in upper
                for key in [
                    "GRAND TOTAL",
                    "TOTAL AMOUNT",
                    "NET TOTAL",
                    "PAYABLE",
                    "AMOUNT DUE",
                    "TOTAL"
                ]
            ):

                numbers = self.extract_numbers(line)

                if numbers:
                    total = numbers[-1]


            # ----------------------------
            # DISCOUNT
            # ----------------------------
            if "DISCOUNT" in upper:

                numbers = self.extract_numbers(line)

                if numbers:
                    discount = numbers[-1]


            # ----------------------------
            # TAX
            # ----------------------------
            if any(
                key in upper
                for key in [
                    "VAT",
                    "TAX",
                    "SERVICE CHARGE"
                ]
            ):

                numbers = self.extract_numbers(line)

                if numbers:
                    tax = numbers[-1]


            # ----------------------------
            # SUBTOTAL
            # ----------------------------
            if "SUBTOTAL" in upper:

                numbers = self.extract_numbers(line)

                if numbers:
                    subtotal = numbers[-1]


        return {

            "subtotal": subtotal,
            "discount": discount,
            "tax": tax,
            "total": total

        }



    # ============================================================
    # NUMBER EXTRACTION
    # ============================================================

    def extract_numbers(self, text):

        pattern = r"""
            (?:
                \d{1,3}(?:,\d{3})*
                |
                \d+
            )
            (?:\.\d{1,2})?
        """

        matches = re.findall(
            pattern,
            text,
            re.VERBOSE
        )


        results = []


        for value in matches:

            try:

                clean = value.replace(",", "")

                results.append(
                    float(clean)
                )

            except:

                continue


        return results



    # ============================================================
    # RECEIPT LINE ITEM EXTRACTION
    # ============================================================

    def extract_items(self, ocr_lines):

        items = []

        for line in ocr_lines:

            numbers = self.extract_numbers(line)


            if not numbers:
                continue


            # remove obvious totals

            upper = line.upper()

            if any(
                word in upper
                for word in [
                    "TOTAL",
                    "SUBTOTAL",
                    "DISCOUNT",
                    "VAT",
                    "CHANGE",
                    "PAID"
                ]
            ):

                continue



            item = {

                "description": line.strip(),

                "amount": numbers[-1]

            }


            items.append(item)


        return items



    # ============================================================
    # PRICE LIST MATCHING ENGINE
    # ============================================================

    def match_price_item(
        self,
        description,
        price_list
    ):

        if not description:
            return None


        description_clean = (
            description
            .lower()
            .strip()
        )


        best_match = None
        highest_score = 0


        for item in price_list:


            name = (
                item.name
                .lower()
                .strip()
            )


            score = self.similarity_score(
                description_clean,
                name
            )


            if score > highest_score:

                highest_score = score

                best_match = item



        if highest_score >= 70:

            return {

                "matched": True,

                "item": best_match,

                "score": highest_score

            }


        return {

            "matched": False,

            "item": None,

            "score": highest_score

        }



    # ============================================================
    # TEXT SIMILARITY
    # ============================================================

    def similarity_score(
        self,
        text1,
        text2
    ):

        from difflib import SequenceMatcher


        return round(

            SequenceMatcher(

                None,

                text1,

                text2

            ).ratio()

            * 100

        )
