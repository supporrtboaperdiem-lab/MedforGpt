"""
Multimodal medical-claim extraction using the organization's local AI server.

The server is llama.cpp's OpenAI-compatible endpoint, hosting the Gemma
multimodal model.  This module deliberately keeps the URL in one obvious
place and also allows it to be overridden from .env/configuration.

This module uses the local multimodal Gemma/llama.cpp service as the sole
claim-document extraction engine. No OCR fallback is used.
"""

import base64
import json
import os
import re
from urllib.parse import urlparse
from decimal import Decimal, InvalidOperation
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional
import threading

from flask import current_app

import cv2
import requests

from app.services.document_image_loader import image_to_array
from app.services.document_pdf_renderer import pdf_to_images


# ============================================================================
# AI CONNECTION CONFIGURATION
#
# IMPORTANT:
#   There is intentionally NO hard-coded server URL or API key here.
#   Deployment values come from the OS environment first (for example
#   ~/.bash_profile). app/.env is only a dummy/local fallback.
#
#   OLLAMA_SERVER_URL = https://<your-tunnel>.trycloudflare.com
#   OLLAMA_API_KEY    = <your server API key>
#
# The application accepts either the base server URL or the full
# /v1/chat/completions URL and normalizes it automatically.
# ============================================================================

DEFAULT_OLLAMA_MODEL = "gemma-4-26B-A4B-it-Q4_K_M.gguf"

# Backwards-compatible exported names. Runtime requests use _ai_settings()
# so the values always come from the single .env configuration location.
OLLAMA_URL = os.getenv("OLLAMA_SERVER_URL", "").strip()
OLLAMA_API_KEY = os.getenv("OLLAMA_API_KEY", "").strip()
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", DEFAULT_OLLAMA_MODEL).strip()
OLLAMA_CONNECT_TIMEOUT = float(os.getenv("OLLAMA_CONNECT_TIMEOUT_SECONDS", "3"))
OLLAMA_READ_TIMEOUT = float(os.getenv("OLLAMA_READ_TIMEOUT_SECONDS", "0"))
OLLAMA_HEALTH_TIMEOUT = float(os.getenv("OLLAMA_HEALTH_TIMEOUT_SECONDS", "2"))
# Backwards-compatible export; runtime health requests use _ai_settings().
OLLAMA_HEALTH_URL = ""

# Reuse persistent HTTP/TLS connections independently in each extraction worker.
_HTTP_LOCAL = threading.local()


def _http_session():
    session = getattr(_HTTP_LOCAL, "session", None)
    if session is None:
        session = requests.Session()
        adapter = requests.adapters.HTTPAdapter(pool_connections=16, pool_maxsize=16, max_retries=0)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        _HTTP_LOCAL.session = session
    return session


def _normalize_ai_url(raw_url: str) -> str:
    """Normalize one administrator-supplied OpenAI-compatible server URL.

    Accepts:
      https://host
      https://host/
      https://host/v1
      https://host/v1/chat/completions

    Also repairs the common copy/paste typo ``http\\:/host`` so a bad
    environment value fails with a useful message instead of requests'
    opaque "No host supplied" error.
    """
    raw = str(raw_url or "").strip().strip('"').strip("'")
    if not raw:
        raise ValueError(
            "OLLAMA_SERVER_URL is empty. Set it in app/.env. "
            "For a Kaggle Cloudflare tunnel use the https://...trycloudflare.com URL."
        )

    # Never accept Markdown link syntax as a URL.
    if raw.startswith("[") and "](" in raw:
        raise ValueError(
            "OLLAMA_SERVER_URL contains Markdown link syntax. "
            "Use only the actual https://...trycloudflare.com URL in app/.env."
        )

    # Repair only obvious scheme copy/paste damage, including the exact
    # ``http\\:/host`` typo produced by some copy/paste/config edits.
    raw = re.sub(r"^(https?)\\:/+", r"\1://", raw, flags=re.I)
    raw = re.sub(r"^(https?)\\+:/+", r"\1://", raw, flags=re.I)

    if "://" not in raw:
        raw = "https://" + raw.lstrip("/")

    parsed = urlparse(raw)
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.netloc:
        raise ValueError(
            f"Invalid OLLAMA_SERVER_URL: {raw!r}. "
            "Use a real http(s) URL, normally the https://...trycloudflare.com URL."
        )

    # Strip query/fragment so credentials or routing parameters cannot
    # accidentally become part of the API endpoint.
    base = f"{parsed.scheme.lower()}://{parsed.netloc}"
    path = parsed.path.rstrip("/")

    if not path:
        return f"{base}/v1/chat/completions"
    if path == "/v1":
        return f"{base}/v1/chat/completions"
    if path.endswith("/v1/chat/completions"):
        return base + path
    return base + path + "/v1/chat/completions"


def _ai_settings(mode="standard"):
    """Read AI settings with the live OS environment as the authority.

    The AI endpoint is intentionally NOT cached in Flask config. This prevents
    a stale value from an earlier process/config load from surviving after the
    administrator changes ~/.bash_profile and starts a new process.

    Precedence:
      1. non-empty OS environment (OLLAMA_*)
      2. Flask config populated from app/.env
      3. module defaults
    """
    try:
        config_url = current_app.config.get("OLLAMA_SERVER_URL", "")
        config_key = current_app.config.get("OLLAMA_API_KEY", "")
        config_cpu_url = current_app.config.get("OLLAMA_CPU_SERVER_URL", "http://10.101.2.245:8080")
        config_cpu_key = current_app.config.get("OLLAMA_CPU_API_KEY", "")
        config_model = current_app.config.get("OLLAMA_MODEL", DEFAULT_OLLAMA_MODEL)
        config_health_timeout = current_app.config.get("OLLAMA_HEALTH_TIMEOUT_SECONDS", OLLAMA_HEALTH_TIMEOUT)
        config_connect_timeout = current_app.config.get("OLLAMA_CONNECT_TIMEOUT_SECONDS", OLLAMA_CONNECT_TIMEOUT)
        config_read_timeout = current_app.config.get("OLLAMA_READ_TIMEOUT_SECONDS", OLLAMA_READ_TIMEOUT)
        config_max_output = current_app.config.get("OLLAMA_MAX_OUTPUT_TOKENS", 768)
    except RuntimeError:
        config_url = config_key = ""
        config_cpu_url = "http://10.101.2.245:8080"
        config_cpu_key = ""
        config_model = DEFAULT_OLLAMA_MODEL
        config_health_timeout = OLLAMA_HEALTH_TIMEOUT
        config_connect_timeout = OLLAMA_CONNECT_TIMEOUT
        config_read_timeout = OLLAMA_READ_TIMEOUT
        config_max_output = 768

    # Read os.environ on EVERY request. Do not use the module-level OLLAMA_URL
    # as the primary source because that value is captured at import time.
    env_url = os.environ.get("OLLAMA_SERVER_URL", "").strip()
    env_key = os.environ.get("OLLAMA_API_KEY", "").strip()
    env_cpu_url = os.environ.get("OLLAMA_CPU_SERVER_URL", "").strip()
    env_cpu_key = os.environ.get("OLLAMA_CPU_API_KEY", "").strip()
    env_model = os.environ.get("OLLAMA_MODEL", "").strip()
    env_health = os.environ.get("OLLAMA_HEALTH_TIMEOUT_SECONDS", "").strip()
    env_connect = os.environ.get("OLLAMA_CONNECT_TIMEOUT_SECONDS", "").strip()
    env_read = os.environ.get("OLLAMA_READ_TIMEOUT_SECONDS", "").strip()
    env_max_output = os.environ.get("OLLAMA_MAX_OUTPUT_TOKENS", "").strip()

    selected_mode = str(mode or "standard").strip().lower()
    if selected_mode == "lite":
        configured_url = env_cpu_url or str(config_cpu_url or "http://10.101.2.245:8080").strip()
        configured_key = env_cpu_key or str(config_cpu_key or "").strip()
    else:
        configured_url = env_url or str(config_url or "").strip()
        configured_key = env_key or str(config_key or "").strip()
    configured_model = env_model or str(config_model or DEFAULT_OLLAMA_MODEL).strip()
    health_timeout = env_health or config_health_timeout
    connect_timeout = env_connect or config_connect_timeout
    read_timeout = env_read or config_read_timeout
    max_output_tokens = env_max_output or config_max_output

    url = _normalize_ai_url(configured_url)
    api_key = str(configured_key or "").strip()
    if api_key.lower().startswith("bearer "):
        api_key = api_key[7:].strip()

    headers = {"Accept": "application/json", "Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    root_url = url.split("/v1/", 1)[0].rstrip("/")
    return {
        "url": url,
        "root_url": root_url,
        "health_url": f"{root_url}/health",
        "model": str(configured_model or DEFAULT_OLLAMA_MODEL).strip(),
        "headers": headers,
        "health_timeout": float(health_timeout),
        "connect_timeout": float(connect_timeout),
        "read_timeout": float(read_timeout),
        "max_output_tokens": int(max_output_tokens),
        "has_api_key": bool(api_key),
    }


SYSTEM_PROMPT = r"""
You are a multimodal medical reimbursement extractor. Inspect the receipt image itself; never guess unreadable data.
Return ONLY valid JSON in the exact shape below.

Extract visible:
- institution: name, address, TIN, phone
- patient: name, MRN, patient_id
- employee: name, employee_id, employee_number, department, manager, office
- receipt: invoice/receipt/FS/reference/prescription numbers, receipt_date, transaction_date/time, currency, payment_method
- provider: doctor_name, license_number
- clinical: diagnosis, procedure_notes
- totals: subtotal, discount, tax, total, amount_paid, credit, change, balance
- every genuine medical expense line with service_name, service_code, category, quantity, unit_price, receipt_price, raw_text

DATE: visually inspect the whole receipt. Prefer an explicitly labelled receipt/invoice/issued date; otherwise use a clearly printed transaction date. Never use filename, file time or upload time.

EXPENSE RULES:
1. Never classify IDs, TIN/VAT, invoice/receipt/FS/reference/serial/item/account/registration numbers, dates, times, percentages, addresses, codes, names or headings as expenses.
2. Never classify TOTAL, SUBTOTAL, CREDIT, CHANGE, BALANCE, VAT/TAX or DISCOUNT as expenses.
3. receipt_price is the actual medical line total. Return all genuine medical lines.
4. The `service_name` MUST contain only the medical service/procedure/product name. Do NOT append quantity, unit price, line total, tax, or total to `service_name`.
5. Put a visible service code such as REG002 or LAB-001 in service_code, separately from service_name.
6. raw_text is only the relevant receipt row, not an OCR dump.
7. Preserve visible spelling; clean only obvious spacing artifacts. Missing fields are null/[].

JSON:
{
  "document": {
    "document_type": "PHARMACY_RECEIPT|HOSPITAL_RECEIPT|OPTICAL_RECEIPT|LAB_RECEIPT|MEDICAL_RECEIPT|OTHER",
    "institution": {"name": null, "address": null, "tin": null, "phone": null},
    "patient": {"name": null, "mrn": null, "patient_id": null},
    "employee": {"name": null, "employee_id": null, "employee_number": null, "department": null, "manager": null, "office": null},
    "receipt": {"invoice_number": null, "receipt_number": null, "fs_number": null, "reference_number": null, "prescription_number": null, "receipt_date": null, "transaction_date": null, "transaction_time": null, "currency": null, "payment_method": null},
    "provider": {"doctor_name": null, "license_number": null},
    "clinical": {"diagnosis": null, "procedure_notes": null},
    "totals": {"subtotal": null, "discount": null, "tax": null, "total": null, "amount_paid": null, "credit": null, "change": null, "balance": null},
    "relevant_notes": []
  },
  "items": [
    {"service_name": "string", "service_code": null, "category": "MEDICINE|MEDICAL_SERVICE|MEDICAL_MATERIAL|OPTICS|OTHER_MEDICAL", "quantity": null, "unit_price": null, "receipt_price": 0.00, "raw_text": "string"}
  ]
}
"""

USER_PROMPT = r"""
Analyze this medical receipt image. Identify institution, patient/employee, printed receipt metadata and totals, then every genuine medical expense line.
Perform a visual date check and return the printed receipt/invoice date when visible; transaction date is fallback only. Never use file/upload dates.
Keep service_name separate from codes and numeric columns. Use the final line total as receipt_price. Return null for unreadable fields and never invent data.
"""


class OllamaUnavailable(Exception):
    """Raised when the local multimodal AI server cannot be reached."""


class OllamaClaimExtractionService:
    """High-accuracy multimodal claim extraction with a strict JSON contract."""

    @classmethod
    def is_available(cls) -> bool:
        """Perform a fast readiness check, separate from AI inference.

        This endpoint is checked once by the claim batch before extraction.
        A failed health check means the AI path is unavailable. It does not
        wait for a model generation request.
        """
        try:
            settings = _ai_settings()
            response = _http_session().get(
                settings["health_url"],
                headers=settings["headers"],
                timeout=settings["health_timeout"],
            )
            return response.status_code == 200
        except (requests.RequestException, ValueError):
            return False

    @staticmethod
    def _image_to_data_url(image) -> str:
        """Convert an OpenCV BGR image to a compact JPEG data URL."""
        if image is None:
            raise ValueError("Empty receipt image")

        # Receipts benefit from a large enough image for the vision model, but
        # sending enormous phone photos wastes context/network bandwidth.
        height, width = image.shape[:2]
        max_dimension = 1800
        scale = min(1.0, max_dimension / float(max(height, width)))
        if scale < 1.0:
            image = cv2.resize(
                image,
                (int(width * scale), int(height * scale)),
                interpolation=cv2.INTER_AREA,
            )

        ok, encoded = cv2.imencode(
            ".jpg",
            image,
            [int(cv2.IMWRITE_JPEG_QUALITY), 88],
        )
        if not ok:
            raise ValueError("Unable to encode receipt image")

        payload = base64.b64encode(encoded.tobytes()).decode("ascii")
        return f"data:image/jpeg;base64,{payload}"

    @staticmethod
    def _extract_json_object(text: str) -> str:
        """Extract the first balanced JSON object from model output.

        Vision models occasionally prepend prose/markdown or append a short
        explanation even when explicitly asked for JSON.  A simple
        ``find('{')/rfind('}')`` is unsafe when braces occur inside quoted
        strings, so this scanner tracks strings and escapes.
        """
        start = text.find("{")
        if start < 0:
            raise ValueError("AI response did not contain a JSON object")

        depth = 0
        in_string = False
        escaped = False
        for index in range(start, len(text)):
            ch = text[index]
            if in_string:
                if escaped:
                    escaped = False
                elif ch == "\\":
                    escaped = True
                elif ch == '"':
                    in_string = False
                continue

            if ch == '"':
                in_string = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return text[start:index + 1]

        raise ValueError("AI response contained an incomplete JSON object")

    @staticmethod
    def _repair_common_json(text: str) -> str:
        """Repair harmless JSON-like syntax commonly emitted by LLMs.

        This deliberately handles only structural formatting problems. It does
        not invent missing business data or alter ordinary string values.
        """
        value = text.strip()

        # Remove // and /* */ comments outside quoted strings.
        out = []
        i = 0
        in_string = False
        escaped = False
        while i < len(value):
            ch = value[i]
            if in_string:
                out.append(ch)
                if escaped:
                    escaped = False
                elif ch == "\\":
                    escaped = True
                elif ch == '"':
                    in_string = False
                i += 1
                continue
            if ch == '"':
                in_string = True
                out.append(ch)
                i += 1
            elif ch == '/' and i + 1 < len(value) and value[i + 1] == '/':
                i += 2
                while i < len(value) and value[i] not in '\r\n':
                    i += 1
            elif ch == '/' and i + 1 < len(value) and value[i + 1] == '*':
                i += 2
                while i + 1 < len(value) and not (value[i] == '*' and value[i + 1] == '/'):
                    i += 1
                i = min(len(value), i + 2)
            else:
                out.append(ch)
                i += 1
        value = ''.join(out)

        # Quote JavaScript/Python-style bare object keys: {name: ...}.
        value = re.sub(
            r'([\{,]\s*)([A-Za-z_][A-Za-z0-9_\-]*)(\s*:)',
            r'\1"\2"\3',
            value,
        )
        # Remove trailing commas before } or ].
        value = re.sub(r',\s*([}\]])', r'\1', value)

        # Convert JavaScript JSON literals for the safe ast.literal_eval
        # fallback. Only tokens outside quoted strings are changed.
        value = re.sub(r'(?<![A-Za-z0-9_])null(?![A-Za-z0-9_])', 'None', value)
        value = re.sub(r'(?<![A-Za-z0-9_])true(?![A-Za-z0-9_])', 'True', value)
        value = re.sub(r'(?<![A-Za-z0-9_])false(?![A-Za-z0-9_])', 'False', value)
        return value

    @staticmethod
    def _escape_control_chars_in_json_strings(text: str) -> str:
        """Escape literal control characters inside double-quoted JSON strings.

        This can repair embedded newlines/tabs in a string value. It cannot
        reconstruct a response that was truncated before the string closed.
        """
        output = []
        in_string = False
        escaped = False

        for ch in text:
            if in_string:
                if escaped:
                    output.append(ch)
                    escaped = False
                elif ch == "\\":
                    output.append(ch)
                    escaped = True
                elif ch == '"':
                    output.append(ch)
                    in_string = False
                elif ch == "\n":
                    output.append("\\n")
                elif ch == "\r":
                    output.append("\\r")
                elif ch == "\t":
                    output.append("\\t")
                elif ord(ch) < 32:
                    output.append(" ")
                else:
                    output.append(ch)
            else:
                output.append(ch)
                if ch == '"':
                    in_string = True

        return "".join(output)

    @staticmethod
    def _parse_json(text: str) -> Dict[str, Any]:
        """Parse LLM JSON robustly while preserving strict business data.

        Gemma/llama.cpp can occasionally return JSON-like output containing
        markdown fences, leading prose, single-quoted keys/values, comments,
        bare keys, or trailing commas.  We try strict JSON first, then apply
        progressively safer syntax-only repairs.
        """
        text = (text or "").strip()
        if not text:
            raise ValueError("AI server returned an empty response")

        # Remove common markdown fences without changing the payload.
        text = re.sub(r"^\s*```(?:json)?\s*", "", text, flags=re.I)
        text = re.sub(r"\s*```\s*$", "", text)

        candidates = []
        try:
            candidates.append(text)
            extracted = OllamaClaimExtractionService._extract_json_object(text)
            if extracted != text:
                candidates.append(extracted)
        except ValueError:
            pass

        last_error = None
        for candidate in candidates:
            candidate = OllamaClaimExtractionService._escape_control_chars_in_json_strings(
                candidate
            )
            try:
                value = json.loads(candidate)
                if isinstance(value, dict):
                    return value
                raise ValueError("AI response JSON is not an object")
            except (json.JSONDecodeError, ValueError) as exc:
                last_error = exc

            # Python's literal parser safely handles the frequent LLM variant
            # using single quotes, True/False and None. It never executes code.
            try:
                import ast
                value = ast.literal_eval(candidate)
                if isinstance(value, dict):
                    return value
            except (ValueError, SyntaxError, TypeError) as exc:
                last_error = exc

            repaired = OllamaClaimExtractionService._repair_common_json(candidate)
            if repaired != candidate:
                try:
                    value = json.loads(repaired)
                    if isinstance(value, dict):
                        return value
                except (json.JSONDecodeError, ValueError) as exc:
                    last_error = exc
                try:
                    import ast
                    value = ast.literal_eval(repaired)
                    if isinstance(value, dict):
                        return value
                except (ValueError, SyntaxError, TypeError) as exc:
                    last_error = exc

        if last_error:
            # Keep parser failures within ValueError so _request_page can
            # handle them and perform its controlled corrective retry. In
            # particular, ast.literal_eval may raise SyntaxError for a broken
            # or truncated raw_text string.
            if isinstance(last_error, SyntaxError):
                raise ValueError(f"Malformed AI JSON: {last_error}") from last_error
            raise last_error
        raise ValueError("AI response did not contain a usable JSON object")

    @staticmethod
    def _decimal(value) -> Optional[Decimal]:
        if value is None or isinstance(value, bool):
            return None
        try:
            raw = str(value).strip().replace(",", "")
            if not raw:
                return None
            return Decimal(raw).quantize(Decimal("0.01"))
        except (InvalidOperation, ValueError):
            return None

    @classmethod
    def _normalize_document(cls, payload: Dict[str, Any], page: int) -> Dict[str, Any]:
        document = payload.get("document") if isinstance(payload.get("document"), dict) else {}
        raw_items = payload.get("items")
        if not isinstance(raw_items, list):
            raw_items = []

        receipt_section = document.get("receipt") if isinstance(document.get("receipt"), dict) else None
        if receipt_section is not None and not receipt_section.get("receipt_date"):
            # A clearly identified transaction date is preferable to losing
            # the document date entirely, but we never use upload/filename
            # timestamps as the printed receipt date.
            if receipt_section.get("transaction_date"):
                receipt_section["receipt_date"] = receipt_section.get("transaction_date")

        items: List[Dict[str, Any]] = []
        seen = set()
        for raw in raw_items:
            if not isinstance(raw, dict):
                continue
            service_name = str(raw.get("service_name") or "").strip()
            description = str(raw.get("raw_text") or service_name).strip()
            price = cls._decimal(raw.get("receipt_price"))
            unit_price = cls._decimal(raw.get("unit_price"))
            quantity_raw = raw.get("quantity")
            # OCR models occasionally return a unit price or a partially read
            # amount instead of the printed line total. Correct it only when
            # the quantity × unit-price total is explicitly visible in this
            # line's raw text; never infer a higher amount from arithmetic alone.
            quantity_match = re.match(r"\s*(\d+(?:[.,]\d+)?)", str(quantity_raw or ""))
            if quantity_match and unit_price is not None and unit_price > 0:
                try:
                    quantity = Decimal(quantity_match.group(1).replace(",", "."))
                    line_total = (quantity * unit_price).quantize(Decimal("0.01"))
                    visible_numbers = {
                        Decimal(token.replace(",", "").replace(" ", "")).quantize(Decimal("0.01"))
                        for token in re.findall(r"(?<![A-Za-z])\d[\d, ]*(?:\.\d{1,2})?", description)
                        if token.strip()
                    }
                    if quantity > 0 and line_total in visible_numbers and price != line_total:
                        price = line_total
                except (InvalidOperation, ValueError):
                    pass
            if not service_name or price is None or abs(price) > Decimal("1000000"):
                continue
            key = (re.sub(r"\s+", " ", service_name.lower()), price, re.sub(r"\s+", " ", description.lower()))
            if key in seen:
                continue
            seen.add(key)
            items.append({
                "service_name": service_name,
                "service_code": str(raw.get("service_code") or "").strip() or None,
                "receipt_price": price,
                "raw_text": description,
                "category": str(raw.get("category") or "OTHER_MEDICAL").strip(),
                "quantity": raw.get("quantity"),
                "unit_price": unit_price if unit_price is not None else raw.get("unit_price"),
                "page": page,
            })

        return {"document": document, "items": items}

    @classmethod
    def _request_page(cls, image, page: int, mode="standard") -> List[Dict[str, Any]]:
        image_url = cls._image_to_data_url(image)

        # Load AI configuration before constructing the payload.
        # This must happen before any reference to `settings`; otherwise
        # Python treats settings as a local variable and raises
        # UnboundLocalError when building the model field.
        settings = _ai_settings(mode)
        request_timeout = (
            settings["connect_timeout"],
            settings["read_timeout"] if settings["read_timeout"] > 0 else None,
        )

        payload = {
            "model": settings["model"],
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": USER_PROMPT},
                        {
                            "type": "image_url",
                            "image_url": {"url": image_url},
                        },
                    ],
                },
            ],
            "temperature": 0,
            # Gemma 4 is a reasoning model. With the previous 1400-token
            # budget, the model could spend the entire budget thinking and
            # return an empty message.content. Explicitly request a
            # final-answer-only response and leave enough generation budget
            # for the structured JSON payload.
            "reasoning_effort": "none",
            "reasoning_format": "none",
            "chat_template_kwargs": {"enable_thinking": False},
            "max_tokens": settings["max_output_tokens"],
            "response_format": {"type": "json_object"},
            "stream": False,
        }

        last_error = None
        # First request asks the server to constrain output to JSON. If the
        # model nevertheless emits malformed JSON, perform one corrective
        # extraction pass against the same image.
        for attempt in range(2):
            current_payload = dict(payload)
            if attempt == 1:
                current_payload.pop("response_format", None)
                current_payload["messages"] = list(payload["messages"]) + [{
                    "role": "user",
                    "content": (
                        "Your previous response was not valid JSON. Re-analyze the same receipt "
                        "and return ONLY one syntactically valid JSON object matching the exact "
                        "schema requested above. Do not use markdown fences, comments, single quotes, "
                        "trailing commas, or explanatory text. Do not change or invent facts; "
                        "use null for unreadable or missing fields."
                    ),
                }]

            try:
                response = _http_session().post(
                    settings["url"],
                    json=current_payload,
                    headers=settings["headers"],
                    timeout=request_timeout,
                )
            except requests.RequestException as exc:
                raise OllamaUnavailable(str(exc)) from exc

            if response.status_code >= 500:
                raise OllamaUnavailable(
                    f"AI server HTTP {response.status_code}: {response.text[:300]}"
                )
            if response.status_code >= 400:
                if response.status_code in (401, 403):
                    key_hint = (
                        "An API key was sent; verify OLLAMA_API_KEY in the OS environment."
                        if settings["has_api_key"]
                        else "No API key was sent; set OLLAMA_API_KEY in the OS environment if the server requires one."
                    )
                    raise OllamaUnavailable(
                        f"AI server rejected authentication (HTTP {response.status_code}). {key_hint} "
                        f"Server response: {response.text[:300]}"
                    )
                if attempt == 0 and response.status_code in (400, 404, 422):
                    last_error = RuntimeError(
                        f"AI server HTTP {response.status_code}: {response.text[:300]}"
                    )
                    continue
                raise RuntimeError(
                    f"AI server HTTP {response.status_code}: {response.text[:500]}"
                )

            try:
                body = response.json()
                choices = body.get("choices") or []
                if not choices:
                    raise ValueError("No choices in AI response")
                message = choices[0].get("message") or {}
                finish_reason = choices[0].get("finish_reason")
                content = message.get("content")
                if isinstance(content, list):
                    parts = []
                    for part in content:
                        if isinstance(part, dict):
                            value = part.get("text") or part.get("content")
                            if value:
                                parts.append(str(value))
                        elif isinstance(part, str):
                            parts.append(part)
                    content = "\n".join(parts)
                if not content:
                    content = choices[0].get("text")
            except (ValueError, KeyError, IndexError, TypeError) as exc:
                last_error = exc
                if attempt == 0:
                    continue
                raise OllamaUnavailable(
                    f"AI server returned an invalid/empty response structure: {exc}"
                ) from exc

            if not str(content or "").strip():
                last_error = ValueError("AI server returned an empty response")
                if attempt == 0:
                    continue
                raise OllamaUnavailable(
                    "AI server returned an empty response after the server health check"
                )

            # A finish_reason of "length" means the model stopped at its output
            # token limit. Retry once with a larger budget instead of attempting
            # to parse incomplete JSON or guessing missing service/price data.
            if finish_reason == "length":
                last_error = ValueError(
                    "AI response was truncated at the generation token limit. "
                    "Increase OLLAMA_MAX_OUTPUT_TOKENS and ensure llama.cpp's "
                    "--n-predict limit is high enough."
                )
                if attempt == 0:
                    payload["max_tokens"] = min(
                        max(int(settings["max_output_tokens"]) * 2, 1536),
                        3072,
                    )
                    continue
                raise OllamaUnavailable(str(last_error))

            try:
                result = cls._parse_json(str(content))
                return cls._normalize_document(result, page)
            except (ValueError, json.JSONDecodeError) as exc:
                last_error = exc
                if attempt == 0:
                    continue
                raise OllamaUnavailable(
                    f"AI server returned unusable extraction JSON after retry: {exc}"
                ) from exc

        raise OllamaUnavailable(f"AI extraction failed: {last_error}")

    @staticmethod
    def _normalize_date_value(value: Any) -> Optional[str]:
        """Normalize a visibly extracted receipt date to YYYY-MM-DD.

        Receipt dates arrive from vision models in many forms, sometimes with a
        time attached.  We deliberately try explicit day-first formats before
        month-first formats because the reimbursement system primarily handles
        local receipts using DD/MM/YYYY notation.
        """
        if value in (None, ""):
            return None
        raw = str(value).strip().replace("T", " ").replace("Z", "")
        raw = re.sub(r"\s+", " ", raw)
        # Remove common labels that a vision model may accidentally include.
        raw = re.sub(r"^(receipt|invoice|transaction|issued|date)\s*[:#-]?\s*", "", raw, flags=re.I)
        candidates = [raw]
        # Also test individual date-looking substrings from the model response.
        candidates.extend(re.findall(
            r"\b\d{1,4}[./-]\d{1,2}[./-]\d{1,4}(?:\s+\d{1,2}:\d{2}(?::\d{2})?)?\b",
            raw,
        ))
        month_pattern = r"\b\d{1,2}\s+(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+\d{4}\b"
        candidates.extend(re.findall(month_pattern, raw, flags=re.I))
        formats = (
            "%Y-%m-%d", "%Y/%m/%d", "%Y.%m.%d",
            "%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y",
            "%m/%d/%Y", "%m-%d-%Y", "%m.%d.%Y",
            "%d %B %Y", "%d %b %Y",
        )
        for candidate in candidates:
            candidate = candidate.strip().rstrip(".,;:")
            for fmt in formats:
                try:
                    return datetime.strptime(candidate[:19], fmt).date().isoformat()
                except ValueError:
                    continue
            # ISO/datetime values with a time component.
            try:
                return datetime.fromisoformat(candidate.replace(" ", "T", 1)).date().isoformat()
            except ValueError:
                pass
        return None

    @staticmethod
    def _date_probe_variants(image):
        """Build high-contrast date-focused views without changing the source file."""
        if image is None:
            return []
        height, width = image.shape[:2]
        regions = [
            image,
            image[: max(1, int(height * 0.68)), :],
            image[: max(1, int(height * 0.72)), int(width * 0.35):],
            image[int(height * 0.12): max(int(height * 0.78), int(height * 0.13)), int(width * 0.05): int(width * 0.95)],
        ]
        variants = []
        for region in regions:
            if region is None or region.size == 0:
                continue
            gray = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)
            # Upscale small receipt text and increase local contrast.  This is
            # particularly useful for camera photos where the printed date is
            # tiny or slightly out of focus.
            scale = max(1.0, min(3.0, 1800.0 / max(gray.shape)))
            if scale > 1.0:
                gray = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
            clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8)).apply(gray)
            blurred = cv2.GaussianBlur(clahe, (0, 0), 1.0)
            sharp = cv2.addWeighted(clahe, 1.7, blurred, -0.7, 0)
            variants.append(cv2.cvtColor(sharp, cv2.COLOR_GRAY2BGR))
        return variants

    @classmethod
    def _request_date_probe(cls, image, mode="standard") -> Optional[str]:
        """Run a second, date-only visual pass when the main extraction misses it."""
        variants = cls._date_probe_variants(image)
        if not variants:
            return None
        settings = _ai_settings(mode)
        content = [{
            "type": "text",
            "text": (
                "DATE-ONLY RECEIPT INSPECTION. These images are views of the same medical receipt. "
                "Find the date that is physically printed on the document. Inspect the ENTIRE visible "
                "receipt, especially labels such as Receipt Date, Invoice Date, Date, Issued Date, "
                "Payment Date, Transaction Date. Return the clearest printed date you can actually see. "
                "Do not use the image filename, file metadata, today's date, or upload time. Do not guess. "
                "If the receipt has both a payment/transaction date and another explicit receipt/invoice date, "
                "use the explicit receipt/invoice date. Return the exact visible date string as raw_text and "
                "also normalize it to YYYY-MM-DD when certain. Return ONLY JSON: "
                '{"receipt_date":"YYYY-MM-DD or null","transaction_date":"YYYY-MM-DD or null",'
                '"raw_text":"exact visible date text or null","confidence":"high|medium|low"}'
            ),
        }]
        for variant in variants[:2]:
            content.append({"type": "image_url", "image_url": {"url": cls._image_to_data_url(variant)}})
        payload = {
            "model": settings["model"],
            "messages": [
                {"role": "system", "content": "You are a receipt date-reading specialist. Never invent a date."},
                {"role": "user", "content": content},
            ],
            "temperature": 0,
            "reasoning_effort": "none",
            "reasoning_format": "none",
            "chat_template_kwargs": {"enable_thinking": False},
            "max_tokens": 128,
            "response_format": {"type": "json_object"},
            "stream": False,
        }
        try:
            response = _http_session().post(
                settings["url"], json=payload, headers=settings["headers"],
                timeout=(settings["connect_timeout"], settings["read_timeout"] if settings["read_timeout"] > 0 else None),
            )
            if response.status_code >= 400:
                return None
            body = response.json()
            choices = body.get("choices") or []
            if not choices:
                return None
            message = choices[0].get("message") or {}
            raw_content = message.get("content") or choices[0].get("text")
            if isinstance(raw_content, list):
                raw_content = "\n".join(str(x.get("text") or x.get("content") or "") for x in raw_content if isinstance(x, dict))
            if not raw_content:
                return None
            result = cls._parse_json(str(raw_content))
            confidence = str(result.get("confidence") or "").lower()
            normalized = cls._normalize_date_value(result.get("receipt_date"))
            if normalized:
                return normalized
            normalized = cls._normalize_date_value(result.get("transaction_date"))
            if normalized:
                return normalized
            # A raw visible date is acceptable only when the model marks it
            # medium/high confidence; normalization still rejects nonsense.
            if confidence in {"high", "medium"}:
                return cls._normalize_date_value(result.get("raw_text"))
        except Exception:
            return None
        return None

    @classmethod
    def compare_service_candidates(
        cls, file_path: str, *, service_name: str, raw_text: str,
        service_code: str, candidates: List[Dict[str, Any]], mode="standard",
    ) -> Optional[Dict[str, Any]]:
        """Use receipt vision to choose only among supplied approved services.

        Returns None unless the model selects a valid candidate with high
        confidence. This is an adjudication step, not a source of new prices.
        """
        if not candidates or len(candidates) > 12:
            return None
        path = Path(file_path)
        pages = pdf_to_images(str(path)) if path.suffix.lower() == ".pdf" else [image_to_array(str(path))]
        if not pages:
            return None
        image_url = cls._image_to_data_url(pages[0])
        settings = _ai_settings(mode)
        allowed = []
        for index, candidate in enumerate(candidates):
            if not isinstance(candidate, dict) or not candidate.get("service_name") or candidate.get("approved_price") is None:
                continue
            allowed.append({
                "candidate_id": index,
                "service_name": str(candidate["service_name"]),
                "approved_price": str(candidate["approved_price"]),
            })
        if not allowed:
            return None
        prompt = (
            "Identify which listed approved service, if any, matches the specific receipt line. "
            "Inspect receipt image layout and line boundaries; do not use price alone. "
            "Do not assign a neighboring row's code to this line. Distinguish combined tests "
            "from individual tests, profiles from injections, and ultrasound from X-ray. "
            "Choose only a candidate_id below. If evidence is insufficient, return null. "
            "Return JSON only with candidate_id (integer or null), confidence (0-100), and reason.\n"
            f"Extracted service name: {service_name}\nRaw receipt line: {raw_text}\n"
            f"Extracted code (may be OCR noise): {service_code}\n"
            f"Approved candidates: {json.dumps(allowed, ensure_ascii=False)}"
        )
        payload = {
            "model": settings["model"],
            "messages": [{"role": "system", "content": "You are a cautious medical receipt line-matching assistant. Never invent candidates."},
                         {"role": "user", "content": [{"type": "text", "text": prompt},
                                                          {"type": "image_url", "image_url": {"url": image_url}}]}],
            "temperature": 0,
            "reasoning_effort": "none",
            "reasoning_format": "none",
            "chat_template_kwargs": {"enable_thinking": False},
            "max_tokens": min(max(int(settings["max_output_tokens"]), 256), 768),
            "response_format": {"type": "json_object"},
            "stream": False,
        }
        timeout = (settings["connect_timeout"], settings["read_timeout"] if settings["read_timeout"] > 0 else None)
        response = _http_session().post(settings["url"], json=payload, headers=settings["headers"], timeout=timeout)
        if response.status_code >= 400:
            raise OllamaUnavailable(f"AI candidate comparison HTTP {response.status_code}: {response.text[:250]}")
        body = response.json()
        choices = body.get("choices") or []
        if not choices:
            return None
        message = choices[0].get("message") or {}
        content = message.get("content") or choices[0].get("text") or ""
        if isinstance(content, list):
            content = "\n".join(str(part.get("text") or "") for part in content if isinstance(part, dict))
        result = cls._parse_json(str(content))
        candidate_id = result.get("candidate_id")
        confidence = float(result.get("confidence", 0) or 0)
        if candidate_id is None or isinstance(candidate_id, bool) or confidence < 85:
            return None
        if not isinstance(candidate_id, int):
            try:
                candidate_id = int(candidate_id)
            except (ValueError, TypeError):
                return None
        candidate = next((c for c in allowed if c["candidate_id"] == candidate_id), None)
        if candidate is None:
            return None
        return {"service_name": candidate["service_name"], "approved_price": candidate["approved_price"],
                "confidence": confidence, "reason": str(result.get("reason") or "")[:300]}

    @classmethod
    def extract_document(cls, file_path: str, mode="standard") -> Dict[str, Any]:
        """Extract complete structured reimbursement data from an image/PDF."""
        path = Path(file_path)
        if path.suffix.lower() == ".pdf":
            pages = pdf_to_images(str(path))
        else:
            pages = [image_to_array(str(path))]

        documents = []
        all_items: List[Dict[str, Any]] = []
        for page_number, page in enumerate(pages, start=1):
            result = cls._request_page(page, page_number, mode=mode)
            documents.append(result.get("document") or {})
            all_items.extend(result.get("items") or [])

        # Merge document sections across pages without throwing away fields.
        merged: Dict[str, Any] = {}
        for doc in documents:
            if not isinstance(doc, dict):
                continue
            for section, value in doc.items():
                if isinstance(value, dict):
                    target = merged.setdefault(section, {})
                    for key, val in value.items():
                        if val not in (None, "", []):
                            target[key] = val
                elif value not in (None, "", []):
                    merged[section] = value

        # The date is business-critical and must not depend on the model
        # noticing it during the broad extraction pass.  If that pass missed
        # it, run a dedicated high-contrast, date-only visual inspection.
        receipt_section = merged.setdefault("receipt", {})
        if not cls._normalize_date_value(receipt_section.get("receipt_date")):
            for page in pages:
                date_value = cls._request_date_probe(page, mode=mode)
                if date_value:
                    receipt_section["receipt_date"] = date_value
                    break
        else:
            receipt_section["receipt_date"] = cls._normalize_date_value(receipt_section.get("receipt_date"))

        # If the explicit receipt date remains unavailable, a clearly printed
        # transaction date is the documented fallback; upload time is NEVER
        # substituted for the printed date.
        if not receipt_section.get("receipt_date") and receipt_section.get("transaction_date"):
            fallback = cls._normalize_date_value(receipt_section.get("transaction_date"))
            if fallback:
                receipt_section["receipt_date"] = fallback

        unique: List[Dict[str, Any]] = []
        seen = set()
        for item in all_items:
            key = (re.sub(r"\s+", " ", item["service_name"].lower()), item["receipt_price"])
            if key in seen:
                continue
            seen.add(key)
            unique.append(item)

        return {"document": merged, "items": unique}

    @classmethod
    def extract_items(cls, file_path: str) -> List[Dict[str, Any]]:
        """Backward-compatible item-only API."""
        return cls.extract_document(file_path)["items"]


__all__ = [
    "OllamaClaimExtractionService",
    "OllamaUnavailable",
    "OLLAMA_URL",
    "OLLAMA_API_KEY",
    "OLLAMA_MODEL",
    "OLLAMA_HEALTH_URL",
    "OLLAMA_HEALTH_TIMEOUT",
]
