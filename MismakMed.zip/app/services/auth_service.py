# ============================================================
# FILE:
# D:\Medical\MedicalReimbursementSystem\app\services\auth_service.py
# ============================================================

from datetime import datetime
import os

from flask import flash, redirect, render_template, session, url_for

from app.extensions import db
from app.models.role import Role
from app.models.user import User
from flask_login import login_user, logout_user, current_user
from app.models.user import User
from app.services.mail_service import (
    send_login_notification,
    send_account_creation_notification,
    send_role_submission_notification,
    send_role_decision_notification,
    send_account_status_notification,
)


class AuthService:

    # ========================================================
    # LOGIN
    # ========================================================

    @staticmethod
    def login(
        email,
        password,
        ip_address=None,
        user_agent=None
    ):

        import platform
        import re
        import smtplib

        from email.message import EmailMessage

        email = (
            email or ""
        ).strip().lower()

        password = (
            password or ""
        )

        if not email or not password:

            return (
                False,
                "Email and password are required."
            )

        user = (
            User.query
            .filter(
                User.email == email
            )
            .first()
        )

        if not user:

            return (
                False,
                "Invalid email or password."
            )

        # BOA Employee/HR accounts authenticate against Active Directory.
        role_name_for_auth = (getattr(user, "role_name", "") or "").strip().lower()
        if role_name_for_auth in {"employee", "hr"}:
            from app.services.ldap_service import authenticate_user
            ldap_ok, ldap_user, ldap_message = authenticate_user(email, password)
            if not ldap_ok:
                return False, "Invalid BOA LDAP username or password."
            # Synchronize authoritative directory identity details.
            user.username = ldap_user.get("username") or user.username
            user.email = (ldap_user.get("email") or email).lower()
        elif not user.check_password(password):
            return False, "Invalid email or password."

        if not user.is_active:

            return (
                False,
                "Your account is disabled."
            )

        # ========================================================
        # DEVICE / BROWSER INFORMATION
        # ========================================================

        user_agent = (
            user_agent
            or "Unknown"
        )

        ip_address = (
            ip_address
            or "Unknown"
        )

        # --------------------------------------------------------
        # BROWSER
        # --------------------------------------------------------

        if "Edg/" in user_agent:
            browser = "Microsoft Edge"

        elif "Chrome/" in user_agent:
            browser = "Google Chrome"

        elif "Firefox/" in user_agent:
            browser = "Mozilla Firefox"

        elif "Safari/" in user_agent:
            browser = "Safari"

        elif "OPR/" in user_agent:
            browser = "Opera"

        else:
            browser = "Unknown Browser"

        # --------------------------------------------------------
        # OPERATING SYSTEM
        # --------------------------------------------------------

        if "Windows NT 10.0" in user_agent:
            operating_system = "Windows 10/11"

        elif "Windows NT 6.3" in user_agent:
            operating_system = "Windows 8.1"

        elif "Windows NT 6.2" in user_agent:
            operating_system = "Windows 8"

        elif "Windows NT 6.1" in user_agent:
            operating_system = "Windows 7"

        elif "Android" in user_agent:
            operating_system = "Android"

        elif "iPhone" in user_agent:
            operating_system = "iOS (iPhone)"

        elif "iPad" in user_agent:
            operating_system = "iOS (iPad)"

        elif "Mac OS X" in user_agent:
            operating_system = "macOS"

        elif "Linux" in user_agent:
            operating_system = "Linux"

        else:
            operating_system = "Unknown OS"

        # --------------------------------------------------------
        # DEVICE
        # --------------------------------------------------------

        if "Mobile" in user_agent:
            device = "Mobile Device"

        elif "Tablet" in user_agent or "iPad" in user_agent:
            device = "Tablet"

        else:
            device = "Desktop / Laptop"

        # ========================================================
        # FLASK-LOGIN
        # ========================================================

        login_user(user)

        session["user_id"] = user.id
        session["username"] = user.username

        if hasattr(
            user,
            "role_name"
        ):
            session["role"] = user.role_name

        # ========================================================
        # LOGIN TIME
        # ========================================================

        login_time = datetime.utcnow()

        # ========================================================
        # ROLE
        # ========================================================

        role_name = getattr(
            user,
            "role_name",
            "Unknown"
        )

        # ========================================================
        # LOGIN NOTIFICATION — BOA SMTP
        # ========================================================
        try:
            from app.services.mail_service import send_login_notification
            send_login_notification(user)
        except Exception as exc:
            print("[LOGIN MAIL][ERROR]", exc, flush=True)

        # ========================================================
        # LOGIN AUDIT
        # ========================================================

        try:

            from app.services.audit_service import (
                AuditService
            )

            AuditService.record(
                action="LOGIN_SUCCESS",
                entity_type="USER",
                entity_id=user.id,
                description=(
                    f"User {user.email} logged in."
                ),
                user=user
            )

            AuditService.commit()

        except Exception as e:

            print(
                "[AUDIT] Login audit failed:",
                repr(e)
            )


        return (
            True,
            "Login successful."
        )
    '''@staticmethod
    def login(username, password):

        username = (
            username or ""
        ).strip()

        password = (
            password or ""
        )

        if not username:

            return False, "Username is required."

        if not password:

            return False, "Password is required."

        user = User.query.filter_by(
            username=username
        ).first()

        if not user:

            return False, "Invalid username or password."

        if not user.verify_password(password):

            return False, "Invalid username or password."

        if not user.is_active:
            flash(
                "Your account is disabled.",
                "danger"
            )
            return redirect(
                url_for("auth.login")
            )

        if (
            user.role_requires_approval
            and user.role_approval_status == "PENDING"
        ):
            return render_template(
                "auth/pending_role.html",
                user=user
            )

        if (
            user.role_requires_approval
            and user.role_approval_status == "REJECTED"
        ):
            return render_template(
                "auth/rejected_role.html",
                user=user
            )

        if not user.role_is_approved:

            if user.role_is_pending:

                return (
                    False,
                    "Your role is awaiting Administrator approval."
                )

            if user.role_is_rejected:

                return (
                    False,
                    "Your role request has been rejected."
                )

            return (
                False,
                "Your account is not approved."
            )

        session.clear()

        session["user_id"] = user.id

        session["username"] = user.username

        session["role"] = user.role_name

        return (
            True,
            f"Welcome, {user.full_name}."
        )'''
    

    # ========================================================
    # LOGOUT
    # ========================================================

    from flask_login import login_user, logout_user, current_user
    @staticmethod
    def logout():

        logout_user()
        session.clear()

    # ========================================================
    # CURRENT USER
    # ========================================================

    @staticmethod
    def current_user():

        user_id = session.get(
            "user_id"
        )

        if not user_id:

            return None

        return User.query.get(
            user_id
        )

    # ========================================================
    # LIST USERS
    # ========================================================

    @staticmethod
    def list_users():

        return (
            User.query
            .join(Role)
            .order_by(
                User.created_at.desc()
            )
            .all()
        )

    # ========================================================
    # GET USER
    # ========================================================

    @staticmethod
    def get_user(user_id):

        return User.query.get(
            user_id
        )

    # ========================================================
    # CREATE USER
    # ========================================================

    '''@staticmethod
    def create_user(
        username,
        full_name,
        email,
        password,
        role_name
    ):

        username = (
            username or ""
        ).strip()

        full_name = (
            full_name or ""
        ).strip()

        email = (
            email or ""
        ).strip()

        password = (
            password or ""
        )

        role_name = (
            role_name or ""
        ).strip()

        if not username:

            return False, "Username is required."

        if not full_name:

            return False, "Full name is required."

        if not email:

            return False, "Email is required."

        if not password:

            return False, "Password is required."

        if not role_name:

            return False, "Role is required."

        existing_username = User.query.filter_by(
            username=username
        ).first()

        if existing_username:

            return False, "Username already exists."

        existing_email = User.query.filter_by(
            email=email
        ).first()

        if existing_email:

            return False, "Email already exists."

        role = Role.query.filter_by(
            name=role_name
        ).first()

        if not role:

            return False, "Selected role does not exist."

        user = User(
            username=username,
            full_name=full_name,
            email=email,
            role_id=role.id,
            is_active=True
        )

        user.set_password(
            password
        )

        # ----------------------------------------------------
        # EMPLOYEE = AUTOMATIC APPROVAL
        # ----------------------------------------------------

        if role.name.lower() == "employee":

            user.role_approval_status = (
                "APPROVED"
            )

            user.role_approved_at = (
                datetime.utcnow()
            )

        # ----------------------------------------------------
        # ALL OTHER ROLES = ADMIN APPROVAL
        # ----------------------------------------------------

        else:

            user.role_approval_status = (
                "PENDING"
            )

        db.session.add(user)

        db.session.commit()

        if role.name.lower() == "employee":

            return (
                True,
                "Employee account created and automatically approved."
            )

        return (
            True,
            f"{role.name} account created and is awaiting Administrator approval."
        )
'''
    @staticmethod
    def create_user(
        username,
        full_name,
        email,
        password,
        role_name
    ):
        username = (username or "").strip()
        full_name = (full_name or "").strip()
        email = (email or "").strip().lower()
        password = password or ""
        role_name = (role_name or "").strip()

        if not username:
            return False, "Username is required."
        if not full_name:
            return False, "Full name is required."
        if not email:
            return False, "Email is required."
        if not password:
            return False, "Password is required."
        if len(password) < 6:
            return False, "Password must be at least 6 characters."
        if not role_name:
            return False, "Role is required."

        role = Role.query.filter(Role.name.ilike(role_name)).first()
        if not role:
            return False, "Selected role does not exist."

        if role.name.strip().lower() in {"employee", "hr"} and not email.endswith("@bankofabyssinia.com"):
            return False, "Employee and HR accounts must use a @bankofabyssinia.com email address."

        if User.query.filter_by(username=username).first():
            return False, "Username already exists."
        if User.query.filter_by(email=email).first():
            return False, "Email already exists."

        user = User(
            username=username,
            full_name=full_name,
            email=email,
            role_id=role.id,
            is_active=True
        )
        user.set_password(password)

        if role.name.strip().lower() == "employee":
            user.role_approval_status = "APPROVED"
            user.role_status = "APPROVED"
            user.role_requested_at = None
            user.role_approved_at = datetime.utcnow()
        else:
            user.role_approval_status = "PENDING"
            user.role_status = "PENDING"
            user.role_requested_at = datetime.utcnow()

        db.session.add(user)
        db.session.commit()

        try:
            send_account_creation_notification(user, created_by=current_user if current_user.is_authenticated else None)
            if user.role_approval_status == "PENDING":
                send_role_submission_notification(user)
        except Exception as exc:
            print("[MAIL][ACCOUNT-CREATION][ERROR]", repr(exc))

        return True, "User created successfully."

    # ========================================================
    # ENABLE
    # ========================================================

    @staticmethod
    def enable_user(user, administrator=None):
        user.is_active = True
        db.session.commit()
        try:
            send_account_status_notification(user, administrator or user, True)
        except Exception as exc:
            print("[MAIL][ACCOUNT-STATUS][ERROR]", repr(exc))

    # ========================================================
    # DISABLE
    # ========================================================

    @staticmethod
    def disable_user(user, administrator=None):
        user.is_active = False
        db.session.commit()
        try:
            send_account_status_notification(user, administrator or user, False)
        except Exception as exc:
            print("[MAIL][ACCOUNT-STATUS][ERROR]", repr(exc))

    # ========================================================
    # APPROVE ROLE
    # ========================================================

    @staticmethod
    def approve_role(
        user,
        administrator
    ):

        if not user:

            return False, "User not found."

        if user.role_is_approved:

            return False, "This role is already approved."

        if user.role_is_rejected:

            return False, "This role has already been rejected."

        if user.is_employee:

            user.role_approval_status = (
                "APPROVED"
            )

            user.role_approved_by = (
                administrator.id
            )

            user.role_approved_at = (
                datetime.utcnow()
            )

            user.role_rejection_reason = None

            user.role_status = "APPROVED"
            db.session.commit()
            try:
                send_role_decision_notification(user, administrator, True)
            except Exception as exc:
                print("[MAIL][ROLE-APPROVAL][ERROR]", repr(exc))

            return (
                True,
                "Employee role approved."
            )

        user.role_approval_status = (
            "APPROVED"
        )
        user.role_status = "APPROVED"

        user.role_approved_by = (
            administrator.id
        )

        user.role_approved_at = (
            datetime.utcnow()
        )

        user.role_rejection_reason = None

        db.session.commit()

        try:
            send_role_decision_notification(user, administrator, True)
        except Exception as exc:
            print("[MAIL][ROLE-APPROVAL][ERROR]", repr(exc))

        return (
            True,
            f"{user.role_name} role approved."
        )

    # ========================================================
    # REJECT ROLE
    # ========================================================

    @staticmethod
    def reject_role(
        user,
        administrator,
        reason
    ):

        if not user:

            return False, "User not found."

        if user.role_is_approved:

            return False, "This role is already approved."

        if user.is_employee:

            return (
                False,
                "Employee roles do not require approval."
            )

        reason = (
            reason or ""
        ).strip()

        if not reason:

            return (
                False,
                "A rejection reason is required."
            )

        user.role_approval_status = (
            "REJECTED"
        )

        user.role_rejected_by = (
            administrator.id
        )

        user.role_rejected_at = (
            datetime.utcnow()
        )

        user.role_status = "REJECTED"

        user.role_rejection_reason = (
            reason
        )

        # Notify before deletion because the email needs the user's data.
        try:
            send_role_decision_notification(user, administrator, False, reason=reason)
        except Exception as exc:
            print("[MAIL][ROLE-REJECTION][ERROR]", repr(exc))

        # Permanently remove all medical claims submitted by this user and
        # their uploaded receipt files. Claim items are cascade-deleted.
        from app.models.claim import MedicalClaim
        claims = MedicalClaim.query.filter(
            MedicalClaim.submitted_by_id == user.id
        ).all()

        receipt_paths = []
        for claim in claims:
            legacy = getattr(claim, "receipt_file_path", None)
            if legacy:
                receipt_paths.append(legacy)
            for receipt in getattr(claim, "receipts", []) or []:
                if getattr(receipt, "file_path", None):
                    receipt_paths.append(receipt.file_path)

        for claim in claims:
            db.session.delete(claim)

        # Clear self-referencing approval/rejection links before deleting
        # the rejected user so the database cannot retain a foreign key to it.
        User.query.filter(User.role_approved_by == user.id).update(
            {User.role_approved_by: None},
            synchronize_session=False,
        )
        User.query.filter(User.role_rejected_by == user.id).update(
            {User.role_rejected_by: None},
            synchronize_session=False,
        )

        db.session.delete(user)
        db.session.commit()

        for receipt_path in receipt_paths:
            if receipt_path and os.path.isfile(receipt_path):
                try:
                    os.remove(receipt_path)
                except OSError as exc:
                    print("[USER][REJECT-CLEANUP][ERROR]", repr(exc))

        return (
            True,
            f"{user.role_name or 'User'} role rejected and permanently removed."
        )

    # ========================================================
    # PENDING ROLE REQUESTS
    # ========================================================

    @staticmethod
    def pending_role_requests():

        return (
            User.query
            .join(Role)
            .filter(
                User.role_approval_status == "PENDING"
            )
            .order_by(
                User.created_at.asc()
            )
            .all()
        )

    # ========================================================
    # CHANGE PASSWORD
    # ========================================================

    @staticmethod
    def change_password(
        user,
        old_password,
        new_password
    ):

        if not user:

            return False, "User not found."

        if not user.verify_password(
            old_password
        ):

            return False, "Current password is incorrect."

        new_password = (
            new_password or ""
        )

        if len(new_password) < 6:

            return (
                False,
                "New password must contain at least 6 characters."
            )

        user.set_password(
            new_password
        )

        db.session.commit()

        return (
            True,
            "Password changed successfully."
        )