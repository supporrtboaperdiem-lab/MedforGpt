from datetime import datetime, timedelta
import json

from app.extensions import db
from app.models.medical_consultation import MedicalConsultation, MedicalPresence
from app.models.role import Role
from app.models.user import User
from app.services.mail_service import send_medical_consultation_invitation

ONLINE_WINDOW_SECONDS = 25
ACTIVE_STATUSES = ("PENDING", "ACCEPTED", "LIVE")


def _role_name(user):
    return (getattr(getattr(user, "role", None), "name", "") or "").strip().lower()


def allowed_counterpart_roles(user):
    role = _role_name(user)
    if role in {"employee"} or role in {"hr", "human resources", "human_resource"}:
        return {"medical officer", "medical_officer", "medical-officer"}
    if role in {"medical officer", "medical_officer", "medical-officer"}:
        return {"employee", "hr", "human resources", "human_resource"}
    return set()


def touch_presence(user_id):
    now = datetime.utcnow()
    row = MedicalPresence.query.get(user_id)
    if row is None:
        row = MedicalPresence(user_id=user_id, last_seen_at=now)
        db.session.add(row)
    else:
        row.last_seen_at = now
    db.session.commit()
    return row


def is_online(user_id):
    row = MedicalPresence.query.get(user_id)
    if not row:
        return False
    return (datetime.utcnow() - row.last_seen_at).total_seconds() <= ONLINE_WINDOW_SECONDS


def is_busy(user_id):
    return db.session.query(MedicalConsultation.id).filter(
        ((MedicalConsultation.requester_id == user_id) | (MedicalConsultation.receiver_id == user_id)),
        MedicalConsultation.status.in_(["ACCEPTED", "LIVE"]),
    ).first() is not None


def list_counterparts(user):
    roles = allowed_counterpart_roles(user)
    if not roles:
        return []

    users = (
        User.query
        .join(Role)
        .filter(User.is_active.is_(True))
        .all()
    )

    result = []
    for candidate in users:
        if candidate.id == user.id:
            continue
        if _role_name(candidate) not in roles:
            continue
        busy = is_busy(candidate.id)
        online = is_online(candidate.id)
        result.append({
            "id": candidate.id,
            "name": candidate.full_name or candidate.email,
            "email": candidate.email,
            "role": candidate.role_name or "",
            "online": online,
            "busy": busy,
            "available": online and not busy,
        })
    result.sort(key=lambda x: (not x["available"], not x["online"], x["name"].lower()))
    return result


def create_consultation(requester, receiver):
    # Keep only one genuinely active request between the same two users.
    active = (
        MedicalConsultation.query
        .filter(
            MedicalConsultation.requester_id == requester.id,
            MedicalConsultation.receiver_id == receiver.id,
            MedicalConsultation.status.in_(ACTIVE_STATUSES),
        )
        .order_by(MedicalConsultation.id.desc())
        .first()
    )
    if active:
        return active, False

    # A participant cannot be placed into a second live session.
    if is_busy(receiver.id):
        raise ValueError("The selected medical officer is currently in another live consultation.")

    now = datetime.utcnow()
    consultation = MedicalConsultation(
        token=MedicalConsultation.new_token(),
        requester_id=requester.id,
        receiver_id=receiver.id,
        # Keep the legacy medical_officer_id column synchronized with the
        # selected receiver. This is required for older live databases that
        # still have that column as NOT NULL.
        medical_officer_id=receiver.id,
        status="PENDING",
        created_at=now,
        updated_at=now,
        last_activity_at=now,
        duration_seconds=0,
        # Existing deployments have a NOT NULL expires_at column. A pending
        # invitation is valid for 30 minutes; this does not affect the actual
        # LIVE duration, which is still measured from started_at to ended_at.
        expires_at=now + timedelta(minutes=30),
    )
    db.session.add(consultation)
    db.session.commit()

    if not is_online(receiver.id):
        from flask import url_for
        link = url_for("consultation.join", token=consultation.token, _external=True)
        send_medical_consultation_invitation(
            receiver,
            requester,
            link,
            consultation.id,
        )

    return consultation, True



def close_stale_live_consultations():
    """Close LIVE sessions whose signaling heartbeat stopped unexpectedly."""
    cutoff = datetime.utcnow() - timedelta(seconds=45)
    rows = MedicalConsultation.query.filter(
        MedicalConsultation.status == "LIVE",
        MedicalConsultation.last_activity_at < cutoff,
    ).all()
    changed = False
    for consultation in rows:
        now = datetime.utcnow()
        consultation.ended_at = now
        consultation.end_reason = "CONNECTION_TIMEOUT"
        consultation.duration_seconds = _duration_seconds(consultation)
        consultation.status = "ENDED"
        consultation.updated_at = now
        consultation.last_activity_at = now
        changed = True
    if changed:
        db.session.commit()
    return len(rows)

def get_user_consultation(user, consultation_id):
    consultation = MedicalConsultation.query.get_or_404(consultation_id)
    if user.id not in {consultation.requester_id, consultation.receiver_id}:
        return None
    return consultation


def _duration_seconds(consultation):
    if not consultation.started_at:
        return int(consultation.duration_seconds or 0)
    end = consultation.ended_at or datetime.utcnow()
    return max(0, int((end - consultation.started_at).total_seconds()))


def serialize(consultation, user):
    other_id = consultation.receiver_id if consultation.requester_id == user.id else consultation.requester_id
    other = User.query.get(other_id)
    duration = _duration_seconds(consultation)
    return {
        "id": consultation.id,
        "token": consultation.token,
        "status": consultation.status,
        "requester_id": consultation.requester_id,
        "receiver_id": consultation.receiver_id,
        "is_requester": consultation.requester_id == user.id,
        "other": {
            "id": other.id if other else None,
            "name": other.full_name if other else "Unknown",
            "email": other.email if other else "",
            "role": other.role_name if other else "",
            "online": is_online(other.id) if other else False,
            "busy": is_busy(other.id) if other else False,
        },
        "offer": consultation.offer,
        "answer": consultation.answer,
        "requester_candidates": json.loads(consultation.requester_candidates or "[]"),
        "receiver_candidates": json.loads(consultation.receiver_candidates or "[]"),
        "created_at": consultation.created_at.isoformat() if consultation.created_at else None,
        "accepted_at": consultation.accepted_at.isoformat() if consultation.accepted_at else None,
        "started_at": consultation.started_at.isoformat() if consultation.started_at else None,
        "ended_at": consultation.ended_at.isoformat() if consultation.ended_at else None,
        "duration_seconds": duration,
        "duration_label": format_duration(duration),
        "ended_by_id": consultation.ended_by_id,
        "end_reason": consultation.end_reason,
        "last_activity_at": consultation.last_activity_at.isoformat() if consultation.last_activity_at else None,
    }


def format_duration(seconds):
    seconds = max(0, int(seconds or 0))
    hours, remainder = divmod(seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    if hours:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def start_consultation(consultation, actor):
    if actor.id not in {consultation.requester_id, consultation.receiver_id}:
        raise PermissionError("Not authorized.")
    if consultation.status not in {"ACCEPTED", "LIVE"}:
        raise ValueError("Consultation is not accepted yet.")

    now = datetime.utcnow()
    if consultation.started_at is None:
        consultation.started_at = now
        consultation.duration_seconds = 0
        consultation.status = "LIVE"
    consultation.updated_at = now
    consultation.last_activity_at = now
    db.session.commit()
    return consultation


def end_consultation(consultation, actor, reason="ENDED"):
    if actor.id not in {consultation.requester_id, consultation.receiver_id}:
        raise PermissionError("Not authorized.")
    if consultation.status in {"ENDED", "DECLINED"}:
        return consultation

    now = datetime.utcnow()
    consultation.ended_at = now
    consultation.ended_by_id = actor.id
    consultation.end_reason = (reason or "ENDED")[:100]
    consultation.duration_seconds = _duration_seconds(consultation)
    consultation.status = "ENDED"
    consultation.updated_at = now
    consultation.last_activity_at = now
    db.session.commit()
    return consultation
