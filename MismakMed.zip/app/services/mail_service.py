from datetime import datetime
from email.message import EmailMessage
from html import escape
import os
import smtplib

from app.models.role import Role
from app.models.user import User


SMTP_SERVER = os.getenv("MAIL_SERVER", "")
SMTP_PORT = int(os.getenv("MAIL_PORT", "587"))
SMTP_USERNAME = os.getenv("MAIL_USERNAME", "")
SMTP_PASSWORD = os.getenv("MAIL_PASSWORD", "")
SENDER_EMAIL = os.getenv("MAIL_USERNAME", "")
MAIL_USE_TLS = os.getenv("MAIL_USE_TLS", "true").strip().lower() in {"1", "true", "yes", "on"}
MAIL_CONNECT_TIMEOUT = float(os.getenv("MAIL_CONNECT_TIMEOUT_SECONDS", "5"))



def send_email(recipient, subject, html_body):
    print(recipient)
    """
    Send one HTML email.

    Returns:
        True  -> email sent
        False -> email failed / recipient missing
    """
    recipient = (recipient or "").strip()

    if not recipient:
        return False

    if not SMTP_SERVER or not SMTP_USERNAME or not SMTP_PASSWORD:
        print(
            "[MAIL][ERROR] Mail configuration is incomplete. Set MAIL_SERVER, "
            "MAIL_USERNAME and MAIL_PASSWORD in the OS environment.",
            flush=True
        )
        return False

    try:
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = SENDER_EMAIL
        msg["To"] = recipient

        msg.add_alternative(
            html_body,
            subtype="html"
        )

        with smtplib.SMTP(
            SMTP_SERVER,
            SMTP_PORT,
            timeout=MAIL_CONNECT_TIMEOUT
        ) as server:

            server.ehlo()
            if MAIL_USE_TLS:
                server.starttls()
                server.ehlo()

            server.login(
                SMTP_USERNAME,
                SMTP_PASSWORD
            )

            server.send_message(msg)

        print(
            f"[MAIL] Email sent successfully to {recipient}",
            flush=True
        )

        return True

    except Exception as exc:
        print(
            f"[MAIL][ERROR] {exc}",
            flush=True
        )

        return False


def _administrators():
    """
    Return all active Administrator users.
    """
    try:
        return (
            User.query
            .join(Role)
            .filter(
                Role.name.ilike("administrator"),
                User.is_active.is_(True)
            )
            .all()
        )

    except Exception as exc:
        print(
            f"[MAIL][ADMIN-LOOKUP][ERROR] {exc}",
            flush=True
        )

        return []


def send_to_administrators(
    subject,
    html_body,
    exclude_emails=None
):
    """
    Send an email to every active administrator.
    """

    excluded = {
        str(value).strip().lower()
        for value in (exclude_emails or [])
        if value
    }

    sent = 0

    for administrator in _administrators():

        email = (
            administrator.email or ""
        ).strip()

        if not email:
            continue

        if email.lower() in excluded:
            continue

        if send_email(
            email,
            subject,
            html_body
        ):
            sent += 1

    return sent


def _layout(
    title,
    eyebrow,
    body,
    accent="linear-gradient(135deg,#7c3aed,#06b6d4)"
):
    """
    Common HTML email layout.
    """

    safe_title = escape(str(title or ""))
    safe_eyebrow = escape(str(eyebrow or ""))

    return f"""
    <html>
    <body
        style="
            margin:0;
            background:#07111f;
            font-family:Arial,Helvetica,sans-serif;
            color:#e8eef7;
            padding:32px 16px;
        "
    >

        <div
            style="
                max-width:680px;
                margin:0 auto;
                background:rgba(15,23,42,.96);
                border:1px solid rgba(255,255,255,.12);
                border-radius:24px;
                overflow:hidden;
                box-shadow:0 24px 70px rgba(0,0,0,.35);
            "
        >

            <div
                style="
                    height:7px;
                    background:{accent};
                "
            ></div>

            <div style="padding:34px;">

                <div
                    style="
                        font-size:12px;
                        letter-spacing:2px;
                        text-transform:uppercase;
                        color:#8da2bd;
                        font-weight:700;
                    "
                >
                    {safe_eyebrow}
                </div>

                <h1
                    style="
                        margin:10px 0 22px;
                        font-size:28px;
                        color:#fff;
                    "
                >
                    {safe_title}
                </h1>

                {body}

                <div
                    style="
                        margin-top:28px;
                        padding-top:18px;
                        border-top:1px solid rgba(255,255,255,.1);
                        font-size:12px;
                        color:#8da2bd;
                    "
                >
                    BOA Medical Reimbursement System
                </div>

            </div>
        </div>

    </body>
    </html>
    """


def _user_summary(user):
    """
    Build a safe HTML summary of a user.

    IMPORTANT:
    Do NOT use nested f-strings inside another f-string.
    """

    full_name = (
        getattr(user, "full_name", None)
        or getattr(user, "email", None)
        or ""
    )

    email = getattr(user, "email", "") or ""

    role_name = (
        getattr(user, "role_name", None)
        or "Unassigned"
    )

    spouse_row = ""

    return f"""
    <table
        style="
            width:100%;
            border-collapse:collapse;
            color:#dbe7f5;
        "
    >

        <tr>
            <td
                style="
                    padding:8px 0;
                    color:#8da2bd;
                "
            >
                Name
            </td>

            <td
                style="
                    padding:8px 0;
                    font-weight:700;
                "
            >
                {escape(str(full_name))}
            </td>
        </tr>

        <tr>
            <td
                style="
                    padding:8px 0;
                    color:#8da2bd;
                "
            >
                Email
            </td>

            <td style="padding:8px 0;">
                {escape(str(email))}
            </td>
        </tr>

        <tr>
            <td
                style="
                    padding:8px 0;
                    color:#8da2bd;
                "
            >
                Role
            </td>

            <td style="padding:8px 0;">
                {escape(str(role_name))}
            </td>
        </tr>

        {spouse_row}

    </table>
    """


def send_registration_otp(email, otp):
    """
    Registration email verification OTP.
    """

    safe_otp = escape(str(otp))

    body = f"""
    <p>
        Your registration verification code is:
    </p>

    <div
        style="
            margin:24px 0;
            padding:20px;
            text-align:center;
            background:#111e33;
            border:1px solid rgba(6,182,212,.35);
            border-radius:18px;
            font-size:34px;
            font-weight:800;
            letter-spacing:10px;
            color:#67e8f9;
        "
    >
        {safe_otp}
    </div>

    <p style="color:#aebdd0;">
        This code expires in
        <strong style="color:#fff;">
            10 minutes
        </strong>.
    </p>

    <p style="color:#aebdd0;">
        If you did not request this account,
        you can safely ignore this message.
    </p>
    """

    return send_email(
        email,
        "BOA Medical Reimbursement System — Verify Your Email",
        _layout(
            "Verify your email",
            "Registration",
            body
        )
    )


def send_login_notification(user):
    """
    Notify the user after a successful login.
    """

    try:
        from flask import request

        ip_address = (
            request.headers.get("X-Forwarded-For")
            or request.remote_addr
            or "Unknown"
        )

        user_agent = (
            request.headers.get("User-Agent")
            or "Unknown"
        )

        login_url = request.url_root

    except Exception:
        ip_address = "Unknown"
        user_agent = "Unknown"
        login_url = ""

    safe_ip = escape(str(ip_address))
    safe_user_agent = escape(str(user_agent))
    safe_login_url = escape(str(login_url))

    body = _user_summary(user)

    body += f"""
    <div
        style="
            margin-top:20px;
            padding:16px;
            background:#111e33;
            border-radius:16px;
        "
    >

        <p
            style="
                margin:4px 0;
                color:#aebdd0;
            "
        >
            <strong style="color:#fff;">
                Login time:
            </strong>

            {datetime.utcnow().strftime(
                "%Y-%m-%d %H:%M:%S"
            )} UTC
        </p>

        <p
            style="
                margin:4px 0;
                color:#aebdd0;
            "
        >
            <strong style="color:#fff;">
                IP:
            </strong>

            {safe_ip}
        </p>

        <p
            style="
                margin:4px 0;
                color:#aebdd0;
                word-break:break-word;
            "
        >
            <strong style="color:#fff;">
                Device:
            </strong>

            {safe_user_agent}
        </p>

        <p
            style="
                margin:4px 0;
                color:#aebdd0;
            "
        >
            <strong style="color:#fff;">
                System:
            </strong>

            {safe_login_url}
        </p>

    </div>
    """

    return send_email(
        user.email,
        "BOA Medical Reimbursement System — New Login",
        _layout(
            "Successful login detected",
            "Security notification",
            body
        )
    )


def send_account_creation_notification(
    user,
    created_by=None
):
    """
    Notify user and administrators about account creation.
    """

    creator = (
        getattr(created_by, "email", None)
        or "Self-registration"
    )

    body = _user_summary(user)

    body += f"""
    <div
        style="
            margin-top:20px;
            padding:16px;
            background:#111e33;
            border-radius:16px;
        "
    >

        <p style="margin:0;color:#aebdd0;">
            Your BOA account has been created successfully.
        </p>

        <p
            style="
                margin:10px 0 0;
                color:#aebdd0;
            "
        >
            <strong style="color:#fff;">
                Created by:
            </strong>

            {escape(str(creator))}
        </p>

    </div>
    """

    sent = send_email(
        user.email,
        "BOA Medical Reimbursement System — Account Created",
        _layout(
            "Account created",
            "Account notification",
            body
        )
    )

    admin_body = _user_summary(user)

    admin_body += f"""
    <p
        style="
            margin-top:20px;
            color:#aebdd0;
        "
    >
        A new account was created by
        <strong style="color:#fff;">
            {escape(str(creator))}
        </strong>.
    </p>
    """

    send_to_administrators(
        "BOA Medical Reimbursement System — New Account Created",
        _layout(
            "New account created",
            "Administrator notification",
            admin_body
        ),
        exclude_emails=[user.email]
    )

    return sent


def send_role_submission_notification(user):
    """
    Notify administrators about a new role request.
    """

    body = _user_summary(user)

    body += """
    <p
        style="
            margin-top:22px;
            color:#aebdd0;
        "
    >
        A new role request is waiting for
        Administrator review.
    </p>
    """

    return (
        send_to_administrators(
            "BOA Medical Reimbursement System — New Role Request",
            _layout(
                "New role request",
                "Administrator action required",
                body
            )
        )
        > 0
    )


def send_role_decision_notification(
    user,
    administrator,
    approved,
    reason=None
):
    """
    Notify user and administrators about role approval/decline.
    """

    status = (
        "APPROVED"
        if approved
        else "DECLINED"
    )

    accent = (
        "linear-gradient(135deg,#10b981,#06b6d4)"
        if approved
        else "linear-gradient(135deg,#ef4444,#f97316)"
    )

    body = _user_summary(user)

    administrator_email = (
        getattr(administrator, "email", "")
        or "System"
    )

    administrator_email = escape(
        str(administrator_email)
    )

    body += f"""
    <div
        style="
            margin-top:20px;
            padding:18px;
            background:#111e33;
            border-radius:16px;
        "
    >

        <p
            style="
                margin:0;
                font-size:18px;
                font-weight:800;
                color:#fff;
            "
        >
            Role {status}
        </p>

        <p style="color:#aebdd0;">
            Administrator:
            {administrator_email}
        </p>
    """

    if reason:
        body += f"""
        <p style="color:#aebdd0;">
            Reason:
            {escape(str(reason))}
        </p>
        """

    body += """
    </div>
    """

    send_email(
        user.email,
        f"BOA Medical Reimbursement System — Role {status}",
        _layout(
            f"Role {status.lower()}",
            "Role decision",
            body,
            accent
        )
    )

    return send_to_administrators(
        f"BOA Medical Reimbursement System — Role {status}",
        _layout(
            f"Role {status.lower()}",
            "Administrator audit",
            body,
            accent
        ),
        exclude_emails=[user.email]
    )


def send_account_status_notification(
    user,
    administrator,
    enabled
):
    """
    Notify user and administrators when an account
    is enabled or disabled.
    """

    status = (
        "ENABLED"
        if enabled
        else "DISABLED"
    )

    administrator_email = (
        getattr(administrator, "email", "")
        or "System"
    )

    body = _user_summary(user)

    body += f"""
    <p
        style="
            margin-top:22px;
            color:#aebdd0;
        "
    >

        Your account was

        <strong style="color:#fff;">
            {status.lower()}
        </strong>

        by Administrator

        {escape(str(administrator_email))}.

    </p>
    """

    send_email(
        user.email,
        f"BOA Medical Reimbursement System — Account {status}",
        _layout(
            f"Account {status.lower()}",
            "Account status",
            body
        )
    )

    return send_to_administrators(
        f"BOA Medical Reimbursement System — Account {status}",
        _layout(
            f"Account {status.lower()}",
            "Administrator audit",
            body
        ),
        exclude_emails=[user.email]
    )


def send_claim_action_notification(
    claim,
    actor,
    action
):
    """
    Notify:
        1. Claim submitter
        2. Actual action taker
        3. All active administrators

    The action taker ALWAYS receives a direct email,
    even when the action taker is HR and is not an
    Administrator.

    Supported actions:
        SUBMITTED
        ACCEPTED
        APPROVED
        DECLINED
        REJECTED
    """

    submitter = getattr(
        claim,
        "submitted_by",
        None
    )

    institution_obj = getattr(
        claim,
        "institution",
        None
    )

    institution = (
        getattr(
            institution_obj,
            "name",
            None
        )
        or getattr(
            claim,
            "institution_name",
            None
        )
        or "Unknown institution"
    )

    status = str(action or "").upper()

    beneficiary_type = (
        getattr(
            claim,
            "beneficiary_type",
            "EMPLOYEE"
        )
        or "EMPLOYEE"
    )

    coverage = (
        getattr(
            claim,
            "coverage_percentage",
            100
        )
        or 100
    )

    owner_name = (
        getattr(
            claim,
            "employee_owner_name",
            None
        )
        or "-"
    )

    beneficiary_name = (
        getattr(
            claim,
            "beneficiary_name",
            None
        )
        or getattr(
            claim,
            "patient_name",
            "-"
        )
    )

    patient_name = (
        getattr(
            claim,
            "patient_name",
            "-"
        )
        or "-"
    )

    category = (
        getattr(
            claim,
            "category",
            "-"
        )
        or "-"
    )

    items = getattr(
        claim,
        "items",
        None
    )

    items = items or []

    receipt_total = 0.0
    reimbursable_total = 0.0

    for item in items:

        receipt_price = (
            getattr(
                item,
                "receipt_price",
                0
            )
            or 0
        )

        reimbursable_amount = (
            getattr(
                item,
                "reimbursable_amount",
                0
            )
            or 0
        )

        try:
            receipt_total += float(
                receipt_price
            )
        except (TypeError, ValueError):
            pass

        try:
            reimbursable_total += float(
                reimbursable_amount
            )
        except (TypeError, ValueError):
            pass

    if str(beneficiary_type).upper() == "SPOUSE":
        tag = "SPOUSE — 90%"
    else:
        tag = "EMPLOYEE — 100%"

    # ---------------------------------------------------------
    # ACTUAL ACTOR
    # ---------------------------------------------------------

    actor_email = (
        getattr(
            actor,
            "email",
            None
        )
        or ""
    ).strip()

    # ---------------------------------------------------------
    # SUBMITTER
    # ---------------------------------------------------------

    submitter_email = ""

    if submitter:
        submitter_email = (
            getattr(
                submitter,
                "email",
                None
            )
            or ""
        ).strip()

    # ---------------------------------------------------------
    # BUILD EMAIL
    # ---------------------------------------------------------

    body = f"""
    <table
        style="
            width:100%;
            border-collapse:collapse;
            color:#dbe7f5;
        "
    >

        <tr>
            <td style="padding:7px 0;color:#8da2bd;">
                Claim
            </td>

            <td
                style="
                    padding:7px 0;
                    font-weight:700;
                "
            >
                #{claim.id}
            </td>
        </tr>

        <tr>
            <td style="padding:7px 0;color:#8da2bd;">
                Employee record
            </td>

            <td
                style="
                    padding:7px 0;
                    font-weight:700;
                "
            >
                {escape(str(owner_name))}
            </td>
        </tr>

        <tr>
            <td style="padding:7px 0;color:#8da2bd;">
                Beneficiary
            </td>

            <td style="padding:7px 0;">
                {escape(str(beneficiary_name))}
                —
                {escape(str(tag))}
            </td>
        </tr>

        <tr>
            <td style="padding:7px 0;color:#8da2bd;">
                Coverage
            </td>

            <td style="padding:7px 0;">
                {escape(str(coverage))}%
            </td>
        </tr>

        <tr>
            <td style="padding:7px 0;color:#8da2bd;">
                Patient
            </td>

            <td style="padding:7px 0;">
                {escape(str(patient_name))}
            </td>
        </tr>

        <tr>
            <td style="padding:7px 0;color:#8da2bd;">
                Category
            </td>

            <td style="padding:7px 0;">
                {escape(str(category))}
            </td>
        </tr>

        <tr>
            <td style="padding:7px 0;color:#8da2bd;">
                Institution
            </td>

            <td style="padding:7px 0;">
                {escape(str(institution))}
            </td>
        </tr>

        <tr>
            <td style="padding:7px 0;color:#8da2bd;">
                Receipt expense
            </td>

            <td style="padding:7px 0;">
                {receipt_total:,.2f} ETB
            </td>
        </tr>

        <tr>
            <td style="padding:7px 0;color:#8da2bd;">
                Reimbursable
            </td>

            <td
                style="
                    padding:7px 0;
                    font-weight:800;
                    color:#6ee7b7;
                "
            >
                {reimbursable_total:,.2f} ETB
            </td>
        </tr>

        <tr>
            <td style="padding:7px 0;color:#8da2bd;">
                Action
            </td>

            <td
                style="
                    padding:7px 0;
                    font-weight:800;
                "
            >
                {escape(status)}
            </td>
        </tr>

        <tr>
            <td style="padding:7px 0;color:#8da2bd;">
                Action taker
            </td>

            <td
                style="
                    padding:7px 0;
                    font-weight:800;
                "
            >
                {escape(str(actor_email or "System"))}
            </td>
        </tr>

    </table>
    """

    subject = (
        "BOA Medical Reimbursement System — "
        f"Claim #{claim.id} {status}"
    )

    email_body = _layout(
        f"Claim {status.lower()}",
        "Claim workflow",
        body
    )

    # =========================================================
    # 1. ALWAYS EMAIL THE ACTION TAKER
    # =========================================================

    if actor_email:

        print(
            f"[MAIL][CLAIM] Sending action notification "
            f"to actor: {actor_email}",
            flush=True
        )

        send_email(
            actor_email,
            subject,
            email_body
        )

    # =========================================================
    # 2. EMAIL THE SUBMITTER
    # =========================================================

    if (
        submitter_email
        and submitter_email.lower()
        != actor_email.lower()
    ):

        print(
            f"[MAIL][CLAIM] Sending notification "
            f"to submitter: {submitter_email}",
            flush=True
        )

        send_email(
            submitter_email,
            subject,
            email_body
        )

    # =========================================================
    # 3. EMAIL ALL ADMINISTRATORS
    #
    # Don't send duplicate emails to actor or submitter.
    # =========================================================

    excluded = [
        actor_email,
        submitter_email
    ]

    print(
        "[MAIL][CLAIM] Sending administrator notifications",
        flush=True
    )

    send_to_administrators(
        subject,
        email_body,
        exclude_emails=excluded
    )

    return True
   


def send_claim_batch_notification(claims, actor):
    """Send exactly one consolidated email for a receipt upload batch."""
    claims = [claim for claim in (claims or []) if claim is not None]
    if not claims:
        return False

    actor_email = (getattr(actor, "email", None) or "").strip()
    first_submitter = getattr(claims[0], "submitted_by", None)
    submitter_email = (getattr(first_submitter, "email", None) or "").strip()
    admins = _administrators()
    addresses = []
    for address in [actor_email, submitter_email] + [getattr(u, "email", None) for u in admins]:
        address = (address or "").strip()
        if address and address.lower() not in {a.lower() for a in addresses}:
            addresses.append(address)
    if not addresses:
        return False

    rows = []
    for claim in claims:
        owner = getattr(claim, "employee_owner_name", None) or "-"
        institution_obj = getattr(claim, "institution", None)
        institution = getattr(institution_obj, "name", None) or "-"
        total = sum(float(getattr(item, "receipt_price", 0) or 0) for item in (getattr(claim, "items", None) or []))
        reimbursable = sum(float(getattr(item, "reimbursable_amount", 0) or 0) for item in (getattr(claim, "items", None) or []))
        rows.append(
            "<tr>"
            f"<td style='padding:8px;border-bottom:1px solid #334155'>#{int(claim.id)}</td>"
            f"<td style='padding:8px;border-bottom:1px solid #334155'>{escape(str(owner))}</td>"
            f"<td style='padding:8px;border-bottom:1px solid #334155'>{escape(str(getattr(claim, 'category', '-')))}</td>"
            f"<td style='padding:8px;border-bottom:1px solid #334155'>{escape(str(institution))}</td>"
            f"<td style='padding:8px;border-bottom:1px solid #334155'>{escape(str(getattr(claim, 'status', '-')))}</td>"
            f"<td style='padding:8px;border-bottom:1px solid #334155;text-align:right'>{total:,.2f} ETB</td>"
            f"<td style='padding:8px;border-bottom:1px solid #334155;text-align:right'>{reimbursable:,.2f} ETB</td>"
            "</tr>"
        )
    body = (
        f"<p>One upload batch created {len(claims)} claim(s). The table below contains every claim created from this upload.</p>"
        "<div style='overflow-x:auto'><table style='width:100%;border-collapse:collapse;color:#dbe7f5'>"
        "<thead><tr>"
        "<th style='text-align:left;padding:8px'>Claim</th><th style='text-align:left;padding:8px'>Employee</th>"
        "<th style='text-align:left;padding:8px'>Category</th><th style='text-align:left;padding:8px'>Institution</th>"
        "<th style='text-align:left;padding:8px'>Status</th><th style='text-align:right;padding:8px'>Receipt total</th>"
        "<th style='text-align:right;padding:8px'>Reimbursable</th></tr></thead><tbody>"
        + "".join(rows) + "</tbody></table></div>"
    )
    html_body = _layout("Claim upload batch", "Medical reimbursement workflow", body)

    if not SMTP_SERVER or not SMTP_USERNAME or not SMTP_PASSWORD:
        print("[MAIL][ERROR] Mail configuration is incomplete; batch notification not sent.", flush=True)
        return False
    try:
        msg = EmailMessage()
        msg["Subject"] = f"BOA Medical Reimbursement System — Upload batch ({len(claims)} claims)"
        msg["From"] = SENDER_EMAIL
        msg["To"] = addresses[0]
        if len(addresses) > 1:
            msg["Bcc"] = ", ".join(addresses[1:])
        msg.add_alternative(html_body, subtype="html")
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=MAIL_CONNECT_TIMEOUT) as server:
            server.ehlo()
            if MAIL_USE_TLS:
                server.starttls()
                server.ehlo()
            server.login(SMTP_USERNAME, SMTP_PASSWORD)
            server.send_message(msg, to_addrs=addresses)
        print(f"[MAIL][CLAIM-BATCH] One batch email sent for {len(claims)} claim(s).", flush=True)
        return True
    except Exception as exc:
        print(f"[MAIL][CLAIM-BATCH][ERROR] {exc}", flush=True)
        return False


def send_price_list_action_notification(
    price_list,
    actor,
    action,
    submitter=None
):
    """
    Send price-list workflow notification to:
        1. Original submitter
        2. Actual action taker
        3. Active administrators

    This function intentionally supports several possible attribute
    names because existing versions of the price-list model may use
    different names for the submitter.
    """

    status = str(action or "").upper()

    # ---------------------------------------------------------
    # Find the original submitter
    # ---------------------------------------------------------
    if submitter is None:

        submitter = (
            getattr(price_list, "created_by", None)
            or getattr(price_list, "submitted_by", None)
            or getattr(price_list, "uploader", None)
        )

    # ---------------------------------------------------------
    # Submitter email
    # ---------------------------------------------------------
    submitter_email = ""

    if submitter:
        submitter_email = (
            getattr(submitter, "email", None)
            or ""
        ).strip()

    # Some versions may store created_by_id but not the
    # relationship. If no relationship is available, try
    # the direct email fields.
    if not submitter_email:

        submitter_email = (
            getattr(price_list, "submitter_email", None)
            or getattr(price_list, "created_by_email", None)
            or ""
        ).strip()

    # ---------------------------------------------------------
    # Action taker
    # ---------------------------------------------------------
    actor_email = ""

    if actor:
        actor_email = (
            getattr(actor, "email", None)
            or ""
        ).strip()

    if not actor_email:
        actor_email = "System"

    # ---------------------------------------------------------
    # Price-list information
    # ---------------------------------------------------------
    price_list_id = getattr(
        price_list,
        "id",
        "-"
    )

    institution = (
        getattr(
            price_list,
            "institution",
            None
        )
        or getattr(
            price_list,
            "institution_name",
            None
        )
        or "-"
    )

    institution_name = getattr(
        institution,
        "name",
        institution
    )

    category = (
        getattr(
            price_list,
            "category",
            None
        )
        or getattr(
            price_list,
            "service_category",
            None
        )
        or "-"
    )

    file_name = (
        getattr(
            price_list,
            "file_name",
            None
        )
        or getattr(
            price_list,
            "source_filename",
            None
        )
        or getattr(
            price_list,
            "filename",
            None
        )
        or "-"
    )

    description = (
        getattr(
            price_list,
            "description",
            None
        )
        or "-"
    )

    # ---------------------------------------------------------
    # Determine friendly action text
    # ---------------------------------------------------------
    if status in ("REJECTED", "DECLINED"):
        action_title = "Price list rejected"
        accent = (
            "linear-gradient("
            "135deg,#ef4444,#f97316"
            ")"
        )

    elif status in ("APPROVED", "ACCEPTED"):
        action_title = "Price list approved"
        accent = (
            "linear-gradient("
            "135deg,#10b981,#06b6d4"
            ")"
        )

    elif status in ("SUBMITTED", "SUBMIT"):
        action_title = "Price list submitted"
        accent = (
            "linear-gradient("
            "135deg,#7c3aed,#06b6d4"
            ")"
        )

    else:
        action_title = (
            f"Price list {status.lower()}"
        )

        accent = (
            "linear-gradient("
            "135deg,#7c3aed,#06b6d4"
            ")"
        )

    # ---------------------------------------------------------
    # Main email body
    # ---------------------------------------------------------
    body = f"""
    <table
        style="
            width:100%;
            border-collapse:collapse;
            color:#dbe7f5;
        "
    >

        <tr>
            <td
                style="
                    padding:8px 0;
                    color:#8da2bd;
                "
            >
                Price List
            </td>

            <td
                style="
                    padding:8px 0;
                    font-weight:700;
                "
            >
                #{escape(str(price_list_id))}
            </td>
        </tr>

        <tr>
            <td
                style="
                    padding:8px 0;
                    color:#8da2bd;
                "
            >
                Institution
            </td>

            <td style="padding:8px 0;">
                {escape(str(institution_name))}
            </td>
        </tr>

        <tr>
            <td
                style="
                    padding:8px 0;
                    color:#8da2bd;
                "
            >
                Category
            </td>

            <td style="padding:8px 0;">
                {escape(str(category))}
            </td>
        </tr>

        <tr>
            <td
                style="
                    padding:8px 0;
                    color:#8da2bd;
                "
            >
                File
            </td>

            <td style="padding:8px 0;">
                {escape(str(file_name))}
            </td>
        </tr>

        <tr>
            <td
                style="
                    padding:8px 0;
                    color:#8da2bd;
                "
            >
                Description
            </td>

            <td style="padding:8px 0;">
                {escape(str(description))}
            </td>
        </tr>

        <tr>
            <td
                style="
                    padding:8px 0;
                    color:#8da2bd;
                "
            >
                Action
            </td>

            <td
                style="
                    padding:8px 0;
                    font-weight:800;
                "
            >
                {escape(action_title)}
            </td>
        </tr>

        <tr>
            <td
                style="
                    padding:8px 0;
                    color:#8da2bd;
                "
            >
                Action taker
            </td>

            <td
                style="
                    padding:8px 0;
                    font-weight:700;
                "
            >
                {escape(str(actor_email))}
            </td>
        </tr>

        <tr>
            <td
                style="
                    padding:8px 0;
                    color:#8da2bd;
                "
            >
                Original submitter
            </td>

            <td style="padding:8px 0;">
                {escape(str(submitter_email or "Unknown"))}
            </td>
        </tr>

    </table>
    """

    subject = (
        "BOA Medical Reimbursement System — "
        f"Price List #{price_list_id} "
        f"{status}"
    )

    email_body = _layout(
        action_title,
        "Price List Workflow",
        body,
        accent
    )

    # ---------------------------------------------------------
    # 1. ORIGINAL SUBMITTER
    # ---------------------------------------------------------
    if (
        submitter_email
        and submitter_email.lower() != actor_email.lower()
    ):
        send_email(
            submitter_email,
            subject,
            email_body
        )

    # ---------------------------------------------------------
    # 2. ACTUAL ACTION TAKER
    #
    # This is the important fix:
    # HR who approves/rejects the price list receives
    # the email too.
    # ---------------------------------------------------------
    if (
        actor_email
        and actor_email.lower() != "system"
    ):
        send_email(
            actor_email,
            subject,
            email_body
        )

    # ---------------------------------------------------------
    # 3. ADMINISTRATORS
    #
    # Do not duplicate the email if actor/submitter is also
    # an administrator.
    # ---------------------------------------------------------
    send_to_administrators(
        subject,
        email_body,
        exclude_emails=[
            submitter_email,
            actor_email
        ]
    )

    return True

def send_medical_consultation_invitation(receiver, requester, consultation_link, consultation_id):
    """Email an offline consultation participant a one-click secure join link."""
    receiver_email = (getattr(receiver, "email", "") or "").strip()
    if not receiver_email:
        return False

    requester_name = (
        getattr(requester, "full_name", None)
        or getattr(requester, "email", None)
        or "A BOA colleague"
    )

    receiver_name = (
        getattr(receiver, "full_name", None)
        or getattr(receiver, "email", None)
        or "Medical colleague"
    )

    body = f"""
    <div style="padding:22px;border-radius:20px;background:#111e33;border:1px solid rgba(255,255,255,.09);">
        <div style="font-size:12px;letter-spacing:2px;text-transform:uppercase;color:#8da2bd;font-weight:800;">
            LIVE MEDICAL CONSULTATION
        </div>
        <h2 style="margin:10px 0;color:#fff;">Your colleague is requesting a live consultation</h2>
        <p style="color:#b9c7d8;line-height:1.7;">
            Hello {escape(str(receiver_name))},<br><br>
            <strong style="color:#fff;">{escape(str(requester_name))}</strong>
            is requesting a live medical consultation with you.
            You were detected as offline when the request was created.
        </p>
        <div style="margin:22px 0;text-align:center;">
            <a href="{escape(str(consultation_link))}"
               style="display:inline-block;padding:15px 24px;border-radius:14px;background:linear-gradient(135deg,#f59e0b,#06b6d4);color:#07111f;text-decoration:none;font-weight:900;">
                JOIN LIVE CONSULTATION
            </a>
        </div>
        <p style="color:#8da2bd;font-size:12px;line-height:1.6;">
            Consultation reference #{escape(str(consultation_id))}.<br>
            The secure link opens the consultation room directly after authentication.
        </p>
    </div>
    """

    return send_email(
        receiver_email,
        "BOA Medical Reimbursement System — Live Consultation Request",
        _layout(
            "Live consultation requested",
            "Medical Officer Consultation",
            body,
            "linear-gradient(135deg,#f59e0b,#06b6d4)"
        )
    )
