import re
import unicodedata
from pathlib import Path
import time

from openpyxl import load_workbook
from sqlalchemy import or_

from app.extensions import db
from app.models.employee import Employee
from app.services.claim_automation_service import ClaimAutomationService

try:
    from rapidfuzz.fuzz import ratio, WRatio, token_set_ratio, token_sort_ratio
except ImportError:  # graceful fallback if RapidFuzz is not installed yet
    from difflib import SequenceMatcher
    def ratio(a, b): return SequenceMatcher(None, a, b).ratio() * 100
    def WRatio(a, b): return ratio(a, b)
    def token_set_ratio(a, b):
        sa, sb = set(a.split()), set(b.split())
        return ratio(" ".join(sorted(sa)), " ".join(sorted(sb)))
    def token_sort_ratio(a, b): return ratio(" ".join(sorted(a.split())), " ".join(sorted(b.split())))


def norm(value):
    text = "" if value is None else str(value)
    text = text.replace("\u00a0", " ").replace("\u202f", " ")
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    text = text.casefold()
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def compact(value):
    return re.sub(r"[^a-z0-9]", "", norm(value))


def exact_id(value):
    text = "" if value is None else str(value).strip()
    if text.endswith(".0") and text[:-2].isdigit():
        text = text[:-2]
    return re.sub(r"\s+", "", text).casefold()


def _cn_name(value):
    """Turn common AD manager/DN values into a human-readable name."""
    text = "" if value is None else str(value)
    m = re.search(r"(?:^|,)\s*CN=([^,]+)", text, flags=re.I)
    return m.group(1).strip() if m else text


def _tokens(value):
    return [t for t in norm(value).split() if t]


def _token_similarity(a_tokens, b_tokens):
    if not a_tokens or not b_tokens:
        return 0.0
    scores = []
    for a in a_tokens:
        scores.append(max(ratio(a, b) for b in b_tokens))
    return sum(scores) / len(scores)


def _name_score(query, candidate):
    """High-precision name score tolerant of OCR typos and token errors.

    It deliberately combines whole-name and token-level evidence instead of
    relying on a single edit-distance measurement. This handles examples such
    as `Shiimelis` vs `Shimelis`, swapped names, doubled/missing letters and
    small OCR corruption while still penalizing unrelated names.
    """
    q = norm(query)
    c = norm(candidate)
    if not q or not c:
        return 0.0
    if q == c:
        return 100.0

    qs, cs = _tokens(q), _tokens(c)
    whole = ratio(q, c)
    wratio = WRatio(q, c)
    tset = token_set_ratio(q, c)
    tsort = token_sort_ratio(q, c)
    q_to_c = _token_similarity(qs, cs)
    c_to_q = _token_similarity(cs, qs)
    token_avg = (q_to_c + c_to_q) / 2.0

    # Token overlap is particularly valuable for three-part Ethiopian names:
    # one misspelled token should not erase two very strong token matches.
    exact_tokens = len(set(qs) & set(cs))
    overlap = 100.0 * exact_tokens / max(len(set(qs)), len(set(cs)), 1)

    # The highest evidence is a near-identical whole name. Otherwise blend
    # character and token evidence. WRatio is useful for reordered/partial OCR.
    score = (
        0.28 * whole +
        0.20 * wratio +
        0.18 * tset +
        0.12 * tsort +
        0.17 * token_avg +
        0.05 * overlap
    )

    # Strong bonus when the query has at least 2 tokens and every query token
    # has a very close candidate token (e.g. Shiimelis -> Shimelis).
    if len(qs) >= 2 and q_to_c >= 90 and c_to_q >= 75:
        score += 4
    return min(score, 100.0)


def _field_score(query, candidate):
    q, c = norm(query), norm(candidate)
    if not q or not c:
        return None
    # Manager values may be AD DNs in the directory.
    c = norm(_cn_name(candidate))
    return ratio(q, c)


def _employee_suggestions(employee_data, limit=8):
    """Return ranked human-review candidates for an unresolved receipt employee."""
    data = employee_data if isinstance(employee_data, dict) else {}
    name = str(data.get("name") or "").strip()
    enum = exact_id(data.get("employee_number"))
    eid = exact_id(data.get("employee_id"))
    all_employees = EmployeeDirectoryService._all_employees()
    ranked = []
    for e in all_employees:
        score = _name_score(name, e.full_name) if name else 0.0
        if enum and exact_id(e.employee_number) == enum:
            score = 100.0
        if eid and exact_id(e.employee_id) == eid:
            score = 100.0
        ranked.append((score, e))
    ranked.sort(key=lambda x: x[0], reverse=True)
    return [{
        "id": e.id, "employee_id": e.employee_id, "employee_number": e.employee_number,
        "full_name": e.full_name, "department": e.department, "manager": e.manager,
        "office": e.office, "score": round(score, 1)
    } for score, e in ranked[:limit]]


class EmployeeDirectoryService:
    _EMPLOYEE_CACHE = None
    _EMPLOYEE_CACHE_AT = 0.0
    _EMPLOYEE_CACHE_TTL = 30.0

    @classmethod
    def _all_employees(cls):
        now = time.monotonic()
        if cls._EMPLOYEE_CACHE is None or (now - cls._EMPLOYEE_CACHE_AT) > cls._EMPLOYEE_CACHE_TTL:
            cls._EMPLOYEE_CACHE = Employee.query.all()
            cls._EMPLOYEE_CACHE_AT = now
        return cls._EMPLOYEE_CACHE

    @classmethod
    def invalidate_cache(cls):
        cls._EMPLOYEE_CACHE = None
        cls._EMPLOYEE_CACHE_AT = 0.0

    HEADER_MAP = {
        "User Name": "username", "First Name": "first_name",
        "Middle Name": "middle_name", "Last Name": "last_name",
        "User Principal Name": "user_principal_name", "Email": "email",
        "Job Title": "job_title", "Department": "department",
        "Company": "company", "Office": "office", "Division": "division",
        "Employee Type": "employee_type", "Mobile": "mobile",
        "Telephone": "telephone", "Business Address": "business_address",
        "City": "city", "State / Region": "state_region",
        "Country": "country", "Employee ID": "employee_id",
        "Employee Number": "employee_number", "Manager": "manager",
        "Description": "description",
    }

    @staticmethod
    def suggest_matches(employee_data, limit=8):
        return _employee_suggestions(employee_data, limit=limit)

    @staticmethod
    def search_matches(query, limit=12):
        """Fast live-search candidate lookup used by the browser autocomplete."""
        q = str(query or "").strip()
        if not q:
            return []
        pattern = f"%{q}%"
        candidates = Employee.query.filter(
            or_(
                Employee.full_name.ilike(pattern),
                Employee.employee_number.ilike(pattern),
                Employee.employee_id.ilike(pattern),
                Employee.department.ilike(pattern),
                Employee.office.ilike(pattern),
                Employee.username.ilike(pattern),
            )
        ).limit(250).all()
        ranked = []
        for e in candidates:
            score = _name_score(q, e.full_name)
            if exact_id(e.employee_number) == exact_id(q) or exact_id(e.employee_id) == exact_id(q):
                score = 100.0
            elif norm(q) in norm(e.full_name):
                score = max(score, 94.0)
            ranked.append((score, e))
        ranked.sort(key=lambda x: x[0], reverse=True)
        return [{
            "id": e.id, "employee_id": e.employee_id, "employee_number": e.employee_number,
            "full_name": e.full_name, "department": e.department, "manager": e.manager,
            "office": e.office, "score": round(score, 1)
        } for score, e in ranked[:limit]]

    @classmethod
    def import_excel(cls, file_path):
        path = Path(file_path)
        wb = load_workbook(path, read_only=True, data_only=True)
        imported = updated = skipped = 0
        errors = []
        try:
            for ws in wb.worksheets:
                rows = ws.iter_rows(values_only=True)
                try:
                    headers = [str(v).strip() if v is not None else "" for v in next(rows)]
                except StopIteration:
                    continue
                indexes = {h: i for i, h in enumerate(headers) if h}
                for row_no, row in enumerate(rows, start=2):
                    def val(header):
                        i = indexes.get(header)
                        return row[i] if i is not None and i < len(row) else None
                    eid = str(val("Employee ID") or "").strip()
                    enum = str(val("Employee Number") or "").strip()
                    first = str(val("First Name") or "").strip()
                    middle = str(val("Middle Name") or "").strip()
                    last = str(val("Last Name") or "").strip()
                    full_name = str(val("User Name") or "").strip() or " ".join(x for x in [first, middle, last] if x).strip()
                    if not eid or not full_name:
                        skipped += 1
                        continue
                    fields = {}
                    for header, attr in cls.HEADER_MAP.items():
                        value = val(header)
                        if value is not None:
                            fields[attr] = str(value).strip()
                    fields["employee_id"] = eid
                    fields["employee_number"] = enum or None
                    fields["full_name"] = full_name
                    existing = Employee.query.filter_by(employee_id=eid).first()
                    if existing is None:
                        code = eid
                        if Employee.query.filter_by(employee_code=code).first():
                            code = f"{eid}-{enum}" if enum else f"{eid}-{row_no}"
                        fields["employee_code"] = code
                        db.session.add(Employee(**fields))
                        imported += 1
                    else:
                        for key, value in fields.items():
                            if key != "employee_code":
                                setattr(existing, key, value)
                        updated += 1
            db.session.commit()
            cls.invalidate_cache()
        except Exception:
            db.session.rollback()
            raise
        finally:
            wb.close()
        return {"imported": imported, "updated": updated, "skipped": skipped, "errors": errors}

    @staticmethod
    def match_employee(employee_data):
        data = employee_data if isinstance(employee_data, dict) else {}
        eid = exact_id(data.get("employee_id"))
        enum = exact_id(data.get("employee_number"))
        name = str(data.get("name") or "").strip()
        department = norm(data.get("department"))
        office = norm(data.get("office"))
        manager = norm(_cn_name(data.get("manager")))

        all_employees = EmployeeDirectoryService._all_employees()

        # 1) Hard identifiers always win. Employee ID is authoritative.
        if eid:
            candidates = [e for e in all_employees if exact_id(e.employee_id) == eid]
            if not candidates:
                candidates = [e for e in all_employees if exact_id(e.employee_number) == eid]
            if len(candidates) == 1:
                return candidates[0], None
            if len(candidates) > 1:
                # Disambiguate a duplicate legacy identifier with the name.
                named = sorted(candidates, key=lambda e: _name_score(name, e.full_name), reverse=True)
                if name and len(named) == 1:
                    return named[0], None
                if name and _name_score(name, named[0].full_name) >= 88 and (_name_score(name, named[0].full_name) - _name_score(name, named[1].full_name) >= 6):
                    return named[0], None
                return None, "Employee identifier matched multiple directory records."

        # 2) Employee number is a secondary hard identifier when explicitly supplied.
        if enum:
            candidates = [e for e in all_employees if exact_id(e.employee_number) == enum]
            if name and len(candidates) > 1:
                candidates.sort(key=lambda e: _name_score(name, e.full_name), reverse=True)
            if len(candidates) == 1:
                return candidates[0], None

        if not name:
            return None, "Employee could not be matched because no employee name or identifier was extracted."

        # 3) Intelligent fuzzy ranking over the complete directory.
        ranked = []
        for e in all_employees:
            score = _name_score(name, e.full_name)
            evidence = {"name": score}

            # Organization fields are supporting evidence, not mandatory exact
            # gates. OCR frequently damages these fields; rejecting a strong
            # name match because of one typo caused false 'unidentified' cases.
            bonuses = []
            if department:
                s = _field_score(department, e.department)
                if s is not None:
                    bonuses.append((s, 5.0, 90.0))
            if office:
                s = _field_score(office, e.office)
                if s is not None:
                    bonuses.append((s, 5.0, 90.0))
            if manager:
                s = _field_score(manager, e.manager)
                if s is not None:
                    bonuses.append((s, 4.0, 88.0))

            for s, weight, strong_threshold in bonuses:
                # Only high-confidence organizational agreement contributes a
                # material bonus. Mild similarity is intentionally ignored.
                if s >= strong_threshold:
                    score += weight * ((s - strong_threshold) / (100.0 - strong_threshold) + 0.5)
                elif s >= 75:
                    score += weight * 0.15

            # Exact token agreement on a distinctive employee number, if the
            # AI extracted one under a different identifier field, is decisive.
            if enum and exact_id(e.employee_number) == enum:
                score += 18

            ranked.append((min(score, 100.0), e, evidence))

        ranked.sort(key=lambda x: x[0], reverse=True)
        best = ranked[0]
        second = ranked[1] if len(ranked) > 1 else (0.0, None, {})
        best_score, employee, _ = best

        # Auto scoring removes the employee confirmation window: the highest
        # scoring directory record is selected directly. Hard identifiers still
        # take precedence above this fuzzy ranking.
        if ClaimAutomationService.automatic_scoring_enabled() and employee:
            return employee, None

        margin = best_score - second[0]

        # Confidence tiers: near-perfect names may pass with a smaller margin;
        # weaker names need a meaningful gap from the next employee.
        qtokens = _tokens(name)
        if best_score >= 96:
            threshold, required_margin = 96, 1.5
        elif best_score >= 92:
            threshold, required_margin = 92, 3.0
        elif best_score >= 88 and len(qtokens) >= 2:
            threshold, required_margin = 88, 5.0
        else:
            threshold, required_margin = 90, 7.0

        if best_score >= threshold and margin >= required_margin:
            return employee, None

        return None, (
            f"Employee could not be confidently matched (name='{name}', "
            f"best='{employee.full_name}', score={best_score:.1f}, margin={margin:.1f})."
        )
