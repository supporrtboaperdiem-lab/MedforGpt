from pathlib import Path
from decimal import Decimal
import json
import re
import unicodedata
from openpyxl import load_workbook
from sqlalchemy import func

from app.extensions import db
from app.models.spouse_directory import SpouseDirectory
from app.models.employee import Employee


def norm(value):
    return " ".join(str(value or "").strip().casefold().split())


def id_norm(value):
    s = str(value or "").strip()
    if s.endswith(".0"):
        s = s[:-2]
    return s.lstrip(" ")


def _name_norm(value):
    text = unicodedata.normalize("NFKD", str(value or "")).encode("ascii", "ignore").decode("ascii").casefold()
    return " ".join(re.findall(r"[a-z0-9]+", text))


def _id_keys(value):
    value = id_norm(value)
    if not value:
        return set()
    return {value.casefold(), value.lstrip("0").casefold() or "0"}


def _name_score(left, right):
    left_norm, right_norm = _name_norm(left), _name_norm(right)
    if not left_norm or not right_norm:
        return 0
    if left_norm == right_norm:
        return 100
    try:
        from rapidfuzz.fuzz import WRatio, token_set_ratio, token_sort_ratio
        return max(WRatio(left_norm, right_norm), token_set_ratio(left_norm, right_norm), token_sort_ratio(left_norm, right_norm))
    except Exception:
        from difflib import SequenceMatcher
        return SequenceMatcher(None, left_norm, right_norm).ratio() * 100


def _strong_name_match(left, right, threshold=78):
    """Require at least two matching name tokens to avoid first-name-only matches."""
    left_norm, right_norm = _name_norm(left), _name_norm(right)
    if not left_norm or not right_norm:
        return False
    if left_norm == right_norm:
        return True
    left_tokens, right_tokens = left_norm.split(), right_norm.split()
    try:
        from rapidfuzz.fuzz import ratio
        similarity = ratio
    except Exception:
        from difflib import SequenceMatcher
        similarity = lambda a, b: SequenceMatcher(None, a, b).ratio() * 100
    matched = 0
    used = set()
    for token in left_tokens:
        best = max(((similarity(token, other), idx) for idx, other in enumerate(right_tokens) if idx not in used), default=(0, -1))
        if best[0] >= threshold:
            matched += 1
            used.add(best[1])
    return matched >= 2


class SpouseDirectoryService:
    @staticmethod
    def import_excel(path):
        path = Path(path)
        wb = load_workbook(path, read_only=True, data_only=True)
        ws = wb.active
        imported = updated = skipped = 0

        # The supplied workbook has its real header on row 3.
        header_row = None
        for row_no, row in enumerate(ws.iter_rows(min_row=1, max_row=10, values_only=True), 1):
            vals = [norm(v) for v in row]
            if "employee name" in vals and "name of spouse" in vals:
                header_row = row_no
                headers = vals
                break
        if not header_row:
            raise ValueError("Could not find Employee Name and Name of Spouse headers in spouse Excel file.")

        def col(name):
            try:
                return headers.index(norm(name))
            except ValueError:
                return None

        employee_number_i = col("Employee Name") - 1 if col("Employee Name") is not None else 1
        employee_name_i = col("Employee Name")
        job_i = col("Job Title")
        salary_i = col("Salary")
        place_i = col("Place of Assignment")
        dept_i = col("Dep't/District/Branch")
        spouse_i = col("Name of Spouse")
        remark_i = col("Remark")

        for row in ws.iter_rows(min_row=header_row + 1, values_only=True):
            employee_number = id_norm(row[employee_number_i] if employee_number_i is not None and employee_number_i < len(row) else "")
            employee_name = str(row[employee_name_i] or "").strip() if employee_name_i is not None else ""
            spouse_name = str(row[spouse_i] or "").strip() if spouse_i is not None else ""
            if not employee_number or not employee_name or not spouse_name:
                skipped += 1
                continue

            salary = row[salary_i] if salary_i is not None and salary_i < len(row) else None
            try:
                salary = Decimal(str(salary)) if salary not in (None, "") else None
            except Exception:
                salary = None

            existing = SpouseDirectory.query.filter(
                SpouseDirectory.employee_number == employee_number,
                func.lower(SpouseDirectory.spouse_name) == spouse_name.casefold(),
            ).first()
            values = dict(
                employee_number=employee_number,
                employee_name=employee_name,
                spouse_name=spouse_name,
                job_title=str(row[job_i] or "").strip() if job_i is not None else None,
                salary=salary,
                place_of_assignment=str(row[place_i] or "").strip() if place_i is not None else None,
                department=str(row[dept_i] or "").strip() if dept_i is not None else None,
                remark=str(row[remark_i] or "").strip() if remark_i is not None else None,
                is_active=True,
            )
            if existing:
                for k, v in values.items(): setattr(existing, k, v)
                updated += 1
            else:
                db.session.add(SpouseDirectory(**values))
                imported += 1
        db.session.commit()
        return {"imported": imported, "updated": updated, "skipped": skipped}

    @staticmethod
    def get_for_employee_number(employee_number):
        n = id_norm(employee_number)
        return SpouseDirectory.query.filter_by(employee_number=n, is_active=True).order_by(SpouseDirectory.spouse_name.asc()).all()

    @staticmethod
    def find_for_employee(employee):
        if not employee:
            return []
        if isinstance(employee, (str, int)):
            identifiers = [employee]
        else:
            identifiers = [getattr(employee, key, None) for key in ("employee_number", "employee_code", "employee_id")]
        rows, seen = [], set()
        for identifier in identifiers:
            for row in SpouseDirectoryService.get_for_employee_number(identifier):
                key = (row.employee_number, row.spouse_name.casefold())
                if key not in seen:
                    seen.add(key)
                    rows.append(row)
        return sorted(rows, key=lambda row: row.spouse_name.casefold())

    @staticmethod
    def _resolve_employee_for_spouse(spouse_row, current_employee=None):
        """Resolve the employee linked to a spouse-directory row, not the claim's prior guess."""
        if not spouse_row:
            return None

        source_number = id_norm(getattr(spouse_row, "employee_number", None))
        source_name = getattr(spouse_row, "employee_name", "") or ""
        employees = Employee.query.all()

        # The spouse workbook's employee number is the strongest key. Require
        # the employee name to agree as well, because legacy ID columns can overlap.
        for field in ("employee_number", "employee_id", "employee_code"):
            exact = [
                employee for employee in employees
                if source_number and _id_keys(getattr(employee, field, None))
                and _id_keys(getattr(employee, field, None)).intersection(_id_keys(source_number))
            ]
            confirmed = [
                employee for employee in exact
                if _strong_name_match(source_name, getattr(employee, "full_name", ""), 70)
            ]
            unique = {getattr(employee, "id", id(employee)): employee for employee in confirmed}
            if len(unique) == 1:
                return next(iter(unique.values()))
            if len(unique) > 1:
                return None

        # Some employee imports carry the source number in a different field,
        # or omit it. Use the directory's employee name only as a cautious fallback.
        ranked = []
        for employee in employees:
            name = getattr(employee, "full_name", "") or ""
            if _strong_name_match(source_name, name, 70):
                ranked.append((_name_score(source_name, name), employee))
        ranked.sort(key=lambda pair: pair[0], reverse=True)
        if ranked:
            best_score, best_employee = ranked[0]
            second_score = ranked[1][0] if len(ranked) > 1 else 0
            if best_score >= 75 and best_score - second_score >= 6:
                return best_employee

        # Never retain a known-wrong employee merely because the spouse owner
        # could not be resolved. Returning None lets the caller flag verification.
        return None

    @staticmethod
    def classify_claim_as_spouse(claim, directory_rows=None):
        """Identify a spouse from the patient name first, then assign that spouse's linked employee.

        A claim's existing employee link is not authoritative for spouse ownership:
        it may be the exact bug being repaired. Spouse identity is matched against
        the spouse directory first; the matched row's employee number/name then
        resolves the payroll owner. Ordinary employee-patient claims are left alone.
        """
        if not claim:
            return False

        already_spouse = str(getattr(claim, "beneficiary_type", "") or "").upper() == "SPOUSE"
        current_employee = getattr(claim, "employee", None)
        current_employee_name = getattr(current_employee, "full_name", None) or getattr(claim, "employee_owner_name", None) or ""

        patient_candidates = []
        # The claim's patient field is the primary evidence. Do not let a stale
        # beneficiary label override a clear employee-patient name.
        if getattr(claim, "patient_name", None):
            patient_candidates.append(str(claim.patient_name))

        extraction_texts = []
        extracted_beneficiary_types = []
        for receipt in (getattr(claim, "receipts", []) or []):
            raw_json = getattr(receipt, "ai_extraction_json", None)
            if not raw_json:
                continue
            try:
                payload = json.loads(raw_json)
            except (TypeError, ValueError):
                continue

            if isinstance(payload, dict) and str(payload.get("beneficiary_type", "")).upper() == "SPOUSE":
                extracted_beneficiary_types.append("SPOUSE")

            def walk(obj):
                if isinstance(obj, dict):
                    for key, value in obj.items():
                        key_l = str(key).casefold()
                        if key_l in {"patient", "beneficiary", "spouse", "patient_name", "beneficiary_name", "spouse_name"}:
                            if isinstance(value, str):
                                patient_candidates.append(value)
                            elif isinstance(value, dict):
                                for name_key in ("name", "full_name", "patient_name", "beneficiary_name", "spouse_name"):
                                    if value.get(name_key):
                                        patient_candidates.append(str(value[name_key]))
                        walk(value)
                elif isinstance(obj, list):
                    for value in obj:
                        walk(value)
            walk(payload)
            extraction_texts.append(json.dumps(payload, ensure_ascii=False, default=str))

        beneficiary_name = str(getattr(claim, "beneficiary_name", "") or "").strip()
        patient_name = str(getattr(claim, "patient_name", "") or "").strip()
        # Explicit user rule: any bracket/parenthesis in the beneficiary name
        # makes this a spouse claim, regardless of other patient/employee signals.
        bracket_rule_spouse = bool(re.search(r"[()\[\]{}<>]", beneficiary_name))
        bracket_pattern = re.compile(r"\([^()]*\)|\[[^\[\]]*\]|\{[^{}]*\}|<[^<>]*>")
        if bracket_rule_spouse:
            for part in bracket_pattern.split(beneficiary_name):
                if part.strip():
                    patient_candidates.append(part.strip())
            for match in bracket_pattern.finditer(beneficiary_name):
                if match.group(0)[1:-1].strip():
                    patient_candidates.append(match.group(0)[1:-1].strip())
        explicit_spouse = already_spouse or bool(extracted_beneficiary_types) or bracket_rule_spouse
        if beneficiary_name and (explicit_spouse or not patient_name or _name_norm(beneficiary_name) != _name_norm(patient_name)):
            patient_candidates.append(beneficiary_name)

        # De-duplicate while preserving priority order.
        deduped_candidates = []
        seen_candidates = set()
        for candidate in patient_candidates:
            candidate = str(candidate or "").strip()
            key = _name_norm(candidate)
            if key and key not in seen_candidates:
                seen_candidates.add(key)
                deduped_candidates.append(candidate)
        if not deduped_candidates:
            return False

        # Most claims are employee claims. If the actual patient clearly matches
        # the currently linked employee and no explicit spouse selection exists,
        # preserve that employee claim instead of matching a namesake spouse.
        primary_patient = deduped_candidates[0]
        if not explicit_spouse and current_employee_name and _strong_name_match(primary_patient, current_employee_name, 78):
            return False

        directory_rows = directory_rows if directory_rows is not None else SpouseDirectory.query.filter_by(is_active=True).all()
        directory_rows = [row for row in directory_rows if getattr(row, "is_active", True)]

        # First match the beneficiary/patient globally against spouse names.
        # Only after the spouse row is identified do we resolve its employee owner.
        spouse_matches = []
        for row in directory_rows:
            if any(_strong_name_match(candidate, row.spouse_name, 72) for candidate in deduped_candidates):
                score = max(_name_score(candidate, row.spouse_name) for candidate in deduped_candidates)
                spouse_matches.append((score, row))
        if not spouse_matches:
            if not bracket_rule_spouse:
                return False
            # Brackets alone are authoritative for spouse classification. If no
            # spouse-directory row can safely identify the owner, keep it in
            # review rather than assigning it to the current employee by guess.
            changed = False
            if str(getattr(claim, "beneficiary_type", "") or "").upper() != "SPOUSE":
                claim.beneficiary_type = "SPOUSE"
                changed = True
            if Decimal(str(getattr(claim, "coverage_percentage", 100) or 100)) != Decimal("90.00"):
                claim.coverage_percentage = Decimal("90.00")
                changed = True
            if getattr(claim, "employee_id", None) is not None:
                claim.employee = None
                claim.employee_id = None
                changed = True
            if getattr(claim, "employee_owner_name", None) is not None:
                claim.employee_owner_name = None
                changed = True
            for item in (getattr(claim, "items", []) or []):
                if hasattr(item, "employee_id") and item.employee_id is not None:
                    item.employee_id = None
                    changed = True
            if getattr(claim, "status", None) != "PENDING_REVIEW":
                claim.status = "PENDING_REVIEW"
                changed = True
            return changed

        spouse_matches.sort(key=lambda pair: pair[0], reverse=True)
        best_score = spouse_matches[0][0]
        top_matches = [row for score, row in spouse_matches if score >= best_score - 4]
        owners = {id_norm(getattr(row, "employee_number", None)) for row in top_matches}
        if len(owners) > 1:
            # Same/near-identical spouse names attached to different employees
            # are ambiguous. Do not guess or leave payroll assigned to a known
            # possibly-wrong employee; clear the owner and keep the claim in review.
            claim.employee = None
            claim.employee_id = None
            claim.employee_owner_name = None
            for item in (getattr(claim, "items", []) or []):
                if hasattr(item, "employee_id"):
                    item.employee_id = None
            if hasattr(claim, "status"):
                claim.status = "PENDING_REVIEW"
            return True

        matched_spouse = top_matches[0]
        linked_employee = SpouseDirectoryService._resolve_employee_for_spouse(matched_spouse, current_employee=current_employee)
        if linked_employee is None:
            # A spouse was recognized, but the directory's employee owner could
            # not be safely mapped to the employee table. Hold for verification.
            changed = False
            if not already_spouse:
                claim.beneficiary_type = "SPOUSE"
                changed = True
            if getattr(claim, "beneficiary_name", None) != matched_spouse.spouse_name:
                claim.beneficiary_name = matched_spouse.spouse_name
                changed = True
            if Decimal(str(getattr(claim, "coverage_percentage", 100) or 100)) != Decimal("90.00"):
                claim.coverage_percentage = Decimal("90.00")
                changed = True
            # Do not attribute a payroll deduction to the old employee if the
            # spouse row cannot be mapped to a verified employee record.
            if getattr(claim, "employee_id", None) is not None:
                claim.employee = None
                claim.employee_id = None
                changed = True
            if getattr(claim, "employee_owner_name", None) is not None:
                claim.employee_owner_name = None
                changed = True
            for item in (getattr(claim, "items", []) or []):
                if hasattr(item, "employee_id") and item.employee_id is not None:
                    item.employee_id = None
                    changed = True
            if getattr(claim, "status", None) != "PENDING_REVIEW":
                claim.status = "PENDING_REVIEW"
                changed = True
            return changed

        changed = False
        if not already_spouse:
            claim.beneficiary_type = "SPOUSE"
            changed = True
        if getattr(claim, "beneficiary_name", None) != matched_spouse.spouse_name:
            claim.beneficiary_name = matched_spouse.spouse_name
            changed = True
        if Decimal(str(getattr(claim, "coverage_percentage", 100) or 100)) != Decimal("90.00"):
            claim.coverage_percentage = Decimal("90.00")
            changed = True

        # Critical correction: replace a wrong employee association with the
        # employee linked to the matched spouse-directory row. Keep the OCR
        # patient name intact for audit; canonical spouse name is stored separately.
        if getattr(claim, "employee_id", None) != getattr(linked_employee, "id", None):
            claim.employee = linked_employee
            claim.employee_id = linked_employee.id
            changed = True
        if getattr(claim, "employee_owner_name", None) != getattr(linked_employee, "full_name", None):
            claim.employee_owner_name = linked_employee.full_name
            changed = True
        for item in (getattr(claim, "items", []) or []):
            if hasattr(item, "employee_id") and item.employee_id != linked_employee.id:
                item.employee_id = linked_employee.id
                changed = True

        return changed

    @staticmethod
    def list_all():
        return SpouseDirectory.query.filter_by(is_active=True).order_by(SpouseDirectory.employee_name.asc()).all()
