from flask_login import current_user


class AuthorizationService:

    @staticmethod
    def role_name(user=None):
        if user is None:
            user = current_user

        if not user:
            return None

        value = getattr(
            user,
            "role_name",
            None
        )

        if callable(value):
            value = value()

        if value:
            return str(
                value
            ).strip().lower()

        role = getattr(
            user,
            "role",
            None
        )

        if role:
            value = getattr(
                role,
                "name",
                None
            )

            if value:
                return str(
                    value
                ).strip().lower()

        if getattr(
            user,
            "is_admin",
            False
        ):
            return "administrator"

        return None

    @staticmethod
    def has_role(*roles, user=None):
        current_role = (
            AuthorizationService.role_name(user)
        )

        if not current_role:
            return False

        allowed = {
            str(role).strip().lower()
            for role in roles
        }

        return current_role in allowed

    @staticmethod
    def is_administrator(user=None):
        if user is None:
            user = current_user

        if not user:
            return False

        return (
            getattr(
                user,
                "is_admin",
                False
            )
            or AuthorizationService.has_role(
                "administrator",
                "admin",
                user=user
            )
        )

    @staticmethod
    def is_employee(user=None):
        return AuthorizationService.has_role(
            "employee",
            user=user
        )

    @staticmethod
    def is_medical_officer(user=None):
        return AuthorizationService.has_role(
            "medical officer",
            "medical_officer",
            "medical-officer",
            user=user
        )

    @staticmethod
    def is_hr(user=None):
        return AuthorizationService.has_role(
            "hr",
            "human resources",
            "human_resource",
            user=user
        )

    @staticmethod
    def owns_claim(claim, user=None):

        if user is None:
            user = current_user

        if not claim or not user:
            return False

        # ========================================================
        # PRIMARY OWNERSHIP CHECK
        #
        # submitted_by_id points directly to the authenticated
        # User who created the claim.
        # ========================================================

        submitted_by_id = getattr(
            claim,
            "submitted_by_id",
            None
        )

        if submitted_by_id is not None:

            try:
                return int(submitted_by_id) == int(user.id)

            except (TypeError, ValueError):
                return False


        # ========================================================
        # LEGACY FALLBACK
        #
        # Keep the old employee relationship available for old
        # records. This does NOT affect newly submitted claims.
        # ========================================================

        employee = getattr(
            claim,
            "employee",
            None
        )

        if employee:

            user_employee_id = getattr(
                user,
                "employee_id",
                None
            )

            if user_employee_id is not None:

                try:
                    return (
                        int(employee.id)
                        == int(user_employee_id)
                    )

                except (TypeError, ValueError):
                    pass


        return False

    @staticmethod
    def can_view_claim(claim, user=None):
        if user is None:
            user = current_user

        if not user:
            return False

        if AuthorizationService.is_administrator(user):
            return True

        if AuthorizationService.is_medical_officer(user):
            # Medical Officers may view only claims they personally submitted.
            return AuthorizationService.owns_claim(claim, user)

        if AuthorizationService.is_hr(user):
            return True

        if AuthorizationService.is_employee(user):
            return AuthorizationService.owns_claim(
                claim,
                user
            )

        return False

    @staticmethod
    def can_submit_claim(claim=None, user=None):
        if user is None:
            user = current_user

        return (
            AuthorizationService.is_employee(user)
            or AuthorizationService.is_medical_officer(user)
            or AuthorizationService.is_hr(user)
        )

    @staticmethod
    def can_medically_review(claim=None, user=None):
        if user is None:
            user = current_user

        return AuthorizationService.is_medical_officer(user)

    @staticmethod
    def can_hr_review(claim=None, user=None):
        if user is None:
            user = current_user

        return AuthorizationService.is_hr(user)

    @staticmethod
    def can_manage_system(user=None):
        return AuthorizationService.is_administrator(user)

    @staticmethod
    def can_submit_price_lists(user=None):
        """HR and Medical Officers may submit price lists."""
        if user is None:
            user = current_user

        return (
            AuthorizationService.is_administrator(user)
            or AuthorizationService.is_hr(user)
            or AuthorizationService.is_medical_officer(user)
        )

    @staticmethod
    def can_review_price_lists(user=None):
        """Only HR is the price-list approver; administrators retain system access."""
        if user is None:
            user = current_user

        return (
            AuthorizationService.is_administrator(user)
            or AuthorizationService.is_hr(user)
        )

    @staticmethod
    def can_manage_price_lists(user=None):
        return AuthorizationService.can_review_price_lists(user)

    @staticmethod
    def can_manage_institutions(user=None):
        return AuthorizationService.is_administrator(user)

    @staticmethod
    def can_manage_users(user=None):
        return AuthorizationService.is_administrator(user)
