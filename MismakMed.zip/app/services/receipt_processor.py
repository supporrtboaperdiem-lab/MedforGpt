from app.services.price_validator import PriceValidator
from app.services.reimbursement_engine import ReimbursementEngine
from app.services.duplicate_detector import DuplicateDetector



class ReceiptProcessor:


    def __init__(self):

        self.validator = PriceValidator()

        self.engine = ReimbursementEngine()

        self.duplicate = DuplicateDetector()



    def process(self, receipt_data):


        validated_items = []


        for item in receipt_data["items"]:


            result = self.validator.validate(

                receipt_data["institution_id"],

                item["service"],

                item["claimed_amount"]

            )


            item.update(result)


            validated_items.append(item)



        totals = self.engine.calculate(
            validated_items
        )



        receipt_data["items"] = validated_items

        receipt_data["totals"] = totals


        receipt_data["receipt_hash"] = (

            self.duplicate.create_hash(
                receipt_data
            )

        )


        receipt_data["duplicate"] = (

            self.duplicate.check(
                receipt_data["receipt_hash"]
            )

        )


        return receipt_data