"""Receipt-level fraud/duplicate detection.

The old detector was never connected to the medical-claim submission path and
also referenced a non-existent legacy ``Receipt`` model.  This detector works
against ``MedicalClaimReceipt`` and combines several independent signals:

* exact SHA-256 of the uploaded file;
* perceptual image hash (same receipt photographed/re-encoded differently);
* printed receipt/invoice/reference number + date + provider;
* normalized receipt metadata and line-item fingerprint.

The server upload timestamp is recorded separately from the printed receipt
date.  A receipt can therefore be rejected as a duplicate without confusing
"when the file was uploaded" with "when the receipt was issued".
"""

import hashlib
import json
import re
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

import cv2
import numpy as np

from app.models.claim import MedicalClaimReceipt


class DuplicateReceiptError(ValueError):
    """Raised when an uploaded receipt has already been submitted."""

    def __init__(self, message, existing_receipt=None):
        super().__init__(message)
        self.existing_receipt = existing_receipt


class DuplicateDetector:
    # Duplicate blocking follows the application's explicit 99% rule.
    # A 64-bit pHash can only represent 100%, 98.4375%, 96.875%, ...;
    # therefore >=99% means a zero-distance pHash. Exact file hashes are
    # also 100% matches and remain a hard duplicate signal.
    PHASH_BITS = 64
    PHASH_MAX_DISTANCE = 0
    VISUAL_MIN_CONFIDENCE = 0.99

    @staticmethod
    def _norm(value):
        value = "" if value is None else str(value)
        value = value.strip().upper()
        return re.sub(r"[^A-Z0-9]+", "", value)

    @staticmethod
    def _date_key(value):
        if not value:
            return ""
        if isinstance(value, datetime):
            return value.date().isoformat()
        raw = str(value).strip().replace("Z", "+00:00")
        for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%m/%d/%Y", "%d.%m.%Y"):
            try:
                return datetime.strptime(raw, fmt).date().isoformat()
            except ValueError:
                pass
        try:
            return datetime.fromisoformat(raw).date().isoformat()
        except ValueError:
            return DuplicateDetector._norm(raw)

    @staticmethod
    def _money_key(value):
        if value in (None, ""):
            return ""
        try:
            return format(Decimal(str(value).replace(",", "")).quantize(Decimal("0.01")), "f")
        except (InvalidOperation, ValueError):
            return DuplicateDetector._norm(value)

    @staticmethod
    def sha256_file(file_path):
        digest = hashlib.sha256()
        with open(file_path, "rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    @staticmethod
    def _image_phash(file_path):
        """Return a dependency-light 64-bit perceptual hash.

        The previous implementation depended on ``cv2.img_hash`` from the
        optional opencv-contrib package.  Standard ``opencv-python`` does not
        provide that module, which meant the visual duplicate detector silently
        returned ``None`` on many installations.  We therefore implement the
        classic DCT pHash directly with OpenCV primitives that are already
        required by the application.
        """
        try:
            path = Path(file_path)
            if path.suffix.lower() == ".pdf":
                import fitz
                document = fitz.open(str(path))
                if not document:
                    return None
                page = document[0]
                pix = page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
                image = cv2.imdecode(
                    np.frombuffer(pix.samples, dtype="uint8"),
                    cv2.IMREAD_GRAYSCALE,
                )
                document.close()
            else:
                image = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
            if image is None:
                return None

            # Normalize the whole document to a small grayscale matrix, then
            # use the lowest 8x8 DCT frequencies. This remains reasonably
            # stable under JPEG compression, resizing and moderate camera
            # changes while remaining deterministic.
            image = cv2.resize(image, (32, 32), interpolation=cv2.INTER_AREA)
            image = np.float32(image)
            dct = cv2.dct(image)
            low = dct[:8, :8]
            median = float(np.median(low[1:, :]))
            bits = (low > median).flatten()
            value = 0
            for bit in bits:
                value = (value << 1) | int(bool(bit))
            return value.to_bytes(8, byteorder="big", signed=False).hex()
        except Exception:
            return None

    @staticmethod
    def _hamming(hex_a, hex_b):
        try:
            a = bytes.fromhex(hex_a)
            b = bytes.fromhex(hex_b)
            if len(a) != len(b):
                return None
            return sum((x ^ y).bit_count() for x, y in zip(a, b))
        except Exception:
            return None

    @classmethod
    def _phash_similarity(cls, hex_a, hex_b):
        distance = cls._hamming(hex_a, hex_b)
        if distance is None:
            return None
        return 1.0 - (distance / float(cls.PHASH_BITS))

    @classmethod
    def metadata_fingerprint(cls, ai_document):
        document = (ai_document or {}).get("document") or {}
        institution = document.get("institution") or {}
        receipt = document.get("receipt") or {}
        totals = document.get("totals") or {}
        items = (ai_document or {}).get("items") or []

        identifiers = [
            cls._norm(receipt.get("receipt_number")),
            cls._norm(receipt.get("invoice_number")),
            cls._norm(receipt.get("fs_number")),
            cls._norm(receipt.get("reference_number")),
        ]
        identifier = next((x for x in identifiers if x), "")
        date_key = cls._date_key(receipt.get("receipt_date") or receipt.get("transaction_date"))
        provider = cls._norm(institution.get("name"))
        patient = cls._norm((document.get("patient") or {}).get("name"))
        total = cls._money_key(totals.get("total"))
        item_parts = []
        for item in items:
            if not isinstance(item, dict):
                continue
            name = cls._norm(item.get("service_name"))
            amount = cls._money_key(item.get("receipt_price"))
            if name or amount:
                item_parts.append(f"{name}:{amount}")
        item_parts.sort()

        payload = "|".join([provider, patient, date_key, total, identifier, ";".join(item_parts)])
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    _bundle_cache = {}

    @classmethod
    def create_fingerprint_bundle(cls, file_path, ai_document):
        path = str(file_path)
        try:
            stat = Path(path).stat()
            cache_key = (path, stat.st_size, stat.st_mtime_ns)
        except OSError:
            cache_key = (path, None, None)

        cached = cls._bundle_cache.get(cache_key)
        if cached is not None:
            # Metadata is derived from the AI result, so only reuse the expensive
            # file/image hashes here. Recompute metadata from the current document.
            return cached[0], cached[1], cls.metadata_fingerprint(ai_document)

        file_sha256 = cls.sha256_file(file_path)
        phash = cls._image_phash(file_path)
        cls._bundle_cache[cache_key] = (file_sha256, phash)
        # Keep this process cache bounded.
        if len(cls._bundle_cache) > 256:
            cls._bundle_cache.pop(next(iter(cls._bundle_cache)))
        metadata = cls.metadata_fingerprint(ai_document)
        return file_sha256, phash, metadata

    @classmethod
    def _metadata_identifier_key(cls, ai_document):
        document = (ai_document or {}).get("document") or {}
        institution = document.get("institution") or {}
        receipt = document.get("receipt") or {}
        identifier = next(
            (
                cls._norm(receipt.get(name))
                for name in ("receipt_number", "invoice_number", "fs_number", "reference_number")
                if cls._norm(receipt.get(name))
            ),
            "",
        )
        if not identifier:
            return None
        date_key = cls._date_key(receipt.get("receipt_date") or receipt.get("transaction_date"))
        return f"{cls._norm(institution.get('name'))}|{identifier}|{date_key}"

    @classmethod
    def find_duplicate(cls, file_sha256, phash, metadata_fingerprint, ai_document, exclude_id=None):
        query = MedicalClaimReceipt.query
        if exclude_id:
            query = query.filter(MedicalClaimReceipt.id != exclude_id)

        # Strongest signal: exact file bytes.
        existing = query.filter_by(file_sha256=file_sha256).first()
        if existing:
            return existing, "exact file hash"

        # A receipt/invoice identifier + date is useful evidence, but it is NOT
        # sufficient by itself for the user's 99% duplicate rule. It is only
        # used together with the visual/full-metadata checks below.
        identifier_key = cls._metadata_identifier_key(ai_document)

        # Visual similarity is intentionally NOT a standalone fraud decision.
        # pHash is useful for re-encoded/re-photographed copies, but a low
        # distance can occur between unrelated documents with similar layouts.
        # Require the strictest visual threshold AND matching receipt identity
        # context (provider/date/identifier or full metadata fingerprint).
        if phash:
            identifier_key = cls._metadata_identifier_key(ai_document)
            visual_query = query.filter(MedicalClaimReceipt.image_phash.isnot(None))
            if identifier_key:
                # Only compare visually against receipts with the same strong
                # provider + identifier + printed-date identity. This makes the
                # expensive visual scan proportional to a small candidate set.
                visual_query = visual_query.filter(
                    MedicalClaimReceipt.receipt_metadata_key == identifier_key
                )
            else:
                # Without a document identifier, do not use visual similarity as
                # a blocking decision; full metadata fingerprint is still checked.
                visual_query = None
            rows = visual_query.all() if visual_query is not None else []
            best = None
            best_distance = None
            for row in rows:
                distance = cls._hamming(phash, row.image_phash)
                if distance is None or distance > cls.PHASH_MAX_DISTANCE:
                    continue

                same_identifier = bool(identifier_key) and identifier_key == getattr(row, "receipt_metadata_key", None)
                same_metadata = bool(metadata_fingerprint) and metadata_fingerprint == getattr(row, "receipt_metadata_fingerprint", None)

                # A >=99% visual match is accepted as duplicate only when it
                # also has a strong document-level identity signal. This eliminates
                # false positives from similar receipt layouts.
                if not (same_identifier or same_metadata):
                    continue

                if best_distance is None or distance < best_distance:
                    best, best_distance = row, distance
            if best:
                return best, f"99%+ visual match with matching receipt identity (pHash distance {best_distance})"

        # Do NOT block on metadata fingerprint alone. Two legitimate receipts can
        # share provider/date/total/item text, especially when a receipt number is
        # unreadable. Under the 99% rule metadata is supporting evidence only; an
        # actual blocking decision requires an exact file hash or >=99% visual
        # similarity with matching receipt identity context.
        return None, None

    @classmethod
    def check_or_raise(cls, file_path, ai_document):
        file_sha256, phash, metadata = cls.create_fingerprint_bundle(file_path, ai_document)
        existing, reason = cls.find_duplicate(file_sha256, phash, metadata, ai_document)
        if existing:
            claim_id = getattr(existing, "claim_id", None)
            when = getattr(existing, "created_at", None)
            detail = f"Existing claim #{claim_id}" if claim_id else "An existing claim"
            if when:
                detail += f" was submitted on {when.strftime('%Y-%m-%d %H:%M:%S UTC')}"
            raise DuplicateReceiptError(
                f"Duplicate receipt rejected: this receipt was already submitted. "
                f"Detection method: {reason}. {detail}.",
                existing_receipt=existing,
            )
        return {
            "file_sha256": file_sha256,
            "image_phash": phash,
            "receipt_metadata_fingerprint": metadata,
            "receipt_metadata_key": cls._metadata_identifier_key(ai_document),
        }

    # Backwards-compatible API used by the older standalone ReceiptProcessor.
    def create_hash(self, data):
        return self.metadata_fingerprint({"document": {"receipt": {
            "receipt_number": data.get("receipt_number"),
            "receipt_date": data.get("receipt_date"),
        }, "totals": {"total": data.get("claimed_total")}}, "items": data.get("items") or []})

    def check(self, receipt_hash):
        return MedicalClaimReceipt.query.filter_by(receipt_metadata_fingerprint=receipt_hash).first() is not None
