from flask_login import current_user

from app.services.authorization_service import (
    AuthorizationService
)


class ClaimAuthorizationService:

    @staticmethod
    def can_view(claim):
        return AuthorizationService.can_view_claim(
            claim,
            current_user
        )

    @staticmethod
    def can_edit(claim):
        if not current_user.is_authenticated:
            return False

        if AuthorizationService.is_administrator(
            current_user
        ):
            return True

        if not AuthorizationService.is_employee(
            current_user
        ):
            return False

        if not AuthorizationService.owns_claim(
            claim,
            current_user
        ):
            return False

        status = str(
            getattr(
                claim,
                "status",
                ""
            )
        ).strip().upper()

        return status in {
            "",
            "DRAFT"
        }

    @staticmethod
    def can_submit(claim):
        if not current_user.is_authenticated:
            return False

        return AuthorizationService.can_submit_claim(
            claim,
            current_user
        )

    @staticmethod
    def can_review(claim):
        return AuthorizationService.can_hr_review(
            claim,
            current_user
        )

    @staticmethod
    def can_approve(claim):
        if not current_user.is_authenticated:
            return False

        return AuthorizationService.is_hr(
            current_user
        )

    @staticmethod
    def can_reject(claim):
        return ClaimAuthorizationService.can_approve(
            claim
        )
