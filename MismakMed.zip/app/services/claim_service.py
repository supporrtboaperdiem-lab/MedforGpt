import json
import os
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from flask import current_app
from uuid import uuid4
import time
import re
import unicodedata
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed

from werkzeug.utils import secure_filename
from sqlalchemy.exc import IntegrityError

from app.models.institution import Institution
from app.models.claim import MedicalClaimReceipt
from app.repositories.active_price_repository import ActivePriceRepository
from app.repositories.claim_repository import ClaimRepository
from app.services.ollama_claim_extraction_service import (
    OllamaClaimExtractionService,
    OllamaUnavailable,
)
from app.services.authorization_service import AuthorizationService
from app.services.mail_service import send_claim_action_notification, send_claim_batch_notification
from app.services.employee_directory_service import EmployeeDirectoryService, norm as normalize_directory_text
from app.services.claim_automation_service import ClaimAutomationService
from app.services.pharmacy_exclusion_service import is_excluded
from app.services.spouse_directory_service import SpouseDirectoryService
from app.services.duplicate_detector import DuplicateDetector, DuplicateReceiptError
try:
    from rapidfuzz.fuzz import ratio, WRatio, token_set_ratio, token_sort_ratio
except ImportError:  # pragma: no cover - requirements-current includes RapidFuzz
    from difflib import SequenceMatcher
    def ratio(a, b): return SequenceMatcher(None, a, b).ratio() * 100
    def WRatio(a, b): return ratio(a, b)
    def token_set_ratio(a, b):
        sa, sb = set(a.split()), set(b.split())
        return ratio(" ".join(sorted(sa)), " ".join(sorted(sb)))
    def token_sort_ratio(a, b):
        return ratio(" ".join(sorted(a.split())), " ".join(sorted(b.split())))


class ClaimResolutionRequired(Exception):
    """Raised when a human must resolve an ambiguous receipt identity."""
    def __init__(self, token, details):
        super().__init__("Human resolution is required before this claim can be submitted.")
        self.token = token
        self.details = details


class ClaimService:
    @staticmethod
    def _debug_log(message, *args, level="INFO"):
        """Emit submission diagnostics to both console and Flask app.log."""
        try:
            rendered = message % args if args else str(message)
        except Exception:
            rendered = f"{message} {args!r}"
        line = f"[CLAIM][TRACE] {rendered}"
        print(line, flush=True)
        try:
            logger = current_app.logger
            getattr(logger, level.lower(), logger.info)(line)
        except Exception:
            pass

    @staticmethod
    def _append_batch_issues(result, issues):
        """Keep successful claim creation while reporting skipped/failed receipts."""
        if not issues:
            return result
        success, message, claim_id = result
        details = []
        for issue in issues[:20]:
            details.append(f"{issue.get('filename', 'Unknown file')}: {issue.get('reason', 'not processed')}")
        if len(issues) > 20:
            details.append(f"...and {len(issues) - 20} additional receipt issue(s). See application logs.")
        summary = (
            f" Batch report: {len(issues)} receipt(s) were skipped or could not be extracted. "
            + " | ".join(details)
        )
        return success, f"{message}{summary}", claim_id

    NORMAL = "NORMAL"
    OPTICS = "OPTICS"
    PHARMACY = "PHARMACY"

    BENEFICIARY_EMPLOYEE = "EMPLOYEE"
    BENEFICIARY_SPOUSE = "SPOUSE"
    EMPLOYEE_COVERAGE = Decimal("100.00")
    SPOUSE_COVERAGE = Decimal("90.00")

    ALLOWED_CATEGORIES = {NORMAL, OPTICS, PHARMACY}

    @staticmethod
    def _repair_spouse_labels(claims):
        """Persist directory-backed spouse classifications for existing claims."""
        changed = False
        claims = list(claims or [])
        directory_rows = None
        if claims:
            try:
                from app.models.spouse_directory import SpouseDirectory
                directory_rows = SpouseDirectory.query.filter_by(is_active=True).all()
            except Exception:
                directory_rows = None
        for claim in claims:
            try:
                if SpouseDirectoryService.classify_claim_as_spouse(claim, directory_rows=directory_rows):
                    changed = True
                # Migrate legacy Bank-excluded pharmacy lines to the current
                # accounting rule: full institution reimbursement, with the
                # 100% amount recorded separately as employee payroll deduction.
                if getattr(claim, "category", None) == ClaimService.PHARMACY:
                    for item in (getattr(claim, "items", []) or []):
                        if getattr(item, "validation_status", "") == "EXCLUDED_100":
                            receipt_amount = Decimal(str(getattr(item, "receipt_price", 0) or 0))
                            reimbursed_amount = Decimal(str(getattr(item, "reimbursable_amount", 0) or 0))
                            if receipt_amount > 0 and reimbursed_amount != receipt_amount:
                                item.reimbursable_amount = receipt_amount
                                item.difference = None
                                changed = True
            except Exception as exc:
                ClaimService._debug_log("SPOUSE_CLASSIFICATION_SKIPPED claim_id=%s error=%r", getattr(claim, "id", None), exc, level="WARNING")
        if changed:
            from app.extensions import db
            try:
                db.session.commit()
            except Exception:
                db.session.rollback()
                raise
        return claims

    @staticmethod
    def list_claims():
        return ClaimService._repair_spouse_labels(ClaimRepository.get_all())

    @staticmethod
    def list_claims_by_user(user_id):
        return ClaimService._repair_spouse_labels(ClaimRepository.get_by_submitter(user_id))

    @staticmethod
    def list_institutions():
        return Institution.query.order_by(Institution.name.asc()).all()

    @staticmethod
    def list_claim_submission_institutions(user=None):
        """
        Return institutions that are eligible for a Normal claim.

        HR and Medical Officer claims must be submitted only against an
        institution with an active, approved price-list batch. Employees
        retain the existing institution list because their non-Normal
        categories do not require price-list validation.
        """
        if not user or not user.is_authenticated:
            return []

        if AuthorizationService.is_hr(user) or AuthorizationService.is_medical_officer(user):
            institution_ids = ActivePriceRepository.get_active_institution_ids()
            if not institution_ids:
                return []
            return (
                Institution.query
                .filter(Institution.id.in_(institution_ids))
                .order_by(Institution.name.asc())
                .all()
            )

        return ClaimService.list_institutions()

    @staticmethod
    def can_submit_normal_claim(user=None):
        """Whether a user may currently start a Normal claim submission."""
        if not user or not user.is_authenticated:
            return False

        if AuthorizationService.is_hr(user):
            return True
        # Role equivalent used by the route layer: AuthorizationService.is_medical_officer(current_user)
        if AuthorizationService.is_medical_officer(user):
            return True
        return False

        # A missing price list no longer blocks submission. Affected Normal
        # items are recorded as PRICE_LIST_UNAVAILABLE for HR review.
        return True

    @staticmethod
    def get_claim(claim_id):
        claim = ClaimRepository.get_by_id(claim_id)
        if claim and ClaimService._repair_spouse_labels([claim]):
            # _repair_spouse_labels commits only when it changed a label.
            pass
        return claim

    @staticmethod
    def allowed_categories_for_user(user):
        if not user or not user.is_authenticated:
            return []
        if AuthorizationService.is_employee(user):
            # Employees can submit their own or their registered spouse's
            # medical expenses in every supported category.
            return [ClaimService.NORMAL, ClaimService.OPTICS, ClaimService.PHARMACY]
        if AuthorizationService.is_medical_officer(user) or AuthorizationService.is_hr(user):
            # HR and Medical Officer may submit all supported claim types.
            # Normal price matching is attempted when an active approved
            # price list exists; missing price lists never block submission.
            return [
                ClaimService.NORMAL,
                ClaimService.OPTICS,
                ClaimService.PHARMACY,
            ]
        return []

    @staticmethod
    def validate_category(category):
        category = str(category or "").strip().upper()
        if category not in ClaimService.ALLOWED_CATEGORIES:
            return False, "Invalid claim category."
        return True, category

    @staticmethod
    def _resolve_beneficiary(form_data, current_user):
        """Return beneficiary metadata and enforce the spouse rule server-side."""
        beneficiary_type = (
            form_data.get("beneficiary_type", ClaimService.BENEFICIARY_EMPLOYEE)
            .strip().upper()
        )

        if not AuthorizationService.is_employee(current_user):
            return (
                ClaimService.BENEFICIARY_EMPLOYEE,
                form_data.get("patient_name", "").strip(),
                form_data.get("patient_name", "").strip(),
                ClaimService.EMPLOYEE_COVERAGE,
                None,
            )

        employee_name = (
            getattr(current_user, "full_name", None)
            or getattr(current_user, "email", None)
            or "Employee"
        ).strip()
        spouse_records = SpouseDirectoryService.find_for_employee(
            getattr(getattr(current_user, "employee", None), "employee_number", None)
        )

        if beneficiary_type == ClaimService.BENEFICIARY_SPOUSE:
            if not spouse_records:
                return None, None, None, None, "No spouse record was found in the authoritative spouse directory."
            if len(spouse_records) > 1:
                return None, None, None, None, "Multiple spouse records were found for this employee. HR must resolve the spouse directory before a spouse claim can be submitted."
            spouse_name = spouse_records[0].spouse_name
            return (
                ClaimService.BENEFICIARY_SPOUSE,
                spouse_name,
                employee_name,
                ClaimService.SPOUSE_COVERAGE,
                None,
            )

        if beneficiary_type != ClaimService.BENEFICIARY_EMPLOYEE:
            return None, None, None, None, "Invalid beneficiary selection."

        return (
            ClaimService.BENEFICIARY_EMPLOYEE,
            employee_name,
            employee_name,
            ClaimService.EMPLOYEE_COVERAGE,
            None,
        )

    @staticmethod
    def _institution_suggestions(raw, limit=8):
        """Rank active institutions for the glassmorph human-review picker."""
        from rapidfuzz.fuzz import WRatio, token_set_ratio
        target = normalize_directory_text(raw)
        institutions = ClaimService._active_institutions()
        if not target:
            return [{"id": i.id, "name": i.name, "institution_type": i.institution_type, "score": 0.0} for i in institutions[:limit]]
        ranked = []
        for i in institutions:
            name = normalize_directory_text(i.name)
            score = 0.65 * WRatio(target, name) + 0.35 * token_set_ratio(target, name)
            if target == name:
                score = 100.0
            ranked.append((score, i))
        ranked.sort(key=lambda x: x[0], reverse=True)
        return [{"id": i.id, "name": i.name, "institution_type": i.institution_type, "score": round(score, 1)} for score, i in ranked[:limit]]

    @staticmethod
    def search_institutions(query, limit=12):
        return ClaimService._institution_suggestions(query, limit=limit)

    @staticmethod
    def _resolve_institution(institution_data, category=None):
        """Resolve the AI-extracted provider to exactly one institution master record."""
        raw = institution_data.get("name") if isinstance(institution_data, dict) else institution_data
        target = normalize_directory_text(raw)
        if not target:
            return None, "The receipt did not contain a readable healthcare institution/provider name."
        institutions = ClaimService._active_institutions()
        if str(category or "").upper() == ClaimService.PHARMACY:
            institutions = [i for i in institutions if normalize_directory_text(i.institution_type) == normalize_directory_text("Pharmacy")]
        elif str(category or "").upper() == ClaimService.NORMAL:
            # Normal medical claims must not accidentally resolve to a Pharmacy
            # or an Optic Eye Center. Legacy Hospital/Laboratory/etc. records
            # remain valid Normal providers.
            excluded = {normalize_directory_text("Pharmacy"), normalize_directory_text("Optic Eye Center")}
            institutions = [i for i in institutions if normalize_directory_text(i.institution_type) not in excluded]
        exact = [i for i in institutions if normalize_directory_text(i.name) == target]
        if len(exact) == 1:
            return exact[0], None
        partial = [i for i in institutions if target in normalize_directory_text(i.name) or normalize_directory_text(i.name) in target]
        if len(partial) == 1:
            return partial[0], None

        # Auto scoring removes the institution confirmation window: rank every
        # eligible institution and take the highest-scoring master record.
        if ClaimAutomationService.automatic_scoring_enabled() and institutions:
            from rapidfuzz.fuzz import WRatio, token_set_ratio
            ranked = []
            for institution in institutions:
                candidate = normalize_directory_text(institution.name)
                score = 0.65 * WRatio(target, candidate) + 0.35 * token_set_ratio(target, candidate)
                ranked.append((score, institution))
            ranked.sort(key=lambda pair: pair[0], reverse=True)
            return ranked[0][1], None

        return None, f"Healthcare institution '{raw}' could not be uniquely matched to the institution master data."

    @staticmethod
    def _current_employee(current_user):
        """Resolve the authenticated Employee account to the authoritative directory record."""
        from app.models.employee import Employee
        if not current_user:
            return None
        explicit = getattr(current_user, "employee_id", None)
        if explicit:
            try:
                obj = Employee.query.get(int(explicit))
                if obj:
                    return obj
            except (TypeError, ValueError):
                pass
        email = normalize_directory_text(getattr(current_user, "email", None))
        if email:
            rows = [e for e in Employee.query.all() if normalize_directory_text(e.email) == email or normalize_directory_text(e.user_principal_name) == email]
            if len(rows) == 1:
                return rows[0]
        username = normalize_directory_text(getattr(current_user, "username", None))
        if username:
            rows = [e for e in Employee.query.all() if normalize_directory_text(e.username) == username]
            if len(rows) == 1:
                return rows[0]
        full_name = normalize_directory_text(getattr(current_user, "full_name", None))
        if full_name:
            rows = [e for e in Employee.query.all() if normalize_directory_text(e.full_name) == full_name]
            if len(rows) == 1:
                return rows[0]
        return None

    @staticmethod
    def _optics_lifetime_counts(employee_id):
        """Return lifetime optics usage for an employee owner. Rejected/deleted claims do not count."""
        from app.models.claim import MedicalClaim
        rows = (MedicalClaim.query
                .filter(MedicalClaim.employee_id == employee_id, MedicalClaim.category == ClaimService.OPTICS)
                .filter(MedicalClaim.status.in_(["PENDING_REVIEW", "APPROVED"]))
                .all())
        sight_frame = sum(1 for c in rows if str(getattr(c, "optics_lens_type", "")).upper() == "SIGHT")
        photosolar = sum(1 for c in rows if str(getattr(c, "optics_lens_type", "")).upper() == "PHOTOSOLAR")
        return sight_frame, photosolar

    @staticmethod
    def _calculate_optics(lens_type, frame_price, lens_price, employee_id, coverage_percentage):
        """Apply the lifetime optics policy exactly once the beneficiary owner is known."""
        lens_type = str(lens_type or "").strip().upper()
        if lens_type not in {"SIGHT", "PHOTOSOLAR"}:
            return None, "Please select a lens type: Sight or Photosolar."
        try:
            frame = Decimal(str(frame_price or "0")).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            lens = Decimal(str(lens_price or "0")).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        except Exception:
            return None, "Frame price and lens price must be valid numbers."
        if frame < 0 or lens < 0:
            return None, "Frame price and lens price cannot be negative."
        sight_frame_count, photosolar_count = ClaimService._optics_lifetime_counts(employee_id)
        if lens_type == "SIGHT" and sight_frame_count >= 2:
            return None, "This employee has already used the lifetime Sight frame reimbursement twice. Lenses are unlimited, but the frame benefit is limited to two lifetime uses."
        if lens_type == "PHOTOSOLAR" and photosolar_count >= 1:
            return None, "This employee has already used the lifetime Photosolar reimbursement. Photosolar is limited to one lifetime use per employee."
        if lens_type == "SIGHT":
            frame_eligible = min(frame, Decimal("3000.00")) * Decimal("0.85")
            lens_eligible = min(lens, Decimal("2000.00"))
        else:
            combined = frame + lens
            total_eligible = min(combined, Decimal("5000.00")) * Decimal("0.50")
            frame_eligible = total_eligible
            lens_eligible = Decimal("0.00")
        # The institution is reimbursed at 100% of the eligible benefit.
        # Spouse 90% coverage is tracked separately as a 10% employee share
        # in reporting; it must not reduce the institution-facing claim amount.
        frame_reimb = frame_eligible.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        lens_reimb = lens_eligible.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        total = (frame_reimb + lens_reimb).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        return {
            "lens_type": lens_type, "frame_price": frame, "lens_price": lens,
            "frame_reimbursable": frame_reimb, "lens_reimbursable": lens_reimb,
            "total": total, "sight_frame_count_before": sight_frame_count,
            "photosolar_count_before": photosolar_count,
        }, None

    @staticmethod
    def _build_resolution_match_preview(category, institution, ai_document):
        """Build all useful price-list match evidence for the confirmation page.

        This is deliberately read-only. It never changes the claim and gives the
        user/HR the same matching evidence that will be used at finalization.
        """
        document = (ai_document or {}).get("document") or {}
        items = []
        for raw in (ai_document or {}).get("items", []) or []:
            if not isinstance(raw, dict):
                continue
            service_name = str(raw.get("service_name") or "").strip()
            if not service_name:
                continue
            unit_price = raw.get("unit_price")
            if unit_price in (None, "") and raw.get("receipt_price") not in (None, ""):
                try:
                    quantity = Decimal(str(raw.get("quantity") or "1"))
                    if quantity > 0:
                        unit_price = Decimal(str(raw["receipt_price"])) / quantity
                except Exception:
                    unit_price = None

            result = None
            if category == ClaimService.NORMAL and institution:
                result = ClaimService._match_normal_item(
                    institution.id,
                    service_name,
                    unit_price,
                    service_code=raw.get("service_code"),
                    raw_text=raw.get("raw_text"),
                    include_candidates=True,
                )
            matched = result.get("matched") if isinstance(result, dict) else None
            items.append({
                "service_name": service_name,
                "service_code": raw.get("service_code"),
                "receipt_price": raw.get("receipt_price"),
                "unit_price": unit_price,
                "quantity": raw.get("quantity"),
                "status": result.get("status") if result else ("NOT_APPLICABLE" if category != ClaimService.NORMAL else "PRICE_LIST_UNAVAILABLE"),
                "score": result.get("score") if result else 0,
                "approved_price": result.get("approved_price") if result else None,
                "matched_service": getattr(matched, "service_name", None) if matched else None,
                "matched_code": getattr(matched, "service_code", None) if matched else None,
                "candidate_matches": result.get("candidates", []) if isinstance(result, dict) else [],
            })

        receipt = document.get("receipt") or {}
        totals = document.get("totals") or {}
        return {
            "employee_name": ((document.get("employee") or {}).get("name") or (document.get("patient") or {}).get("name")),
            "institution_name": ((document.get("institution") or {}).get("name")),
            "receipt_date": receipt.get("receipt_date"),
            "receipt_number": receipt.get("receipt_number") or receipt.get("invoice_number") or receipt.get("fs_number") or receipt.get("reference_number"),
            "total": totals.get("total"),
            "items": items,
        }

    @staticmethod
    def _save_pending_resolution(category, current_user, extracted_receipts, unresolved):
        """Persist extracted receipt state so the browser can resolve it without re-uploading files."""
        base = Path(current_app.config.get("UPLOAD_FOLDER", "uploads")) / "pending_claim_resolutions"
        base.mkdir(parents=True, exist_ok=True)
        token = uuid4().hex
        payload = {
            "created": time.time(), "user_id": current_user.id if current_user else None,
            "category": category, "unresolved": unresolved,
            "form_options": getattr(current_user, "_claim_form_options", {}) or {},
            "receipts": []
        }
        for file_path, original_name, ai_document, employee, institution in extracted_receipts:
            payload["receipts"].append({
                "file_path": file_path, "original_name": original_name,
                "ai_document": ai_document,
                "employee_id": employee.id if employee else None,
                "institution_id": institution.id if institution else None,
            })
        path = base / f"{token}.json"
        path.write_text(json.dumps(payload, ensure_ascii=False, default=str), encoding="utf-8")
        return token, payload

    @staticmethod
    def load_pending_resolution(token, current_user):
        path = Path(current_app.config.get("UPLOAD_FOLDER", "uploads")) / "pending_claim_resolutions" / f"{secure_filename(token)}.json"
        if not path.is_file():
            return None
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return None
        if payload.get("user_id") != getattr(current_user, "id", None) or time.time() - float(payload.get("created", 0)) > 3600:
            return None
        payload["_path"] = str(path)
        return payload

    @staticmethod
    def finalize_pending_resolution(token, selections, current_user):
        ClaimService._debug_log("RESOLVE_START token=%s user_id=%s selections=%r", token, getattr(current_user, "id", None), selections)
        payload = ClaimService.load_pending_resolution(token, current_user)
        if not payload:
            ClaimService._debug_log("RESOLVE_MISSING_OR_EXPIRED token=%s user_id=%s", token, getattr(current_user, "id", None), level="WARNING")
            return False, "This claim-resolution session has expired. Please upload the receipts again.", None
        category = payload["category"]
        form_options = dict(payload.get("form_options") or {})
        batch_issues = list(form_options.pop("_batch_issues", []) or [])
        form_options.update(selections.get("__form__") or {})
        receipts = []
        employee_ids = set()
        try:
            ClaimService._debug_log("RESOLVE_PAYLOAD category=%s receipt_count=%d", category, len(payload.get("receipts", [])))
            for idx, rec in enumerate(payload["receipts"]):
                sel = selections.get(str(idx), {})
                ClaimService._debug_log("RESOLVE_RECEIPT idx=%s name=%s selection=%r stored_employee=%s stored_institution=%s", idx, rec.get("original_name"), sel, rec.get("employee_id"), rec.get("institution_id"))
                employee = None
                institution = None
                if rec.get("employee_id"):
                    from app.models.employee import Employee
                    employee = Employee.query.get(rec["employee_id"])
                if rec.get("institution_id"):
                    institution = Institution.query.get(rec["institution_id"])
                if not employee:
                    from app.models.employee import Employee
                    emp_id = str(sel.get("employee_id") or "").strip()
                    emp_num = str(sel.get("employee_number") or "").strip()
                    name = str(sel.get("employee_name") or "").strip()
                    candidates = []
                    from app.services.employee_directory_service import exact_id
                    if emp_id:
                        # Resolve the radio's database primary key first. The UI's
                        # employee_id_<index> radios submit item.id (DB PK), not the
                        # employee's external employee_id string. Fall back to the
                        # external identifier for older clients/integrations.
                        if emp_id.isdigit():
                            selected_employee = Employee.query.get(int(emp_id))
                            if selected_employee is not None:
                                candidates = [selected_employee]
                        if not candidates:
                            candidates = [e for e in Employee.query.all() if exact_id(e.employee_id) == exact_id(emp_id)]
                    if not candidates and emp_num:
                        candidates = [e for e in Employee.query.all() if exact_id(e.employee_number) == exact_id(emp_num)]
                    if not candidates and name:
                        candidates = Employee.query.filter(Employee.full_name.ilike(f"%{name}%")).all()
                    ClaimService._debug_log("RESOLVE_EMPLOYEE_CANDIDATES idx=%s employee_id=%s employee_number=%s name=%s count=%d", idx, emp_id, emp_num, name, len(candidates))
                    if len(candidates) != 1:
                        ClaimService._debug_log("RESOLVE_FAILED_EMPLOYEE idx=%s name=%s", idx, rec.get("original_name"), level="WARNING")
                        return False, f"Please select exactly one employee for receipt '{rec['original_name']}'.", None
                    employee = candidates[0]
                if category != ClaimService.OPTICS and not institution:
                    institution_id = str(sel.get("institution_id") or "").strip()
                    institution = Institution.query.get(int(institution_id)) if institution_id.isdigit() else None
                    if not institution:
                        ClaimService._debug_log("RESOLVE_FAILED_INSTITUTION idx=%s name=%s selected=%s", idx, rec.get("original_name"), sel.get("institution_id"), level="WARNING")
                        return False, f"Please select an institution for receipt '{rec['original_name']}'.", None
                # A missing approved price list must not discard the whole claim.
                # The claim can still be submitted and HR can resolve the item later.
                ClaimService._debug_log("RESOLVE_MATCHED idx=%s employee_db_id=%s employee_id=%s employee_number=%s institution_db_id=%s institution=%s", idx, employee.id, employee.employee_id, employee.employee_number, getattr(institution, "id", None), getattr(institution, "name", None))
                receipts.append((rec["file_path"], rec["original_name"], rec["ai_document"], employee, institution))
                employee_ids.add(employee.id)
            # Do not reject a receipt solely because its raw-file SHA-256 matches
            # a previously stored value. Deployments have reported false duplicate
            # collisions; receipt identity checks below use the visual fingerprint
            # together with receipt-identifying context instead. Keep every resolved
            # receipt in this batch so unrelated receipts are never discarded here.

            ClaimService._debug_log("RESOLVE_ALL_MATCHED category=%s receipts=%d employees=%d -> CREATE", category, len(receipts), len(employee_ids))
            result = ClaimService._create_claim_from_extracted(category, receipts, current_user, form_options=form_options)
            ClaimService._debug_log("RESOLVE_CREATE_RESULT=%r", result)
            try: os.remove(payload["_path"])
            except OSError: pass
            return ClaimService._append_batch_issues(result, batch_issues)
        except IntegrityError as exc:
            from app.extensions import db
            db.session.rollback()
            error_text = str(getattr(exc, "orig", None) or exc)
            ClaimService._debug_log(
                "RESOLVE_INTEGRITY_ERROR type=%s error=%s -> ROLLBACK",
                type(exc).__name__, error_text, level="WARNING"
            )
            if "file_sha256" in error_text:
                # Handles a narrow race where another transaction inserts the same
                # hash after the preflight check. Do not expose a SQL traceback to
                # the user; preserve the pending resolution and uploaded files.
                return False, (
                    "A duplicate receipt was submitted at the same time by another request. "
                    "No duplicate receipt was saved. Your uploaded files were retained; "
                    "please remove the duplicate and retry."
                ), None
            raise
        except Exception as exc:
            from app.extensions import db
            ClaimService._debug_log("RESOLVE_EXCEPTION type=%s -> ROLLBACK", type(exc).__name__, level="ERROR")
            db.session.rollback()
            raise

    @staticmethod
    def _create_claim_from_extracted(category, extracted_receipts, current_user, form_options=None):
        """Create one claim per matched employee, merging that employee's receipts.

        A multi-file submission is intentionally split by employee: receipts for
        different employees become different claim/request records, while all
        receipts belonging to the same employee are merged into one claim.
        Employee DB id is the authoritative grouping key, so spelling variants
        in receipt names cannot accidentally create duplicate requests after the
        employee has been resolved.
        """
        from collections import OrderedDict
        groups = OrderedDict()
        for record in extracted_receipts:
            employee = record[3]
            key = getattr(employee, "id", None)
            if key is None:
                raise ValueError("A resolved receipt is missing its employee record.")
            groups.setdefault(key, []).append(record)

        ClaimService._debug_log(
            "CREATE_GROUPING category=%s receipts=%d employee_groups=%d groups=%s",
            category, len(extracted_receipts), len(groups),
            {str(k): len(v) for k, v in groups.items()},
        )

        created_ids = []
        created_messages = []
        for group_no, (employee_id, group_receipts) in enumerate(groups.items(), 1):
            employee = group_receipts[0][3]
            ClaimService._debug_log(
                "CREATE_GROUP_START group=%d/%d employee_db_id=%s employee_id=%s employee_name=%s receipts=%d",
                group_no, len(groups), employee_id, getattr(employee, "employee_id", None),
                getattr(employee, "full_name", None), len(group_receipts),
            )
            group_options = dict(form_options or {})
            # One consolidated notification is sent after every claim in this
            # upload batch has been created successfully.
            group_options["_suppress_claim_notification"] = True
            success, message, claim_id = ClaimService._create_single_claim_from_extracted(
                category, group_receipts, current_user, form_options=group_options
            )
            if not success or not claim_id:
                ClaimService._debug_log(
                    "CREATE_GROUP_FAILED group=%d employee_db_id=%s message=%r",
                    group_no, employee_id, message, level="ERROR"
                )
                # If earlier employee groups committed successfully, send one
                # consolidated email covering those saved claims rather than
                # leaving a partially successful upload silent.
                if created_ids:
                    try:
                        partial_claims = [ClaimRepository.get_by_id(cid) for cid in created_ids]
                        send_claim_batch_notification([c for c in partial_claims if c is not None], current_user)
                    except Exception as exc:
                        ClaimService._debug_log("PARTIAL_BATCH_NOTIFICATION_FAILED claim_ids=%s error=%r", created_ids, exc, level="WARNING")
                return False, message, created_ids if created_ids else None
            created_ids.append(claim_id)
            created_messages.append(message)
            ClaimService._debug_log(
                "CREATE_GROUP_OK group=%d employee_db_id=%s claim_id=%s",
                group_no, employee_id, claim_id
            )

        label = {ClaimService.NORMAL: "Normal", ClaimService.OPTICS: "Optics", ClaimService.PHARMACY: "Pharmacy"}[category]
        try:
            batch_claims = [ClaimRepository.get_by_id(cid) for cid in created_ids]
            batch_claims = [claim for claim in batch_claims if claim is not None]
            if batch_claims:
                send_claim_batch_notification(batch_claims, current_user)
        except Exception as exc:
            ClaimService._debug_log("BATCH_NOTIFICATION_FAILED claim_ids=%s error=%r", created_ids, exc, level="WARNING")
        if len(created_ids) == 1:
            return True, created_messages[0], created_ids[0]

        message = (
            f"{label} submission created {len(created_ids)} separate claims for "
            f"{len(created_ids)} employees. Receipts belonging to the same employee "
            f"were merged into one claim each. Claim IDs: {', '.join(map(str, created_ids))}."
        )
        ClaimService._debug_log(
            "CREATE_GROUPING_COMPLETE category=%s claims=%s", category, created_ids
        )
        return True, message, created_ids

    @staticmethod
    def _create_single_claim_from_extracted(category, extracted_receipts, current_user, form_options=None):
        """Create exactly one claim from receipts already resolved to one employee owner."""
        from app.extensions import db
        form_options = form_options or {}
        ClaimService._debug_log("CREATE_START category=%s user_id=%s receipts=%d", category, getattr(current_user, "id", None), len(extracted_receipts))
        first_file_path, first_name, first_doc, first_employee, first_institution = extracted_receipts[0]
        beneficiary_type = str(form_options.get("beneficiary_type") or ClaimService.BENEFICIARY_EMPLOYEE).upper()
        beneficiary_name = str(form_options.get("beneficiary_name") or "").strip()
        coverage = ClaimService.SPOUSE_COVERAGE if beneficiary_type == ClaimService.BENEFICIARY_SPOUSE else ClaimService.EMPLOYEE_COVERAGE
        patient_name = beneficiary_name or ((first_doc.get("document") or {}).get("patient") or {}).get("name") or first_employee.full_name
        if category == ClaimService.OPTICS:
            optics, optics_error = ClaimService._calculate_optics(
                form_options.get("optics_lens_type"), form_options.get("optics_frame_price"),
                form_options.get("optics_lens_price"), first_employee.id, coverage
            )
            if optics_error:
                return False, optics_error, None
            optics_lens_type = optics["lens_type"]
            optics_frame_price = optics["frame_price"]
            optics_lens_price = optics["lens_price"]
            optics_frame_reimb = optics["frame_reimbursable"]
            optics_lens_reimb = optics["lens_reimbursable"]
            optics_total = optics["total"]
            institution_id = None
        else:
            optics = None
            optics_lens_type = optics_frame_price = optics_lens_price = optics_frame_reimb = optics_lens_reimb = optics_total = None
            institution_id = first_institution.id if first_institution else None
            if institution_id is None:
                return False, "A matched institution is required for Normal and Pharmacy claims.", None
        ClaimService._debug_log("CREATE_HEADER employee_db_id=%s employee_id=%s employee_number=%s institution_db_id=%s institution=%s beneficiary=%s optics=%s", first_employee.id, first_employee.employee_id, first_employee.employee_number, getattr(first_institution, "id", None), getattr(first_institution, "name", None), beneficiary_type, optics_lens_type)
        claim = ClaimRepository.create_claim(
            institution_id=institution_id, patient_name=patient_name,
            receipt_file_path=first_file_path, employee_id=first_employee.id,
            submitted_by_id=current_user.id if current_user is not None else None,
            category=category, beneficiary_type=beneficiary_type,
            beneficiary_name=patient_name, employee_owner_name=first_employee.full_name,
            coverage_percentage=coverage,
            optics_lens_type=optics_lens_type, optics_frame_price=optics_frame_price,
            optics_lens_price=optics_lens_price, optics_frame_reimbursable=optics_frame_reimb,
            optics_lens_reimbursable=optics_lens_reimb, optics_reimbursable_total=optics_total,
        )
        ClaimService._debug_log("CREATE_HEADER_RESULT claim_id=%s status=%s", getattr(claim, "id", None), getattr(claim, "status", None))
        inserted = 0; employee_ids = set()
        for file_path, original_name, ai_document, employee, institution in extracted_receipts:
            document_data = ai_document.get("document") or {}
            receipt_meta = document_data.get("receipt") or {}
            raw_receipt_date = receipt_meta.get("receipt_date")
            parsed_receipt_date = None
            if raw_receipt_date:
                try:
                    raw = str(raw_receipt_date).strip().replace("Z", "+00:00")
                    parsed_receipt_date = datetime.fromisoformat(raw)
                except Exception:
                    try:
                        for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%m/%d/%Y", "%d.%m.%Y"):
                            try:
                                parsed_receipt_date = datetime.strptime(str(raw_receipt_date).strip(), fmt)
                                break
                            except ValueError:
                                pass
                    except Exception:
                        parsed_receipt_date = None
            # Recompute and persist the fraud fingerprints at the exact point
            # the receipt becomes a database record. This is intentionally
            # independent of the OCR/AI result so exact duplicate files can
            # never be accepted twice.
            fraud = DuplicateDetector.create_fingerprint_bundle(file_path, ai_document)
            receipt = ClaimRepository.create_receipt(
                claim_id=claim.id,
                file_path=file_path,
                original_filename=original_name,
                receipt_date=parsed_receipt_date,
                uploaded_at=datetime.now(timezone.utc),
                # Do not write raw SHA-256 into the globally unique legacy column.
                # It caused legitimate uploads to fail with UNIQUE constraint errors.
                file_sha256=None,
                image_phash=fraud[1],
                receipt_metadata_fingerprint=fraud[2],
                receipt_metadata_key=DuplicateDetector._metadata_identifier_key(ai_document),
            )
            receipt.ai_extraction_json = json.dumps({"engine":"Gemma multimodal AI","document":document_data,"items":ai_document.get("items",[]),"matched_employee":{"employee_id":employee.employee_id,"employee_number":employee.employee_number,"full_name":employee.full_name,"department":employee.department,"manager":employee.manager,"office":employee.office},"matched_institution":getattr(institution,"name",None),"beneficiary_type":beneficiary_type,"beneficiary_name":patient_name}, ensure_ascii=False, default=str)
            employee_ids.add(employee.id)
            if category == ClaimService.OPTICS:
                # Optics are governed by the manual frame/lens policy. Create
                # two explicit expense records so every cost remains associated
                # with the employee owner. The first receipt carries the values.
                if inserted == 0:
                    ClaimRepository.create_item(claim_id=claim.id, service_name="Frame", item_category="OPTICS_FRAME", unit_price=optics_frame_price, receipt_id=receipt.id, employee_id=employee.id, institution_id=None, service_description=f"{optics_lens_type.title()} frame", receipt_price=optics_frame_price, approved_price=optics_frame_reimb, difference=None, validation_status="OPTICS_POLICY", reimbursable_amount=optics_frame_reimb)
                    ClaimRepository.create_item(claim_id=claim.id, service_name="Lens", item_category="OPTICS_LENS", unit_price=optics_lens_price, receipt_id=receipt.id, employee_id=employee.id, institution_id=None, service_description=f"{optics_lens_type.title()} lens", receipt_price=optics_lens_price, approved_price=optics_lens_reimb, difference=None, validation_status="OPTICS_POLICY", reimbursable_amount=optics_lens_reimb)
                    inserted += 2
                continue
            for item in ai_document.get("items", []):
                service_name=str(item.get("service_name") or "").strip(); receipt_price=item.get("receipt_price"); unit_price=item.get("unit_price")
                if not service_name or receipt_price is None: continue
                receipt_price=Decimal(str(receipt_price)).quantize(Decimal("0.01"),rounding=ROUND_HALF_UP)
                unit_price=Decimal(str(unit_price)).quantize(Decimal("0.01"),rounding=ROUND_HALF_UP) if unit_price is not None else None
                if unit_price is None and item.get("quantity") not in (None,"",0,"0"):
                    try:
                        q=Decimal(str(item.get("quantity")))
                        if q>0: unit_price=(receipt_price/q).quantize(Decimal("0.01"),rounding=ROUND_HALF_UP)
                    except Exception: unit_price=None
                approved_price=difference=None; status="NOT_APPLICABLE"
                match_result = None
                excluded_commodity = None
                if category == ClaimService.PHARMACY:
                    is_excluded_commodity, excluded_commodity = is_excluded(
                        service_name, item.get("raw_text") or item.get("description")
                    )
                    if is_excluded_commodity:
                        status = "EXCLUDED_100"
                        ClaimService._debug_log(
                            "PHARMACY_EXCLUDED claim_id=%s service=%s matched_list_item=%s",
                            claim.id, service_name, excluded_commodity
                        )
                if category==ClaimService.NORMAL:
                    active_batch = ActivePriceRepository.get_active_batch(institution.id) if institution else None
                    if not active_batch:
                        status = "PRICE_LIST_UNAVAILABLE"
                        ClaimService._debug_log("CREATE_PRICE_LIST_MISSING claim_id=%s institution_id=%s institution=%s service=%s unit_price=%s", claim.id, getattr(institution,"id",None), getattr(institution,"name",None), service_name, unit_price, level="WARNING")
                    if active_batch:
                        match_result = ClaimService._match_normal_item(
                            institution.id,
                            service_name,
                            unit_price,
                            service_code=item.get("service_code"),
                            raw_text=item.get("raw_text"),
                            receipt_image_path=file_path,
                        )
                        approved_price = match_result["approved_price"]
                        difference = match_result["difference"]
                        status = match_result["status"]
                # For Normal claims, reimbursement is based on the approved
                # price-list unit price, not an OCR/receipt price variation.
                # Preserve the receipt line amount separately as evidence.
                reimbursable_base = receipt_price
                if category == ClaimService.NORMAL and approved_price is not None:
                    quantity = Decimal("1")
                    if unit_price is not None and unit_price > 0:
                        try:
                            inferred_qty = (receipt_price / unit_price).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
                            if inferred_qty >= 1:
                                quantity = inferred_qty
                        except Exception:
                            quantity = Decimal("1")
                    reimbursable_base = approved_price * quantity
                # Institution-facing reimbursement is always 100% of the
                # otherwise eligible amount. Spouse 90% coverage is reported
                # separately as a 10% employee deduction, not subtracted here.
                reimbursable=reimbursable_base.quantize(Decimal("0.01"),rounding=ROUND_HALF_UP)
                # Never reimburse more than the amount actually printed on the
                # receipt. The approved price-list rate is authoritative for
                # the matched service, but it is also capped by the actual
                # receipt expense. This prevents a
                # 540 ETB receipt for a 900 ETB price-list service from becoming
                # a 900 ETB reimbursement.
                if category == ClaimService.NORMAL:
                    receipt_cap = receipt_price.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                    reimbursable = min(reimbursable, receipt_cap)
                if category == ClaimService.PHARMACY and excluded_commodity:
                    # The institution reimbursement remains 100% of the receipt line.
                    # The Bank exclusion is recovered separately from the employee's
                    # payroll; it is not an institution-side service-price deduction.
                    reimbursable = receipt_price.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                    difference = None
                # Once a Normal service is matched, store the canonical
                # approved price-list service name in the Service column.
                # Keep the receipt's original wording in service_description
                # for audit/evidence. This prevents a generic OCR label such
                # as "Consultation" from visually hiding that the actual
                # matched service was "REG002 - Sub Consultation 1".
                canonical_service_name = (
                    getattr(match_result.get("matched"), "service_name", None)
                    if category == ClaimService.NORMAL and isinstance(locals().get("match_result"), dict)
                    else None
                ) or service_name
                ClaimRepository.create_item(claim_id=claim.id,service_name=canonical_service_name,item_category=str(item.get("category") or "MEDICAL_SERVICE").strip(),unit_price=unit_price,receipt_id=receipt.id,employee_id=employee.id,institution_id=(institution.id if institution else None),service_description=(item.get("raw_text") or service_name).strip(),receipt_price=receipt_price,approved_price=approved_price,difference=difference,validation_status=status,reimbursable_amount=reimbursable); inserted+=1
        # The receipt's patient/beneficiary and the employee→spouse directory
        # take priority over a default Employee selection when the evidence
        # clearly identifies the registered spouse.
        try:
            SpouseDirectoryService.classify_claim_as_spouse(claim)
        except Exception as exc:
            ClaimService._debug_log("SPOUSE_CLASSIFICATION_SKIPPED claim_id=%s error=%r", claim.id, exc, level="WARNING")
        automation = ClaimAutomationService.get_settings()
        auto_approved = False
        if automation["automatic_approval"] and inserted > 0 and category in {ClaimService.NORMAL, ClaimService.OPTICS, ClaimService.PHARMACY}:
            if category == ClaimService.NORMAL:
                has_deduction = any(
                    getattr(x, "validation_status", "") == "MATCHED" and
                    Decimal(str(getattr(x, "receipt_price", 0) or 0)) - Decimal(str(getattr(x, "reimbursable_amount", 0) or 0)) > Decimal("0.004")
                    for x in claim.items
                )
                # Discounts are informational, not a reason to hold a matched
                # Normal claim for manual review. Keep the deduction visible in
                # red in the UI, but automatically approve fully matched claims.
                auto_approved = all(
                    getattr(x, "validation_status", "") == "MATCHED"
                    for x in claim.items
                )
            elif category == ClaimService.OPTICS:
                auto_approved = bool(optics_total is not None and inserted >= 2)
            elif category == ClaimService.PHARMACY:
                # Auto-approve pharmacy claims when the supplied exclusion list
                # has been applied to at least one item. Non-excluded pharmacy
                # claims keep the existing HR review workflow.
                auto_approved = any(getattr(x, "validation_status", "") == "EXCLUDED_100" for x in claim.items)
            if auto_approved:
                claim.status = "APPROVED"
                ClaimService._debug_log("AUTO_APPROVED claim_id=%s category=%s", claim.id, category)
        ClaimService._debug_log("CREATE_BEFORE_COMMIT claim_id=%s items=%s employees=%s auto_approved=%s", claim.id, inserted, len(employee_ids), auto_approved)
        db.session.flush(); ClaimService._debug_log("CREATE_FLUSH_OK claim_id=%s", claim.id)
        db.session.commit(); ClaimService._debug_log("CREATE_COMMIT_OK claim_id=%s", claim.id)
        verified = ClaimRepository.get_by_id(claim.id); ClaimService._debug_log("CREATE_VERIFY claim_id=%s found=%s", claim.id, bool(verified))
        if not verified: raise RuntimeError(f"Claim {claim.id} committed but could not be re-read immediately after commit")
        label={ClaimService.NORMAL:"Normal",ClaimService.OPTICS:"Optics",ClaimService.PHARMACY:"Pharmacy"}[category]
        message=f"{label} claim {'approved automatically' if auto_approved else 'submitted'} with {len(extracted_receipts)} receipt(s), {len(employee_ids)} matched employee(s), and {inserted} expense item(s)."
        if category==ClaimService.NORMAL:
            missing_price_list_items = sum(1 for _, _, ai_document, _, institution in extracted_receipts for item in (ai_document.get("items", []) or []) if item.get("service_name") and item.get("receipt_price") is not None and not ActivePriceRepository.get_active_batch(institution.id))
            if missing_price_list_items: message += f" {missing_price_list_items} item(s) could not be price-matched because the institution has no active approved price list; HR can review them."
            elif auto_approved: message += " Matched services use the approved price-list price regardless of the receipt's unit-price variation."
            else: message += " Items were checked against the approved price list."
        elif category == ClaimService.OPTICS:
            message += f" {optics_lens_type.title()} policy reimbursement: {optics_total:.2f} ETB."
        if not form_options.get("_suppress_claim_notification"):
            try: send_claim_action_notification(claim,current_user,"APPROVED" if auto_approved else "SUBMITTED")
            except Exception as exc: print("[MAIL][CLAIM-SUBMIT][ERROR]",repr(exc))
        return True,message,claim.id

    # ------------------------------------------------------------------
    # Smart Normal-service price-list matching
    # ------------------------------------------------------------------
    # IMPORTANT: service matching is independent of unit price. A matching
    # price must NEVER cause an unrelated service to be treated as a match.
    # RapidFuzz combines character similarity, token similarity, token order,
    # and OCR-tolerant WRatio. This handles examples such as:
    #   "Widal Weil Fleix (N)" -> "Widal Weil Felix (N)"
    # while still refusing unrelated services.
    SERVICE_MATCH_THRESHOLD = 82.0
    SERVICE_MATCH_AMBIGUITY_GAP = 4.0
    # Price-list rows are immutable within an approved batch. Cache them by
    # batch_id so a claim with many receipt lines does one DB read instead of
    # one SELECT per line.
    _PRICE_ROWS_CACHE = {}
    _INSTITUTION_CACHE = None
    _INSTITUTION_CACHE_AT = 0.0
    _INSTITUTION_CACHE_TTL = 30.0

    @classmethod
    def _active_institutions(cls):
        now = time.monotonic()
        if cls._INSTITUTION_CACHE is None or (now - cls._INSTITUTION_CACHE_AT) > cls._INSTITUTION_CACHE_TTL:
            cls._INSTITUTION_CACHE = Institution.query.filter_by(is_active=True).all()
            cls._INSTITUTION_CACHE_AT = now
        return cls._INSTITUTION_CACHE

    # These are not generic words. They identify a *different service
    # variant*.  A generic "consultation" must never be allowed to consume a
    # "sub consultation", "emergency examination", "ICU visit", etc. merely
    # because the generic word happens to score highly with RapidFuzz.
    #
    # The groups are deliberately mutually exclusive.  For example,
    # "specialist consultation" and "subspecialist consultation" are not the
    # same service.  This is the important guard that was missing from the
    # previous automatic matcher.
    SERVICE_VARIANT_PATTERNS = {
        "sub_consultation": (
            r"\bsub\s*(?:-|/)?\s*(?:consultation|specialist|specialty)\b",
            r"\bsubspecialist\b",
            r"\bsubspecialty\b",
            r"\bsubconsultation\b",
        ),
        "emergency": (
            r"\bemergency\b",
            r"\bemregency\b",
            r"\bemerg\b",
        ),
        "icu": (r"\bicu\b", r"\bintensive\s+care\b"),
        "admitted_patient": (
            r"\badmitted\s+patient\b",
            r"\binpatient\b",
            r"\bin\s*patient\b",
        ),
        "home_visit": (
            r"\bhome\s+(?:physician|doctor|medical)\s+visit\b",
            r"\bhome\s+visit\b",
        ),
        "on_call": (r"\bon\s*[- ]?\s*call\b",),
        "ophthalmic": (r"\bophthalmic\b", r"\bophthalmology\b"),
        "dental": (r"\bdental\b", r"\bdentist\b"),
        "anesthetic": (r"\banesthetic\b", r"\banesthesia\b"),
        "ward": (r"\bward\b",),
    }

    @staticmethod
    def _normalize_service_code(value):
        """Normalize one visible medical service/procedure code."""
        text = "" if value is None else str(value)
        text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii").upper()
        m = re.search(r"\b([A-Z]{1,10})\s*[-/]?\s*(\d{2,})\b", text)
        return f"{m.group(1)}{m.group(2)}" if m else ""

    @classmethod
    def _extract_service_codes(cls, *values):
        """Extract every explicit service code visible in the supplied evidence.

        Receipt extraction can occasionally disagree about ``service_name`` and
        ``raw_text``.  Codes are therefore collected from both sources and used
        as identity evidence before any fuzzy name scoring.
        """
        found = []
        for value in values:
            text = "" if value is None else str(value)
            text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii").upper()
            for match in re.finditer(r"\b([A-Z]{1,10})\s*[-/]?\s*(\d{2,})\b", text):
                code = f"{match.group(1)}{match.group(2)}"
                if code not in found:
                    found.append(code)
        return found

    @classmethod
    def _extract_service_code(cls, *values):
        """Backward-compatible first-code helper."""
        codes = cls._extract_service_codes(*values)
        return codes[0] if codes else ""

    @staticmethod
    def _normalize_service_for_match(value):
        text = "" if value is None else str(value)
        text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
        text = text.casefold().replace("&", " and ")

        # Service/procedure codes are handled separately as identity evidence.
        text = re.sub(r"\b[a-z]{1,10}\s*[-/]?\s*\d{2,}[a-z0-9._/-]*\b", " ", text)
        # Some receipt parsers accidentally leave quantity/unit/line-total
        # numbers attached to the service text.  Remove only a numeric tail;
        # do not remove meaningful numbers occurring inside a service name.
        text = re.sub(r"(?:\s+[-:]?\s*\(?\d[\d,]*(?:\.\d+)?\)?)+\s*$", " ", text)

        # Normalize common institutional wording for the same *specific*
        # service variant.  In particular, "subspecialist" and "sub
        # consultation" describe the same price-list variant in many lists.
        text = re.sub(r"\bsub\s*[-/]?\s*specialist\b", " sub consultation ", text)
        text = re.sub(r"\bsub\s*[-/]?\s*specialty\b", " sub consultation ", text)
        text = re.sub(r"\bsubconsultation\b", " sub consultation ", text)

        text = re.sub(r"[\[\]{}()_/\\|,;:+*=#]+", " ", text)
        text = re.sub(r"[-]+", " ", text)
        text = re.sub(r"[^a-z0-9]+", " ", text)
        return re.sub(r"\s+", " ", text).strip()

    @staticmethod
    def _thyroid_panel_markers(value):
        """Return the exact thyroid tests named in a panel description.

        FT3 and T3, and FT4 and T4, are not interchangeable. This guard
        prevents two panels sharing TSH/FT4 from being treated as equivalent.
        """
        text = "" if value is None else str(value)
        text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii").upper()
        # Avoid matching FT3 as T3 or FT4 as T4 by consuming FT-prefixed
        # markers first, then collecting standalone T3/T4/TSH markers.
        markers = set(re.findall(r"(?<![A-Z0-9])FT[34](?![A-Z0-9])", text))
        text_without_free = re.sub(r"(?<![A-Z0-9])FT[34](?![A-Z0-9])", " ", text)
        markers.update(re.findall(r"(?<![A-Z0-9])T[345](?![A-Z0-9])", text_without_free))
        if re.search(r"(?<![A-Z0-9])TSH(?![A-Z0-9])", text):
            markers.add("TSH")
        return markers

    @classmethod
    def _thyroid_panel_compatible(cls, query, candidate):
        q = cls._thyroid_panel_markers(query)
        c = cls._thyroid_panel_markers(candidate)
        # Only constrain comparisons when both sides contain explicit panel
        # markers; a generic phrase such as "thyroid test" has no marker set.
        return not (q and c and q != c)

    @classmethod
    def _service_variant_tags(cls, value):
        """Return mutually-exclusive service-variant markers.

        These markers prevent generic fuzzy matching from crossing a real
        clinical/billing variant boundary.  Price is never used to create a
        match; it can only help break a tie after the service identity has
        already passed these guards.
        """
        text = "" if value is None else str(value)
        text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii").casefold()
        text = re.sub(r"\s+", " ", text)
        tags = set()
        for tag, patterns in cls.SERVICE_VARIANT_PATTERNS.items():
            if any(re.search(pattern, text) for pattern in patterns):
                tags.add(tag)
        return tags

    @classmethod
    def _service_variant_compatible(cls, query, candidate):
        if not cls._thyroid_panel_compatible(query, candidate):
            return False
        q_tags = cls._service_variant_tags(query)
        c_tags = cls._service_variant_tags(candidate)
        if not q_tags:
            # A generic query may match a generic service, but it must not
            # silently consume a specifically-qualified service when a truly
            # generic candidate exists.  Ranking handles that preference.
            return True
        # Every specific variant present in the receipt must be represented by
        # the candidate.  This is intentionally strict for automatic approval.
        return q_tags.issubset(c_tags)

    @classmethod
    def _service_similarity_score(cls, query, candidate):
        q = cls._normalize_service_for_match(query)
        c = cls._normalize_service_for_match(candidate)
        if not q or not c:
            return 0.0
        if q == c:
            return 100.0

        whole = ratio(q, c)
        weighted = WRatio(q, c)
        token_set = token_set_ratio(q, c)
        token_sort = token_sort_ratio(q, c)
        score = (
            0.30 * whole
            + 0.30 * weighted
            + 0.25 * token_set
            + 0.15 * token_sort
        )

        q_tokens = set(q.split())
        c_tokens = set(c.split())
        if q_tokens and q_tokens.issubset(c_tokens) and token_set >= 98:
            score += 8.0

        # A protected service variant is more important than generic word
        # similarity.  Once the same variant is present on both sides, give
        # that evidence a strong boost.  A missing variant is handled by the
        # compatibility guard above and cannot receive this boost.
        q_tags = cls._service_variant_tags(query)
        c_tags = cls._service_variant_tags(candidate)
        if q_tags and q_tags.issubset(c_tags):
            score += 14.0

        return min(score, 100.0)

    @classmethod
    def _find_service_match(cls, institution_id, service_name, unit_price=None, service_code=None, raw_text=None, include_candidates=False):
        """Match a receipt service to the correct approved price-list service.

        Identity is resolved from the *whole available receipt evidence* in this
        order:
          1. Explicit service/procedure code.
          2. Exact service-name evidence.
          3. Strong bidirectional/token/fuzzy similarity with variant guards.

        The receipt unit price is never used to decide service identity.
        Critically, a generic word such as ``Consultation`` can never override a
        specific coded service such as ``REG002 - Sub Consultation 1``.
        """
        from app.models.price_list import PriceListItem

        batch = ActivePriceRepository.get_active_batch(institution_id)
        if not batch:
            return (None, 0.0, []) if include_candidates else (None, 0.0)

        rows = cls._PRICE_ROWS_CACHE.get(batch.id)

        if rows:
            from sqlalchemy.orm import object_session
            from app.extensions import db
        
            current_session = db.session()
        
            if any(
                object_session(row) is not current_session
                for row in rows
            ):
                rows = None
        
        if rows is None:
            rows = PriceListItem.query.filter_by(
                batch_id=batch.id,
                is_active=True,
            ).all()
        
            cls._PRICE_ROWS_CACHE[batch.id] = rows
        
            # Keep the in-process cache bounded.
            if len(cls._PRICE_ROWS_CACHE) > 64:
                cls._PRICE_ROWS_CACHE.pop(next(iter(cls._PRICE_ROWS_CACHE)))
        if not rows:
            return (None, 0.0, []) if include_candidates else (None, 0.0)
        
        # Keep every useful piece of evidence.  Older persisted claims may have
        # lost the original service_code column, but service_description still
        # contains the receipt's raw line, so it is equally important.
        evidence_values = [service_code, raw_text, service_name]
        evidence_texts = [str(v).strip() for v in evidence_values if v not in (None, "") and str(v).strip()]
        explicit_codes = cls._extract_service_codes(*evidence_values)
        
        row_codes = {
            id(row): cls._normalize_service_code(row.service_name)
            for row in rows
        }
        
        # --------------------------------------------------------------
        # 1. Exact service-code identity.
        # --------------------------------------------------------------
        # Prefer a code supplied explicitly by the AI, then a code embedded in
        # the raw receipt text, then a code embedded in the service label.
        # Among multiple visible codes, only candidates whose code exists in the
        # approved price list are considered.
        coded_candidates = []
        for code_index, code in enumerate(explicit_codes):
            matches = [row for row in rows if row_codes[id(row)] == code]
            for row in matches:
                name_scores = [
                    cls._service_similarity_score(text, row.service_name)
                    for text in evidence_texts
                ]
                best_name_score = max(name_scores) if name_scores else 0.0
                coded_candidates.append((code_index, best_name_score, row))
        
        if coded_candidates:
            # A known code is definitive. If the approved list contains multiple
            # rows with that same code, use the receipt unit price only to resolve
            # that duplicate-code tie; never let price override the code.
            coded_candidates.sort(
                key=lambda x: (x[0] == 0, x[1]),
                reverse=True,
            )
            best_code_index = coded_candidates[0][0]
            same_code = [entry for entry in coded_candidates if entry[0] == best_code_index]
            if len(same_code) > 1 and unit_price not in (None, ""):
                try:
                    receipt_value = Decimal(str(unit_price))
                    same_code.sort(
                        key=lambda entry: abs(
                            Decimal(str(getattr(entry[2], "approved_price", 0))) - receipt_value
                        )
                    )
                except Exception:
                    pass
            # A code read from OCR is not definitive when its service label
            # contradicts the approved row. Receipts often place codes close to
            # adjacent lines, so validate code identity against the description.
            _, score, row = same_code[0]
            name_evidence = [str(service_name or "").strip(), str(raw_text or "").strip()]
            name_evidence = [value for value in name_evidence if value]
            best_description_score = max(
                (cls._service_similarity_score(value, row.service_name) for value in name_evidence),
                default=0.0,
            )
            description_compatible = any(
                cls._service_variant_compatible(value, row.service_name)
                for value in name_evidence
            )
            if best_description_score >= 65.0 and description_compatible:
                candidates = [{"service_name": getattr(r[2], "service_name", None), "approved_price": getattr(r[2], "approved_price", None), "score": max(100.0, r[1])} for r in same_code]
                return (row, max(100.0, score), candidates) if include_candidates else (row, max(100.0, score))
            # Ignore the questionable code and continue matching by service
            # description; never let a stray neighboring code force identity.

        # --------------------------------------------------------------
        # 2. Exact normalized name identity across all evidence.
        # --------------------------------------------------------------
        normalized_names = [cls._normalize_service_for_match(text) for text in evidence_texts]
        raw_text_value = str(raw_text or "").strip()
        # Prefer a complete service phrase visible in the receipt's raw line.
        # A generic extracted label such as "Hemoglobin" must not short-circuit
        # evidence that explicitly names "Hemoglobin & Hematocrit". If the raw
        # line only says the generic name and the price list contains longer
        # variants, leave it for ambiguity scoring rather than guessing.
        raw_norm = cls._normalize_service_for_match(raw_text_value)
        raw_phrase_matches = []
        if raw_norm:
            for row in rows:
                row_norm = cls._normalize_service_for_match(row.service_name)
                if row_norm and len(row_norm.split()) >= 2 and row_norm in raw_norm:
                    raw_phrase_matches.append((len(row_norm), row))
        if raw_phrase_matches:
            longest = max(length for length, _ in raw_phrase_matches)
            exact_from_raw = [row for length, row in raw_phrase_matches if length == longest]
            if len(exact_from_raw) == 1:
                row = exact_from_raw[0]
                candidates = [{"service_name": getattr(row, "service_name", None), "approved_price": getattr(row, "approved_price", None), "score": 100.0}]
                return (row, 100.0, candidates) if include_candidates else (row, 100.0)

        exact_matches = []
        for normalized in normalized_names:
            if not normalized:
                continue
            exact_matches.extend(row for row in rows if cls._normalize_service_for_match(row.service_name) == normalized)
        # Deduplicate while preserving approved-list order.
        exact = list({id(row): row for row in exact_matches}.values())
        if exact:
            exact_norms = {cls._normalize_service_for_match(row.service_name) for row in exact}
            generic_exact = any(
                name and any(name != candidate and set(name.split()).issubset(set(candidate.split()))
                             for candidate in (cls._normalize_service_for_match(r.service_name) for r in rows))
                for name in exact_norms
            )
            if generic_exact and not raw_phrase_matches:
                # Do not silently choose a shorter exact label when the list has
                # more specific services sharing its words. Return ambiguity so
                # HR can confirm the actual receipt service instead of guessing.
                ambiguous = [row for row in rows if any(
                    name and set(name.split()).issubset(set(cls._normalize_service_for_match(row.service_name).split()))
                    for name in exact_norms
                )]
                candidates = [{"service_name": getattr(r, "service_name", None), "approved_price": getattr(r, "approved_price", None), "score": 100.0} for r in ambiguous[:8]]
                return (None, 100.0, candidates) if include_candidates else (None, 100.0)
            else:
                if len(exact) > 1 and unit_price not in (None, ""):
                    try:
                        receipt_value = Decimal(str(unit_price))
                        exact.sort(key=lambda row: abs(Decimal(str(getattr(row, "approved_price", 0))) - receipt_value))
                    except Exception:
                        pass
                candidates = [{"service_name": getattr(r, "service_name", None), "approved_price": getattr(r, "approved_price", None), "score": 100.0} for r in exact]
                return (exact[0], 100.0, candidates) if include_candidates else (exact[0], 100.0)

        # --------------------------------------------------------------
        # 3. Build a robust score from BOTH service_name and raw receipt text.
        # --------------------------------------------------------------
        # We use the strongest evidence rather than blindly concatenating raw
        # text, because raw OCR often contains price/quantity columns.
        scored = []
        primary_text = str(service_name or "").strip()

        for row in rows:
            candidate = row.service_name
            if not cls._service_variant_compatible(primary_text or raw_text_value, candidate):
                # If the extracted label is noisy but raw text contains the
                # right variant, allow the raw evidence to qualify the row.
                if not raw_text_value or not cls._service_variant_compatible(raw_text_value, candidate):
                    continue

            pieces = []
            if primary_text:
                pieces.append(cls._service_similarity_score(primary_text, candidate))
            if raw_text_value:
                pieces.append(cls._service_similarity_score(raw_text_value, candidate))

            if not pieces:
                continue

            # Give the best single evidence most influence, but require the
            # secondary evidence not to be strongly contradictory. This lets an
            # OCR-swapped display label be corrected by the actual receipt line.
            best = max(pieces)
            other = min(pieces) if len(pieces) > 1 else best
            combined = 0.72 * best + 0.28 * other

            q_norm = cls._normalize_service_for_match(primary_text or raw_text_value)
            c_norm = cls._normalize_service_for_match(candidate)
            q_tokens = set(q_norm.split())
            c_tokens = set(c_norm.split())

            # Distinct specific service variants are never interchangeable.
            # Evaluate each evidence source independently: if OCR produced a
            # conflicting label but the receipt text is stronger, the stronger
            # source must be allowed to identify the service. This is especially
            # important for malformed extraction such as a display label saying
            # "Emregency Examination Fee" while the raw receipt line contains
            # "REG001 - Registration Fee". Exact code identity is handled above;
            # this guard applies only when no usable code exists.
            c_tags = cls._service_variant_tags(candidate)
            tagged_sources = []
            for source_text in (primary_text, raw_text_value):
                source_tags = cls._service_variant_tags(source_text)
                if source_tags:
                    source_score = cls._service_similarity_score(source_text, candidate)
                    tagged_sources.append((source_score, source_tags))
            if tagged_sources:
                strongest_variant_score, strongest_variant_tags = max(tagged_sources, key=lambda x: x[0])
                if strongest_variant_score >= 60.0 and not strongest_variant_tags.issubset(c_tags):
                    continue

            # A generic two-word label such as "consultation" must not absorb
            # a more specific service when there is no explicit identity/code.
            if q_tokens and q_tokens.issubset(c_tokens) and q_tokens != c_tokens and len(q_tokens) <= 2:
                continue

            # Reward meaningful bidirectional token overlap and phrase containment.
            overlap = len(q_tokens & c_tokens) / max(1, len(q_tokens | c_tokens))
            if q_tokens and c_tokens and q_tokens <= c_tokens and q_tokens != c_tokens:
                combined -= 8.0
            combined += overlap * 8.0

            service_score = min(combined, 100.0)

            # Receipt price is NEVER allowed to override a clearly better
            # service identity. It is only a deterministic tie-breaker when
            # services are already essentially equally similar. This fixes the
            # "always choose the cheapest duplicate service" failure mode while
            # still using receipt data when two service labels genuinely tie.
            price_distance = None
            if unit_price not in (None, ""):
                try:
                    receipt_value = Decimal(str(unit_price))
                    candidate_value = Decimal(str(getattr(row, "approved_price", None)))
                    if receipt_value >= 0 and candidate_value >= 0:
                        price_distance = abs(candidate_value - receipt_value)
                except Exception:
                    price_distance = None

            scored.append((service_score, price_distance, row))

        if not scored:
            return (None, 0.0, []) if include_candidates else (None, 0.0)

        # Service identity is the primary ranking key. Receipt price may only
        # resolve a genuinely near-equal service tie; it must never pull a
        # clearly better service toward the cheapest price-list row.
        scored.sort(key=lambda pair: pair[0], reverse=True)
        service_best_score = scored[0][0]
        tie_window = 1.5
        top = [entry for entry in scored if service_best_score - entry[0] <= tie_window]

        if len(top) > 1:
            receipt_value = None
            if unit_price not in (None, ""):
                try:
                    receipt_value = Decimal(str(unit_price))
                except Exception:
                    receipt_value = None

            # If the receipt amount is lower than one or more tied candidates,
            # prefer the closest price that does not exceed the receipt. This is
            # the only circumstance in which receipt price influences identity.
            # It prevents the historical "always choose the cheapest row" bug.
            if receipt_value is not None:
                not_above = [
                    entry for entry in top
                    if entry[1] is not None and Decimal(str(getattr(entry[2], "approved_price", 0))) <= receipt_value
                ]
                if not_above:
                    not_above.sort(key=lambda entry: abs(Decimal(str(getattr(entry[2], "approved_price", 0))) - receipt_value))
                    selected_score, _, best_row = not_above[0]
                else:
                    # If every tied price is above the receipt, preserve service
                    # identity and choose the smallest excess only as a safe
                    # reimbursement-oriented tie-break.
                    priced = [entry for entry in top if entry[1] is not None]
                    priced.sort(key=lambda entry: abs(Decimal(str(getattr(entry[2], "approved_price", 0))) - receipt_value))
                    selected_score, _, best_row = priced[0] if priced else top[0]
            else:
                selected_score, _, best_row = top[0]
        else:
            selected_score, _, best_row = scored[0]

        # The reported confidence remains the service-identity score, not the
        # amount-based tie-break.
        best_score = service_best_score
        # Always display candidates in descending identity score order. Price
        # is not a reason to promote a lower-scoring clinical identity.
        candidate_details = [
            {
                "service_name": getattr(entry[2], "service_name", None),
                "approved_price": getattr(entry[2], "approved_price", None),
                "score": entry[0],
            }
            for entry in sorted(scored, key=lambda entry: entry[0], reverse=True)[:8]
        ]

        automation_on = False
        try:
            automation_on = ClaimAutomationService.automatic_scoring_enabled()
        except Exception:
            automation_on = False

        if not automation_on:
            if best_score < cls.SERVICE_MATCH_THRESHOLD:
                return (None, best_score, candidate_details) if include_candidates else (None, best_score)
            if len(scored) > 1:
                second_score = scored[1][0]
                if (best_score - second_score) < cls.SERVICE_MATCH_AMBIGUITY_GAP:
                    return (None, best_score, candidate_details) if include_candidates else (None, best_score)

        # Backward-compatible non-preview contract: return best_row, best_score.
        return (best_row, best_score, candidate_details) if include_candidates else (best_row, best_score)

    @staticmethod
    def auto_finalize_pending_normal_claims():
        """Re-score legacy Normal claims when both automation controls are ON.

        This keeps older pending claims consistent with the current submission
        rules instead of requiring HR to open each claim to trigger revalidation.
        """
        if not (ClaimAutomationService.automatic_scoring_enabled() and ClaimAutomationService.automatic_approval_enabled()):
            return 0
        from app.models.claim import MedicalClaim
        from app.extensions import db
        changed_count = 0
        claims = MedicalClaim.query.filter_by(status="PENDING_REVIEW", category=ClaimService.NORMAL).all()
        for claim in claims:
            try:
                all_matched = bool(claim.items)
                for item in claim.items:
                    institution_id = getattr(item, "institution_id", None) or getattr(claim, "institution_id", None)
                    result = ClaimService._match_normal_item(
                        institution_id,
                        item.service_name,
                        item.unit_price,
                        service_code=None,
                        raw_text=getattr(item, "service_description", None),
                    )
                    if result.get("matched") is not None:
                        item.service_name = result["matched"].service_name
                    item.approved_price = result["approved_price"]
                    item.difference = result["difference"]
                    item.validation_status = result["status"]
                    if result["status"] == "MATCHED" and result["approved_price"] is not None:
                        receipt_price = Decimal(str(item.receipt_price or item.unit_price or 0)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                        unit_price = Decimal(str(item.unit_price or 0))
                        quantity = Decimal("1")
                        if unit_price > 0:
                            try:
                                inferred_qty = (receipt_price / unit_price).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
                                if inferred_qty >= 1:
                                    quantity = inferred_qty
                            except Exception:
                                pass
                        # Reimbursement remains 100% of the eligible amount;
                        # spouse cost-sharing is calculated separately in reports.
                        item.reimbursable_amount = (Decimal(str(result["approved_price"])) * quantity).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                        receipt_cap = receipt_price.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                        item.reimbursable_amount = min(item.reimbursable_amount, receipt_cap)
                    if result["status"] != "MATCHED":
                        all_matched = False
                has_deduction = any(
                    getattr(item, "validation_status", "") == "MATCHED"
                    and Decimal(str(getattr(item, "receipt_price", 0) or 0))
                        - Decimal(str(getattr(item, "reimbursable_amount", 0) or 0)) > Decimal("0.004")
                    for item in (claim.items or [])
                )
                # A deduction alone must not block automatic approval; all
                # services must still be matched to the approved price list.
                if all_matched:
                    claim.status = "APPROVED"
                    changed_count += 1
            except Exception as exc:
                current_app.logger.warning("Automatic legacy Normal claim re-score skipped for claim %s: %s", getattr(claim, "id", None), exc)
        if changed_count:
            db.session.commit()
        return changed_count

    @staticmethod
    def _match_normal_item(institution_id, service_name, unit_price, service_code=None, raw_text=None, include_candidates=False, receipt_image_path=None):
        """Return structured Normal-claim validation.

        Service existence is established first. Once the approved price-list
        service is matched, its price is authoritative even if OCR/receipt
        unit price differs. Automatic scoring can select the best sufficiently
        similar service without a manual score/ambiguity review.
        """
        if not institution_id:
            return {
                "matched": None,
                "score": 0.0,
                "status": "PRICE_LIST_UNAVAILABLE",
                "approved_price": None,
                "difference": None,
                "candidates": [],
            }

        batch = ActivePriceRepository.get_active_batch(institution_id)
        if not batch:
            return {
                "matched": None,
                "score": 0.0,
                "status": "PRICE_LIST_UNAVAILABLE",
                "approved_price": None,
                "difference": None,
                "candidates": [],
            }

        match_result = ClaimService._find_service_match(
            institution_id,
            service_name,
            unit_price=unit_price,
            service_code=service_code,
            raw_text=raw_text,
            include_candidates=(include_candidates or bool(receipt_image_path)),
        )
        if include_candidates or receipt_image_path:
            matched, score, candidates = match_result
        else:
            matched, score = match_result
            candidates = []

        # For live Normal claims, use the receipt image to adjudicate ambiguous
        # candidates. The model is constrained to the approved candidate list;
        # all returned identifiers are validated again below against that list.
        # Existing callers that re-score old claims or preview matches remain
        # compatible because the image path is optional.
        needs_vision_review = bool(
            receipt_image_path and os.path.isfile(str(receipt_image_path))
        )
        vision_attempted = False
        if needs_vision_review:
            try:
                from app.services.ollama_claim_extraction_service import OllamaClaimExtractionService
                from app.models.price_list import PriceListItem

                # Build the visual adjudication shortlist from the entire active
                # approved list. The legacy matcher may return a single early
                # exact/fuzzy candidate; that is not sufficient evidence that
                # competing service variants were considered.
                query_texts = [str(service_name or ""), str(raw_text or "")]
                approved_rows = PriceListItem.query.filter_by(
                    batch_id=batch.id, is_active=True
                ).all()
                ranked = []
                for approved_row in approved_rows:
                    candidate_name = str(approved_row.service_name or "")
                    if not candidate_name:
                        continue
                    compatibility_queries = [q for q in query_texts if q.strip()]
                    if compatibility_queries and not any(
                        ClaimService._service_variant_compatible(q, candidate_name)
                        for q in compatibility_queries
                    ):
                        continue
                    candidate_score = max(
                        (ClaimService._service_similarity_score(q, candidate_name)
                         for q in compatibility_queries),
                        default=0.0,
                    )
                    ranked.append((candidate_score, approved_row))
                ranked.sort(key=lambda pair: pair[0], reverse=True)

                pool = []
                seen_keys = set()
                for existing_candidate in candidates or []:
                    key = (str(existing_candidate.get("service_name") or ""),
                           str(existing_candidate.get("approved_price") or ""))
                    if key[0] and key not in seen_keys:
                        pool.append(existing_candidate)
                        seen_keys.add(key)
                for candidate_score, approved_row in ranked:
                    key = (str(approved_row.service_name), str(approved_row.approved_price))
                    if key in seen_keys:
                        continue
                    pool.append({
                        "service_name": approved_row.service_name,
                        "approved_price": approved_row.approved_price,
                        "score": candidate_score,
                    })
                    seen_keys.add(key)
                    if len(pool) >= 12:
                        break
                candidates = pool[:12]
                vision_attempted = True
                vision_confirmed = False
                vision_choice = OllamaClaimExtractionService.compare_service_candidates(
                    str(receipt_image_path),
                    service_name=str(service_name or ""),
                    raw_text=str(raw_text or ""),
                    service_code=str(service_code or ""),
                    candidates=candidates,
                )
                if vision_choice:
                    chosen_name = str(vision_choice.get("service_name") or "").strip()
                    chosen_price = str(vision_choice.get("approved_price") or "").strip()
                    validated = [candidate for candidate in candidates if
                        str(candidate.get("service_name") or "").strip() == chosen_name and
                        str(candidate.get("approved_price") or "").strip() == chosen_price]
                    if len(validated) == 1:
                        from app.models.price_list import PriceListItem
                        selected = validated[0]
                        # Query by approved service name, then compare prices as
                        # Decimals to avoid DB-driver string/numeric coercion.
                        possible_rows = PriceListItem.query.filter_by(
                            batch_id=batch.id, is_active=True,
                            service_name=selected["service_name"],
                        ).all()
                        selected_price = Decimal(str(selected["approved_price"])).quantize(Decimal("0.01"))
                        matched = next((row for row in possible_rows if
                            Decimal(str(row.approved_price)).quantize(Decimal("0.01")) == selected_price), None)
                        if matched is not None:
                            score = float(vision_choice.get("confidence", 0) or 0)
                            vision_confirmed = True
                if not vision_confirmed:
                    # A receipt image was available but the AI did not confirm
                    # an approved candidate. Keep it unresolved for review
                    # rather than auto-accepting a potentially wrong text match.
                    matched = None
                    score = max(float(score or 0), ClaimService.SERVICE_MATCH_THRESHOLD)
            except Exception as exc:
                matched = None
                score = max(float(score or 0), ClaimService.SERVICE_MATCH_THRESHOLD)
                try:
                    current_app.logger.warning("Normal claim vision matching failed; marking line unresolved: %s", exc)
                except Exception:
                    pass
        if matched is None:
            status = (
                "SERVICE_MATCH_NOT_CONFIRMED"
                if score >= ClaimService.SERVICE_MATCH_THRESHOLD
                else "SERVICE_DOES_NOT_EXIST"
            )
            return {
                "matched": None,
                "score": score,
                "status": status,
                "approved_price": None,
                "difference": None,
                "candidates": candidates,
            }

        approved = Decimal(str(matched.approved_price)).quantize(
            Decimal("0.01"), rounding=ROUND_HALF_UP
        )
        # Once the service itself is matched, the approved price is always
        # the authoritative price-list price. The receipt's unit price is
        # retained as evidence, but it can never turn a valid service into a
        # price-mismatch review item. This is especially important for OCR
        # variants such as 900 on the price list versus 910/920 on the receipt.
        return {
            "matched": matched,
            "score": score,
            "status": "MATCHED",
            "approved_price": approved,
            "difference": Decimal("0.00"),
            "candidates": candidates,
        }

    @staticmethod
    def _find_price_for_item(institution_id, service_name, unit_price):
        """Backward-compatible wrapper returning only a validated match.

        Normal claims now match the service by intelligent similarity first;
        price is validated only after the service has been identified.
        """
        result = ClaimService._match_normal_item(
            institution_id,
            service_name,
            unit_price,
        )
        if result["status"] == "MATCHED":
            return result["matched"]
        return None

    @staticmethod
    def submit_claim(form_data, files=None, upload_folder=None, current_user=None, file=None):
        """Create one claim from one or more uploaded receipt files.

        ``file`` remains accepted for backwards compatibility with older
        callers; new callers should pass ``files``.
        """
        # The submit page intentionally collects only category + receipts.
        # Institution, employee and patient are derived from each receipt and
        # the imported employee/institution master data.
        batch_started_at = time.perf_counter()
        ClaimService._debug_log("SUBMIT_START user_id=%s category_raw=%r files=%d", getattr(current_user, "id", None), form_data.get("claim_category"), len(files) if files else 0)
        category = form_data.get("claim_category", "").strip().upper()

        valid, category_result = ClaimService.validate_category(category)
        if not valid:
            return False, category_result, None

        allowed_categories = ClaimService.allowed_categories_for_user(current_user)
        if category not in allowed_categories:
            return False, "You are not authorized to submit this claim category.", None

        if files is None:
            files = [file] if file is not None else []
        else:
            files = [f for f in files if f and f.filename]

        if not files:
            return False, "At least one receipt file is required.", None

        # Employee accounts choose Employee or their registered Spouse. HR/Medical
        # Officer submissions remain employee-owned and use the AI employee match.
        beneficiary_type = str(form_data.get("beneficiary_type") or ClaimService.BENEFICIARY_EMPLOYEE).strip().upper()
        coverage = ClaimService.SPOUSE_COVERAGE if beneficiary_type == ClaimService.BENEFICIARY_SPOUSE else ClaimService.EMPLOYEE_COVERAGE
        ai_mode = str(form_data.get("ai_mode") or "standard").strip().lower()
        if ai_mode not in {"standard", "lite"}:
            ai_mode = "standard"
        form_options = {
            "ai_mode": ai_mode,
            "beneficiary_type": beneficiary_type,
            "beneficiary_name": "",
            "optics_lens_type": form_data.get("optics_lens_type"),
            "optics_frame_price": form_data.get("optics_frame_price"),
            "optics_lens_price": form_data.get("optics_lens_price"),
        }
        if AuthorizationService.is_employee(current_user):
            owner = ClaimService._current_employee(current_user)
            if not owner:
                return False, "Your Employee account could not be linked to the authoritative employee directory. Please contact HR.", None
            if beneficiary_type == ClaimService.BENEFICIARY_SPOUSE:
                spouse_records = SpouseDirectoryService.find_for_employee(owner)
                if not spouse_records:
                    return False, "No spouse record was found in the authoritative spouse directory.", None
                if len(spouse_records) > 1:
                    return False, "Multiple spouse records were found for this employee. HR must resolve the spouse directory before a spouse claim can be submitted.", None
                form_options["beneficiary_name"] = spouse_records[0].spouse_name
            elif beneficiary_type == ClaimService.BENEFICIARY_EMPLOYEE:
                form_options["beneficiary_name"] = owner.full_name
            else:
                return False, "Invalid beneficiary selection.", None
        elif beneficiary_type != ClaimService.BENEFICIARY_EMPLOYEE:
            return False, "Only Employee accounts may submit spouse claims.", None

        allowed_extensions = {".pdf", ".jpg", ".jpeg", ".png"}
        prepared = []
        for uploaded in files:
            original_name = secure_filename(uploaded.filename or "")
            extension = Path(original_name).suffix.lower()
            if not original_name:
                return False, "One of the uploaded receipts has no valid filename.", None
            if extension not in allowed_extensions:
                return False, "Only PDF, JPG, JPEG, and PNG files are allowed for receipts.", None
            prepared.append((uploaded, original_name))

        os.makedirs(upload_folder, exist_ok=True)
        saved_paths = []
        employee_id = getattr(current_user, "employee_id", None) if current_user is not None else None
        if employee_id is None and current_user is not None:
            employee = getattr(current_user, "employee", None)
            employee_id = getattr(employee, "id", None) if employee else None

        batch_issues = []
        try:
            # Preserve non-file form choices through human-resolution.
            current_user._claim_form_options = form_options if current_user is not None else {}
            # Save every receipt first, then create one claim containing all
            # receipt records and all extracted expense items.
            for uploaded, original_name in prepared:
                ClaimService._debug_log("SUBMIT_SAVE_RECEIPT original=%s", original_name)
                stored_name = f"{uuid4().hex}_{original_name}"
                file_path = os.path.join(upload_folder, stored_name)
                uploaded.save(file_path)
                saved_paths.append((file_path, original_name))
                ClaimService._debug_log("SUBMIT_RECEIPT_SAVED original=%s path=%s", original_name, file_path)

            # Keep every uploaded file in the extraction batch. Raw-file SHA-256
            # collisions must not silently discard receipts; duplicate screening
            # happens later using receipt visual similarity plus identity context.
            extraction_paths = list(saved_paths)

            # The whole batch is submitted, but each receipt has an independent
            # result. A timeout/failure for one file must not cancel other futures.
            max_workers = max(1, min(
                len(extraction_paths),
                int(current_app.config.get("OLLAMA_MAX_CONCURRENT_REQUESTS", 4) or 4),
            ))
            try:
                retry_count = max(0, min(2, int(os.environ.get("OLLAMA_RECEIPT_RETRIES", "1") or 1)))
            except (TypeError, ValueError):
                retry_count = 1

            extraction_started_at = time.perf_counter()

            def _extract_one(entry):
                file_path, original_name = entry
                receipt_started_at = time.perf_counter()
                last_error = None
                for attempt in range(retry_count + 1):
                    ClaimService._debug_log("SUBMIT_AI_START original=%s mode=%s attempt=%d/%d path=%s", original_name, ai_mode, attempt + 1, retry_count + 1, file_path)
                    try:
                        ai_document = OllamaClaimExtractionService.extract_document(file_path, mode=ai_mode)
                        if not isinstance(ai_document, dict):
                            raise ValueError("AI extraction returned an invalid document shape")
                        ClaimService._debug_log("SUBMIT_AI_OK original=%s mode=%s attempt=%d duration_seconds=%.2f keys=%s", original_name, ai_mode, attempt + 1, time.perf_counter() - receipt_started_at, list(ai_document.keys()))
                        return file_path, original_name, ai_document, None
                    except Exception as exc:
                        last_error = exc
                        retryable = isinstance(exc, (OllamaUnavailable, TimeoutError)) or "524" in str(exc) or "timeout" in str(exc).lower() or "temporar" in str(exc).lower()
                        if attempt < retry_count and retryable:
                            delay = min(8, 2 ** (attempt + 1))
                            ClaimService._debug_log("SUBMIT_AI_RETRY original=%s delay=%ss error=%r", original_name, delay, exc, level="WARNING")
                            time.sleep(delay)
                            continue
                        break
                ClaimService._debug_log("SUBMIT_AI_FAILED original=%s mode=%s attempts=%d duration_seconds=%.2f error=%r", original_name, ai_mode, attempt + 1, time.perf_counter() - receipt_started_at, last_error, level="ERROR")
                return file_path, original_name, None, f"AI extraction failed after {attempt + 1} attempt(s): {last_error}"

            extraction_results = [None] * len(extraction_paths)
            with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="claim-ai") as executor:
                future_map = {executor.submit(_extract_one, entry): idx for idx, entry in enumerate(extraction_paths)}
                for future in as_completed(future_map):
                    idx = future_map[future]
                    try:
                        extraction_results[idx] = future.result()
                    except Exception as exc:  # defensive: a worker must never cancel sibling receipts
                        file_path, original_name = extraction_paths[idx]
                        extraction_results[idx] = (file_path, original_name, None, str(exc))

            ClaimService._debug_log("SUBMIT_AI_BATCH_COMPLETE mode=%s receipts=%d duration_seconds=%.2f", ai_mode, len(extraction_paths), time.perf_counter() - extraction_started_at)

            for file_path, original_name, ai_document, error in extraction_results:
                if error or ai_document is None:
                    reason = error or "AI returned no extraction data"
                    batch_issues.append({"filename": original_name, "reason": reason})
                    ClaimService._debug_log("SUBMIT_AI_FAILED_KEEP_FILE original=%s error=%s", original_name, reason, level="ERROR")

            if not any(result and result[2] is not None for result in extraction_results):
                try: delattr(current_user, "_claim_form_options")
                except Exception: pass
                summary = "No receipts could be extracted successfully. Uploaded files were retained for recovery. "
                summary += " | ".join(f"{x['filename']}: {x['reason']}" for x in batch_issues)
                ClaimService._debug_log("SUBMIT_TOTAL_NO_EXTRACTION mode=%s duration_seconds=%.2f", ai_mode, time.perf_counter() - batch_started_at, level="WARNING")
                return False, summary, None

            # Match employee/institution in deterministic upload order after AI
            # extraction has completed. This avoids concurrent SQLAlchemy ORM
            # work while preserving the original receipt order.
            extracted_receipts = []
            batch_fingerprints = []
            for file_path, original_name, ai_document, extraction_error in extraction_results:
                if extraction_error or ai_document is None:
                    continue
                # Fraud detection and ORM work remain on the Flask request thread;
                # the expensive multimodal HTTP calls above are the only parallel
                # stage. This keeps SQLAlchemy's scoped session thread-safe.
                try:
                    fraud_bundle = DuplicateDetector.check_or_raise(file_path, ai_document)
                except DuplicateReceiptError as exc:
                    batch_issues.append({"filename": original_name, "reason": str(exc)})
                    ClaimService._debug_log("SUBMIT_DUPLICATE_POST_AI_SKIP original=%s reason=%s", original_name, exc, level="WARNING")
                    try: os.remove(file_path)
                    except OSError: pass
                    continue

                # Reject two copies of the same receipt in one batch. Use the
                # already-computed fingerprints instead of recalculating pHash.
                duplicate_of = None
                for prior_path, prior_name, prior_doc, prior_employee, prior_institution, prior_bundle in batch_fingerprints:
                    same_file = fraud_bundle["file_sha256"] == prior_bundle[0]
                    same_visual = bool(
                        fraud_bundle.get("image_phash")
                        and prior_bundle[1]
                        and DuplicateDetector._hamming(fraud_bundle["image_phash"], prior_bundle[1]) <= DuplicateDetector.PHASH_MAX_DISTANCE
                        and (
                            fraud_bundle.get("receipt_metadata_fingerprint") == prior_bundle[2]
                            or (
                                fraud_bundle.get("receipt_metadata_key")
                                and fraud_bundle.get("receipt_metadata_key") == DuplicateDetector._metadata_identifier_key(prior_doc)
                            )
                        )
                    )
                    current_doc = ai_document.get("document") or {}
                    prior_document = prior_doc.get("document") or {}
                    current_receipt = current_doc.get("receipt") or {}
                    prior_receipt = prior_document.get("receipt") or {}
                    current_totals = current_doc.get("totals") or {}
                    prior_totals = prior_document.get("totals") or {}
                    current_institution = current_doc.get("institution") or {}
                    prior_institution = prior_document.get("institution") or {}
                    current_has_identity = bool(
                        DuplicateDetector._metadata_identifier_key(ai_document)
                        or ((current_receipt.get("receipt_date") or current_receipt.get("transaction_date"))
                            and current_institution.get("name") and current_totals.get("total") is not None)
                    )
                    prior_has_identity = bool(
                        DuplicateDetector._metadata_identifier_key(prior_doc)
                        or ((prior_receipt.get("receipt_date") or prior_receipt.get("transaction_date"))
                            and prior_institution.get("name") and prior_totals.get("total") is not None)
                    )
                    same_metadata = bool(current_has_identity and prior_has_identity) and (
                        fraud_bundle.get("receipt_metadata_fingerprint") == prior_bundle[2]
                    )
                    if same_file or same_visual or same_metadata:
                        duplicate_of = prior_name
                        break
                if duplicate_of:
                    batch_issues.append({"filename": original_name, "reason": f"same receipt as '{duplicate_of}' in this batch; skipped"})
                    ClaimService._debug_log("SUBMIT_DUPLICATE_BATCH_AI_SKIP original=%s duplicate_of=%s", original_name, duplicate_of, level="WARNING")
                    try: os.remove(file_path)
                    except OSError: pass
                    continue

                document = ai_document.get("document") or {}
                employee_data = document.get("employee") or {}
                patient_data = document.get("patient") or {}
                if not employee_data.get("name"):
                    employee_data["name"] = patient_data.get("name")
                if AuthorizationService.is_employee(current_user):
                    employee = ClaimService._current_employee(current_user)
                    match_error = None if employee else "Authenticated Employee account could not be linked to directory."
                else:
                    employee, match_error = EmployeeDirectoryService.match_employee(employee_data)
                if category == ClaimService.OPTICS:
                    institution, institution_error = None, None
                else:
                    institution, institution_error = ClaimService._resolve_institution(document.get("institution") or {}, category=category)
                ClaimService._debug_log("SUBMIT_MATCH original=%s employee=%s emp_error=%r institution=%s inst_error=%r category=%s", original_name, getattr(employee, "full_name", None), match_error, getattr(institution, "name", None), institution_error, category)
                extracted_receipts.append((file_path, original_name, ai_document, employee, institution))
                batch_fingerprints.append((file_path, original_name, ai_document, employee, institution, (fraud_bundle["file_sha256"], fraud_bundle.get("image_phash"), fraud_bundle["receipt_metadata_fingerprint"])))

            if not extracted_receipts:
                try: delattr(current_user, "_claim_form_options")
                except Exception: pass
                summary = "No non-duplicate receipts were available to create a claim. "
                summary += " | ".join(f"{x['filename']}: {x['reason']}" for x in batch_issues)
                return False, summary, None

            if batch_issues:
                form_options["_batch_issues"] = batch_issues
                current_user._claim_form_options = form_options

            unresolved = []
            for idx, (file_path, original_name, ai_document, employee, institution) in enumerate(extracted_receipts):
                if not employee or (category != ClaimService.OPTICS and not institution):
                    document = ai_document.get("document") or {}
                    employee_data = document.get("employee") or {}
                    patient_data = document.get("patient") or {}
                    if not employee_data.get("name"): employee_data["name"] = patient_data.get("name")
                    _, emp_error = (ClaimService._current_employee(current_user), None) if AuthorizationService.is_employee(current_user) else EmployeeDirectoryService.match_employee(employee_data)
                    raw_institution = (document.get("institution") or {}).get("name")
                    if category == ClaimService.OPTICS:
                        inst_error = None
                    else:
                        _, inst_error = ClaimService._resolve_institution(document.get("institution") or {}, category=category)
                    unresolved.append({
                        "index": idx, "receipt_name": original_name,
                        "employee_error": emp_error if not employee else None,
                        "employee_data": employee_data if not employee else {},
                        "employee_suggestions": EmployeeDirectoryService.suggest_matches(employee_data, 8) if not employee else [],
                        "institution_error": inst_error if not institution else None,
                        "institution_name": raw_institution if not institution else "",
                        "institution_suggestions": ClaimService._institution_suggestions(raw_institution, 8) if not institution else [],
                        "match_preview": ClaimService._build_resolution_match_preview(category, institution, ai_document),
                    })
            if unresolved:
                ClaimService._debug_log("SUBMIT_UNRESOLVED count=%d details=%r -> SAVE_PENDING", len(unresolved), unresolved, level="WARNING")
                token, payload = ClaimService._save_pending_resolution(category, current_user, extracted_receipts, unresolved)
                ClaimService._debug_log("SUBMIT_PENDING_SAVED token=%s path=%s", token, payload.get("_path"))
                ClaimService._debug_log("SUBMIT_TOTAL_BEFORE_RESOLUTION mode=%s duration_seconds=%.2f", ai_mode, time.perf_counter() - batch_started_at)
                raise ClaimResolutionRequired(token, unresolved)

            # Do not block a valid claim merely because one institution has not
            # yet received an approved price list. Items for that institution are
            # marked PRICE_LIST_UNAVAILABLE during creation so HR can see exactly
            # what still needs price-list validation.

            ClaimService._debug_log("SUBMIT_ALL_MATCHED -> CREATE")
            result = ClaimService._create_claim_from_extracted(category, extracted_receipts, current_user, form_options=form_options)
            result = ClaimService._append_batch_issues(result, batch_issues)
            ClaimService._debug_log("SUBMIT_CREATE_RESULT=%r", result)
            ClaimService._debug_log("SUBMIT_TOTAL_COMPLETE mode=%s duration_seconds=%.2f", ai_mode, time.perf_counter() - batch_started_at)
            try: delattr(current_user, "_claim_form_options")
            except Exception: pass
            return result

        except ClaimResolutionRequired:
            # Receipt files remain on disk while the user resolves master-data matches.
            raise
        except DuplicateReceiptError as exc:
            ClaimService._debug_log("SUBMIT_DUPLICATE_REJECTED message=%s", exc, level="WARNING")
            from app.extensions import db
            db.session.rollback()
            # Keep uploaded files in place on an unexpected late duplicate
            # collision. This is safer than deleting other valid receipts in
            # the same batch; the filename/reason is reported for recovery.
            ClaimService._debug_log("SUBMIT_DUPLICATE_FILES_PRESERVED paths=%r", [path for path, _ in saved_paths if os.path.exists(path)], level="WARNING")
            return False, str(exc) + " Other uploaded files were retained for recovery.", None
        except IntegrityError as exc:
            # The unique file-hash index is the final database-level safety
            # net for concurrent submissions. Roll back the failed transaction,
            # but preserve uploads because this batch may contain valid receipts
            # alongside the conflicting duplicate.
            from app.extensions import db
            db.session.rollback()
            ClaimService._debug_log("SUBMIT_INTEGRITY_FILES_PRESERVED paths=%r", [path for path, _ in saved_paths if os.path.exists(path)], level="WARNING")
            if "medical_claim_receipts.file_sha256" in str(exc) or "file_sha256" in str(exc):
                return False, (
                    "A duplicate receipt was detected by database protection. "
                    "No further records were committed in the failed transaction; uploaded files were retained for recovery. "
                    "Please retry with the duplicate removed."
                ), None
            raise
        except Exception as exc:
            ClaimService._debug_log("SUBMIT_EXCEPTION type=%s error=%r -> ROLLBACK", type(exc).__name__, exc, level="ERROR")
            from app.extensions import db
            db.session.rollback()
            # Keep uploaded files on unexpected failures for administrator recovery.
            # Successful claims retain their referenced files; unreferenced files can
            # be cleaned up later by a maintenance task after review.
            ClaimService._debug_log("SUBMIT_FILES_PRESERVED count=%d paths=%r", sum(1 for path, _ in saved_paths if os.path.exists(path)), [path for path, _ in saved_paths if os.path.exists(path)], level="WARNING")
            raise

    @staticmethod
    def approve_claim(claim_id, current_user=None):
        if not AuthorizationService.is_hr(current_user):
            return False, "Only HR can approve claims."
        claim = ClaimRepository.get_by_id(claim_id)
        if not claim:
            return False, "Claim not found."
        if claim.status != "PENDING_REVIEW":
            return False, "Only claims pending HR review can be approved."
        ClaimRepository.approve_claim(claim)
        try:
            send_claim_action_notification(claim, current_user, "APPROVED")
        except Exception as exc:
            print("[MAIL][CLAIM-APPROVE][ERROR]", repr(exc))
        return True, "Claim approved."

    @staticmethod
    def reject_claim(claim_id, current_user=None):
        if not AuthorizationService.is_hr(current_user):
            return False, "Only HR can reject claims."
        claim = ClaimRepository.get_by_id(claim_id)
        if not claim:
            return False, "Claim not found."
        if claim.status != "PENDING_REVIEW":
            return False, "Only claims pending HR review can be rejected."
        # Notify while the claim still exists, then permanently remove it.
        try:
            send_claim_action_notification(claim, current_user, "DECLINED")
        except Exception as exc:
            print("[MAIL][CLAIM-REJECT][ERROR]", repr(exc))

        receipt_path = getattr(claim, "receipt_file_path", None)

        from app.extensions import db
        db.session.delete(claim)
        db.session.commit()

        if receipt_path and os.path.isfile(receipt_path):
            try:
                os.remove(receipt_path)
            except OSError as exc:
                print("[CLAIM][REJECT-CLEANUP][ERROR]", repr(exc))

        return True, "Claim rejected and permanently removed."
