from datetime import datetime

from flask import request

from flask_login import current_user

from app.extensions import db


class AuditService:

    @staticmethod
    def record(
        action,
        entity_type=None,
        entity_id=None,
        description=None,
        old_value=None,
        new_value=None,
        user=None
    ):

        if user is None:

            if current_user.is_authenticated:
                user = current_user

        ip_address = None

        if request:

            forwarded = request.headers.get(
                "X-Forwarded-For"
            )

            if forwarded:
                ip_address = (
                    forwarded
                    .split(",")[0]
                    .strip()
                )
            else:
                ip_address = request.remote_addr

        user_agent = None

        if request:

            user_agent = request.headers.get(
                "User-Agent"
            )

        try:

            from app.models.audit_log import AuditLog

        except ImportError:

            return False

        log = AuditLog()

        # User
        if user:

            if hasattr(
                log,
                "user_id"
            ):
                log.user_id = user.id

        # Action
        if hasattr(
            log,
            "action"
        ):
            log.action = action

        # Entity
        if hasattr(
            log,
            "entity_type"
        ):
            log.entity_type = entity_type

        if hasattr(
            log,
            "entity_id"
        ):
            log.entity_id = entity_id

        # Description
        if hasattr(
            log,
            "description"
        ):
            log.description = description

        # Values
        if hasattr(
            log,
            "old_value"
        ):
            log.old_value = old_value

        if hasattr(
            log,
            "new_value"
        ):
            log.new_value = new_value

        # IP
        if hasattr(
            log,
            "ip_address"
        ):
            log.ip_address = ip_address

        # Browser
        if hasattr(
            log,
            "user_agent"
        ):
            log.user_agent = user_agent

        # Timestamp
        if hasattr(
            log,
            "created_at"
        ):
            log.created_at = datetime.utcnow()

        db.session.add(log)

        return True

    @staticmethod
    def commit():

        db.session.commit()