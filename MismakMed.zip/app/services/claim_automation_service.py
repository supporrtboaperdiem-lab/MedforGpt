"""Runtime settings for medical-claim automation.

The settings are intentionally kept outside the database schema so enabling the
feature does not require a migration and survives application restarts/workers.
The file is created with both automation controls enabled by default.
"""
import json
import os
import tempfile
from pathlib import Path
from threading import RLock


class ClaimAutomationService:
    DEFAULTS = {
        "automatic_approval": True,
        "automatic_scoring": True,
    }
    _lock = RLock()

    @classmethod
    def _path(cls):
        # Keep deployment-specific settings beside the SQLite instance data.
        base = os.environ.get("MEDICAL_AUTOMATION_SETTINGS_FILE", "").strip()
        if base:
            return Path(base).expanduser().resolve()
        try:
            from app.config import BASE_DIR
            return BASE_DIR / "instance" / "claim_automation.json"
        except Exception:
            return Path(__file__).resolve().parents[2] / "instance" / "claim_automation.json"

    @classmethod
    def get_settings(cls):
        path = cls._path()
        with cls._lock:
            settings = dict(cls.DEFAULTS)
            try:
                if path.is_file():
                    with path.open("r", encoding="utf-8") as fh:
                        raw = json.load(fh)
                    if isinstance(raw, dict):
                        for key in cls.DEFAULTS:
                            if key in raw:
                                settings[key] = bool(raw[key])
            except (OSError, ValueError, TypeError):
                # A corrupt/missing settings file must not break claim submission.
                pass
            return settings

    @classmethod
    def save_settings(cls, automatic_approval=None, automatic_scoring=None):
        current = cls.get_settings()
        if automatic_approval is not None:
            current["automatic_approval"] = bool(automatic_approval)
        if automatic_scoring is not None:
            current["automatic_scoring"] = bool(automatic_scoring)

        path = cls._path()
        path.parent.mkdir(parents=True, exist_ok=True)
        with cls._lock:
            fd, tmp_name = tempfile.mkstemp(prefix=".claim_automation_", suffix=".json", dir=str(path.parent))
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as fh:
                    json.dump(current, fh, indent=2, sort_keys=True)
                    fh.write("\n")
                    fh.flush()
                    os.fsync(fh.fileno())
                os.replace(tmp_name, path)
            finally:
                try:
                    os.unlink(tmp_name)
                except FileNotFoundError:
                    pass
        return current

    @classmethod
    def automatic_approval_enabled(cls):
        return cls.get_settings()["automatic_approval"]

    @classmethod
    def automatic_scoring_enabled(cls):
        return cls.get_settings()["automatic_scoring"]
