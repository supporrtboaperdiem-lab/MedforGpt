"""Bank non-covered pharmacy commodities from app/data/pharma_exclude.xlsx."""
from functools import lru_cache
import json
from pathlib import Path
import re
import unicodedata

from openpyxl import load_workbook


_DATA_DIR = Path(__file__).resolve().parents[1] / "data"
_EXCEL_PATH = _DATA_DIR / "pharma_exclude.xlsx"
_RULES_PATH = _DATA_DIR / "pharmacy_exclusion_rules.json"
_DEFAULT_RULES = {
    "allow_names": [],
    "exclude_names": [],
    "exclude_brands": [
        "Vaselline", "Vaseline", "Dezor", "Fenza", "Preganum", "Vovo", "Tafflen", "Taflen",
        "Dove", "Nivea", "Photoblock", "Cetaphil", "Fix Derma", "CeraVe", "Cervae", "Cyclogest",
        "Medicam", "Lifebuoy",
    ],
    "exclude_categories": [
        "prenatal", "vaselline", "vaseline", "shampoo", "shampo", "sunscreen", "sun screen",
        "tooth brush", "toothbrush", "toothpaste", "tooth paste", "paraffin", "parafin", "paraphin",
        "liquid paraffin", "paraffin oil", "cream", "soap", "heel cushion", "spf", "moisturizing",
        "moisturising", "whey protein", "protein powder", "varicose vein stocking", "stocking",
        "crepe elastic bandage", "elastic bandage", "bandage", "cleanser", "cyclogest",
    ],
}


def load_manual_rules():
    """Load editable HR rules; defaults are merged without replacing local edits."""
    try:
        data = json.loads(_RULES_PATH.read_text(encoding="utf-8")) if _RULES_PATH.exists() else {}
    except (OSError, ValueError):
        data = {}
    return {key: list(data.get(key, defaults)) for key, defaults in _DEFAULT_RULES.items()}


def save_manual_rules(rules):
    _DATA_DIR.mkdir(parents=True, exist_ok=True)
    cleaned = {}
    for key in _DEFAULT_RULES:
        values = rules.get(key, [])
        if isinstance(values, str):
            values = values.splitlines()
        cleaned[key] = list(dict.fromkeys(str(v).strip() for v in values if str(v).strip()))
    _RULES_PATH.write_text(json.dumps(cleaned, ensure_ascii=False, indent=2), encoding="utf-8")
    excluded_names.cache_clear()
    return cleaned
_GENERIC_TOKENS = {
    "cream", "soap", "shampoo", "shampo", "oil", "liquid", "powder",
    "bandage", "support", "stocking", "parafin", "paraffin", "paraphin",
    "screen", "sun", "skin", "sensitive", "hydrating", "moisturizing",
    "moisturizer", "moisturiser", "cleanser",
    "suppo", "suppository", "large", "medium", "plus", "spf", "gm", "ml",
    "cm", "mg", "the", "and", "of", "for", "a", "an",
}


def _normalize(value):
    text = unicodedata.normalize("NFKD", str(value or "")).encode("ascii", "ignore").decode("ascii")
    return " ".join(re.findall(r"[a-z0-9]+", text.lower()))


def _tokens(value):
    return [t for t in _normalize(value).split() if t]


@lru_cache(maxsize=1)
def excluded_names():
    """Read commodity names from column H; rows 4 onward contain the list."""
    names = []
    if not _EXCEL_PATH.is_file():
        return tuple(names)
    workbook = load_workbook(_EXCEL_PATH, read_only=True, data_only=True)
    try:
        sheet = workbook.active
        for row in sheet.iter_rows(min_row=4, values_only=True):
            # In the supplied workbook, column H (index 7) is the excluded commodity.
            value = row[7] if len(row) > 7 else None
            name = str(value or "").strip()
            if name and "excluded" not in name.lower() and name.lower() not in {"none", "nan"}:
                names.append(name)
    finally:
        workbook.close()
    return tuple(names)


def is_excluded(service_name, raw_text=None):
    """Conservative OCR-tolerant match against the supplied 100%-excluded list.

    Exact normalized names and full multi-word phrase containment are accepted.
    Single-word matches are limited to distinctive list terms, avoiding generic
    words like "cream" from excluding an otherwise eligible product by themselves.
    """
    from rapidfuzz.fuzz import ratio

    candidates = [_normalize(service_name), _normalize(raw_text)]
    candidates = [c for c in candidates if c]
    if not candidates:
        return False, None
    candidate_tokens = [set(c.split()) for c in candidates]
    rules = load_manual_rules()

    # Manual product rules should classify the line item, not unrelated words elsewhere
    # on a full receipt OCR. The service name is the primary classification field.
    item_text = _normalize(service_name)
    # Explicit allow rules always win over spreadsheet/category/brand matches.
    for allowed in rules.get("allow_names", []):
        norm_allowed = _normalize(allowed)
        if norm_allowed and item_text and (norm_allowed in item_text or item_text in norm_allowed):
            return False, None

    # Editable individual names, brands, and broad product categories.
    for name in rules.get("exclude_names", []):
        norm_name = _normalize(name)
        if norm_name and norm_name in item_text:
            return True, name
    for brand in rules.get("exclude_brands", []):
        norm_brand = _normalize(brand)
        if norm_brand and re.search(r"\b" + re.escape(norm_brand) + r"\b", item_text):
            return True, brand
    for category in rules.get("exclude_categories", []):
        norm_category = _normalize(category)
        if not norm_category:
            continue
        # Category terms are applied as whole words, so e.g. soap does not match "soapy".
        if re.search(r"\b" + re.escape(norm_category) + r"\b", item_text):
            return True, category

    list_names = sorted(excluded_names(), key=lambda value: len(_normalize(value)), reverse=True)

    # Exact name match first, so "Dove Soap" is not reported merely as "Soap".
    for listed in list_names:
        norm_listed = _normalize(listed)
        if norm_listed and any(candidate == norm_listed for candidate in candidates):
            return True, listed

    # Whole phrase / compact spelling matches handle punctuation and spacing OCR noise.
    for listed in list_names:
        norm_listed = _normalize(listed)
        listed_compact = "".join(norm_listed.split())
        if not norm_listed:
            continue
        for candidate in candidates:
            candidate_compact = "".join(candidate.split())
            if len(candidate.split()) > 1 and (norm_listed in candidate or candidate in norm_listed):
                return True, listed
            if candidate_compact == listed_compact:
                return True, listed

    # Distinctive brand/item words still match when OCR omits the rest of the
    # printed description (e.g. "Cetaphil" or "Cyclogest").
    for listed in list_names:
        listed_tokens = set(_normalize(listed).split())
        for token_set in candidate_tokens:
            for listed_token in listed_tokens:
                if len(listed_token) < 5 or listed_token in _GENERIC_TOKENS:
                    continue
                for candidate_token in token_set:
                    if len(candidate_token) >= 5 and ratio(candidate_token, listed_token) >= 82:
                        return True, listed
    return False, None
