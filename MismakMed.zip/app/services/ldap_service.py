"""Bank of Abyssinia Active Directory integration.

Uses the same ldap3 service-account bind pattern as the verified BOA
LDAP exporter supplied for this project.
"""
import os
from ldap3 import Server, Connection, ALL, SUBTREE

LDAP_SERVER = os.getenv("LDAP_SERVER", "")
LDAP_PORT = int(os.getenv("LDAP_PORT", "389"))
BASE_DN = os.getenv("LDAP_BASE_DN", "")
LDAP_USERNAME = os.getenv("LDAP_USERNAME", "")
LDAP_PASSWORD = os.getenv("LDAP_PASSWORD", "")
DOMAIN = os.getenv("LDAP_DOMAIN", "")
LDAP_CONNECT_TIMEOUT = int(os.getenv("LDAP_CONNECT_TIMEOUT", "5"))

ATTRIBUTES = [
    "sAMAccountName", "userPrincipalName", "displayName", "givenName", "middleName", "sn",
    "mail", "proxyAddresses", "targetAddress", "title", "department", "company",
    "physicalDeliveryOfficeName", "division", "employeeType", "mobile", "telephoneNumber",
    "homePhone", "otherTelephone", "facsimileTelephoneNumber", "pager", "streetAddress",
    "postOfficeBox", "l", "st", "postalCode", "co", "c", "employeeID", "employeeNumber",
    "distinguishedName", "canonicalName", "manager", "description", "userAccountControl",
    "accountExpires", "pwdLastSet", "whenCreated", "whenChanged", "objectGUID", "objectSid",
    "memberOf"
]

def _value(entry, attr):
    try:
        value = entry[attr].value
        if isinstance(value, (list, tuple)):
            return list(value)
        return value or ""
    except Exception:
        return ""

def _server():
    return Server(
        LDAP_SERVER,
        port=LDAP_PORT,
        get_info=ALL,
        connect_timeout=LDAP_CONNECT_TIMEOUT,
    )

def _safe_filter_value(value):
    # Minimal LDAP filter escaping for user-supplied lookup values.
    return (value or "").replace("\\", "").replace("*", "").replace("(", "").replace(")", "")

def _entry_info(entry, fallback_email=""):
    info = {attr: _value(entry, attr) for attr in ATTRIBUTES}
    info["username"] = info.get("sAMAccountName") or ""
    info["email"] = (info.get("mail") or info.get("userPrincipalName") or fallback_email).lower()
    return info

def directory_search(email):
    """Find a BOA account using the verified BOA LDAP service account."""
    email = (email or "").strip().lower()
    if not email:
        return False, None, "Email is required."
    try:
        print(f"[LDAP][DIRECTORY] Connecting to {LDAP_SERVER}:{LDAP_PORT} as {LDAP_USERNAME}", flush=True)
        server = Server(
            LDAP_SERVER,
            port=LDAP_PORT,
            get_info=ALL,
            connect_timeout=LDAP_CONNECT_TIMEOUT,
        )
        # IMPORTANT: this intentionally matches the known-working BOA
        # exporter: user=email, password=password, auto_bind=True.
        conn = Connection(
            server,
            user=LDAP_USERNAME,
            password=LDAP_PASSWORD,
            auto_bind=True,
            receive_timeout=LDAP_CONNECT_TIMEOUT,
        )
        sam = _safe_filter_value(email.split("@", 1)[0])
        safe_email = _safe_filter_value(email)
        ok = conn.search(
            search_base=BASE_DN,
            search_filter=(
                f"(&(objectCategory=person)(objectClass=user)"
                f"(|(mail={safe_email})(userPrincipalName={safe_email})(sAMAccountName={sam})))"
            ),
            search_scope=SUBTREE,
            attributes=ATTRIBUTES,
        )
        if not ok or not conn.entries:
            result = conn.result
            conn.unbind()
            return False, None, f"User not found in BOA LDAP directory. {result.get('description', '')}".strip()
        info = _entry_info(conn.entries[0], email)
        conn.unbind()
        return True, info, "LDAP directory lookup successful."
    except Exception as exc:
        print(f"[LDAP][DIRECTORY] search failed server={LDAP_SERVER} port={LDAP_PORT} base_dn={BASE_DN}: {exc}", flush=True)
        return False, None, f"BOA LDAP directory search failed: {exc}"

def authenticate_user(email, password):
    """Authenticate an employee/HR using the employee's own BOA AD password.

    The service-account bind above is used for directory lookup. This bind uses
    the employee credential supplied on the login/registration form.
    """
    email = (email or "").strip().lower()
    password = password or ""
    if not email or not password:
        return False, None, "Email and password are required."
    if "@" not in email:
        return False, None, "Use your BOA organizational email address."
    sam = _safe_filter_value(email.split("@", 1)[0])
    try:
        server = Server(
            LDAP_SERVER,
            port=LDAP_PORT,
            get_info=ALL,
            connect_timeout=LDAP_CONNECT_TIMEOUT,
        )
        # Authenticate exactly against AD using the submitted employee
        # credential. The application does not save this password.
        #
        # BOA accounts are entered as user@bankofabyssinia.com. Use that
        # UPN/email directly for the bind so LDAP_DOMAIN is NOT required in
        # the shell environment. This avoids constructing an invalid bind
        # when LDAP_DOMAIN is unset.
        #
        # If a deployment explicitly supplies LDAP_DOMAIN and the directory
        # requires DOMAIN\\username, retain that as a compatibility fallback.
        bind_candidates = [email]
        if DOMAIN:
            bind_candidates.append(f"{DOMAIN}\\{sam}")

        last_exc = None
        conn = None
        for bind_user in bind_candidates:
            try:
                conn = Connection(
                    server,
                    user=bind_user,
                    password=password,
                    auto_bind=True,
                    receive_timeout=LDAP_CONNECT_TIMEOUT,
                )
                break
            except Exception as exc:
                last_exc = exc
                conn = None

        if conn is None:
            raise last_exc or RuntimeError("LDAP authentication failed")
        ok = conn.search(
            search_base=BASE_DN,
            search_filter=f"(&(objectCategory=person)(objectClass=user)(sAMAccountName={sam}))",
            search_scope=SUBTREE,
            attributes=ATTRIBUTES,
        )
        if not ok or not conn.entries:
            result = conn.result
            conn.unbind()
            return False, None, f"LDAP authentication succeeded but directory lookup failed: {result.get('description', '')}".strip()
        info = _entry_info(conn.entries[0], email)
        conn.unbind()
        return True, info, "LDAP authentication successful."
    except Exception as exc:
        return False, None, f"Invalid BOA LDAP username/password or LDAP connection failed: {exc}"

# Compatibility aliases used by earlier authentication code.
def verify_ldap(email, password):
    return authenticate_user(email, password)

def authenticate_ldap(email, password):
    success, _, _ = authenticate_user(email, password)
    return success
