(() => {
  "use strict";

  const reduceMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches;

  const initReveal = () => {
    const items = document.querySelectorAll(".reveal-up, .workflow-card, .dashboard-header, .glass-card, .data-card");
    if (!items.length || reduceMotion || !("IntersectionObserver" in window)) return;
    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08 });
    items.forEach((item) => observer.observe(item));
  };

  const initRegistration = () => {
    const form = document.querySelector("[data-registration-form]");
    if (!form) return;

    const role = form.querySelector("[data-registration-role]");
    const fields = form.querySelector("[data-registration-fields]");
    const inputs = [...form.querySelectorAll("[data-registration-input]")];
    const email = form.querySelector("#email");
    const confirm = form.querySelector("#confirm_password");
    const confirmWrap = form.querySelector("[data-confirm-wrap]");
    const submit = form.querySelector("[data-registration-submit]");
    const message = form.querySelector("[data-role-message]");
    const hint = form.querySelector("[data-domain-hint]");

    const employeeOrHr = () => {
      const value = (role.value || "").trim().toLowerCase();
      return value === "employee" || value === "hr";
    };

    const update = () => {
      const selected = Boolean(role.value);
      const restricted = employeeOrHr();

      fields?.classList.toggle("unlocked", selected);
      fields?.setAttribute("aria-disabled", String(!selected));
      inputs.forEach((input) => {
        input.disabled = !selected;
      });
      if (submit) submit.disabled = !selected;

      if (confirm) {
        confirm.required = selected && !restricted;
        confirm.disabled = !selected || restricted;
        if (restricted) confirm.value = "";
      }
      if (confirmWrap) confirmWrap.hidden = !selected || restricted;

      if (email) {
        email.required = selected;
        email.placeholder = restricted ? "name@bankofabyssinia.com" : "name@example.com";
        email.setAttribute("pattern", restricted ? ".+@bankofabyssinia\\.com$" : ".+");
      }

      if (hint) {
        hint.textContent = restricted
          ? "Required domain: @bankofabyssinia.com"
          : "Use your organizational email address where applicable.";
      }


      if (message) {
        if (!selected) {
          message.innerHTML = "<strong>Role workflow</strong><p>Select a role to see its approval and email requirements.</p>";
        } else if ((role.value || "").trim().toLowerCase() === "employee") {
          message.innerHTML = "<strong>Employee account</strong><p>Email and password are required. Spouse information is registered from the Employee dashboard after account creation; spouse expenses stay under your employee record and are reimbursed at 90%.</p>";
        } else if (restricted) {
          message.innerHTML = "<strong>HR account</strong><p>Email and password are required. HR requires Administrator approval.</p>";
        } else {
          message.innerHTML = "<strong>Administrator review</strong><p>Email and password are required. The requested role will follow the existing Administrator approval workflow.</p>";
        }
      }
    };

    role?.addEventListener("change", update);
    update();
  };

  const initPasswordHints = () => {
    document.querySelectorAll('input[type="password"]').forEach((input) => {
      input.addEventListener("input", () => {
        if (input.minLength > 0 && input.value.length > 0) {
          input.classList.toggle("field-valid", input.value.length >= input.minLength);
        }
      });
    });
  };


  const initTheme = () => {
    const root = document.documentElement;
    const control = document.querySelector("[data-theme-control]");
    if (!control) return;
    const trigger = control.querySelector("[data-theme-trigger]");
    const label = control.querySelector("[data-theme-label]");
    const names = {aurora:"Aurora",ocean:"Ocean",emerald:"Emerald",violet:"Violet",rose:"Rose",amber:"Amber",ruby:"Ruby",sapphire:"Sapphire",midnight:"Midnight",light:"Pearl"};
    let saved = localStorage.getItem("boa-medical-theme") || "aurora";
    if (!names[saved]) saved = "aurora";
    const apply = theme => {
      root.dataset.theme = theme;
      localStorage.setItem("boa-medical-theme", theme);
      if (label) label.textContent = names[theme];
      control.querySelectorAll("[data-theme-option]").forEach(o => o.classList.toggle("is-active", o.dataset.themeOption === theme));
    };
    apply(saved);
    trigger?.addEventListener("click", e => { e.stopPropagation(); const open = control.classList.toggle("is-open"); trigger.setAttribute("aria-expanded", String(open)); });
    control.querySelectorAll("[data-theme-option]").forEach(option => option.addEventListener("click", () => { apply(option.dataset.themeOption); control.classList.remove("is-open"); trigger?.setAttribute("aria-expanded","false"); }));
    control.querySelector("[data-theme-reset]")?.addEventListener("click", () => { apply("aurora"); });
    document.addEventListener("click", e => { if (!control.contains(e.target)) { control.classList.remove("is-open"); trigger?.setAttribute("aria-expanded","false"); } });
  };

  document.addEventListener("DOMContentLoaded", () => {
    initTheme();
    initReveal();
    initRegistration();
    initPasswordHints();
  });
})();

/* =============================================================
   BOA PROCESSING / TRANSITION ENGINE
   ============================================================= */
(() => {
  "use strict";
  const overlay = document.querySelector("[data-processing-overlay]");
  if (!overlay) return;

  const title = overlay.querySelector("[data-processing-title]");
  const subtitle = overlay.querySelector("[data-processing-subtitle]");
  const steps = [...overlay.querySelectorAll("[data-processing-step]")];
  let timer = null;

  const labels = [
    ["Validating your request", "BOA Intelligent Workflow Engine"],
    ["Securing your information", "Protected HRM transaction channel"],
    ["Processing securely", "Medical Reimbursement Workflow Engine"],
    ["Finalizing your request", "Bank of Abyssinia HRM Team"]
  ];

  function activate(message) {
    if (message && title) title.textContent = message;
    overlay.classList.add("is-active");
    overlay.setAttribute("aria-hidden", "false");
    let i = 0;
    clearInterval(timer);
    const tick = () => {
      const item = labels[i % labels.length];
      if (title) title.textContent = item[0];
      if (subtitle) subtitle.textContent = item[1];
      steps.forEach((s, idx) => s.classList.toggle("is-current", idx === i % steps.length));
      i += 1;
    };
    tick();
    timer = setInterval(tick, 900);
  }

  function deactivate() {
    clearInterval(timer);
    overlay.classList.remove("is-active");
    overlay.setAttribute("aria-hidden", "true");
  }

  window.BOAProcessing = { activate, deactivate };

  window.addEventListener("pageshow", () => {
    window.setTimeout(deactivate, 180);
  });

  document.addEventListener("submit", (event) => {
    const form = event.target;
    if (!(form instanceof HTMLFormElement)) return;
    if (form.hasAttribute("data-no-processing") || form.target === "_blank") return;
    if (form.checkValidity && !form.checkValidity()) return;
    activate();
  }, true);

  document.addEventListener("click", (event) => {
    const link = event.target.closest?.("a[href]");
    if (!link) return;
    if (event.defaultPrevented) return;
    if (link.hasAttribute("data-no-processing") || link.target === "_blank") return;
    const href = link.getAttribute("href") || "";
    if (!href || href.startsWith("#") || href.startsWith("javascript:")) return;
    if (link.origin !== window.location.origin) return;
    activate();
  }, true);
})();

/* =============================================================
   LIVE MEDICAL CONSULTATION CLIENT
   Presence, request workflow and consultation history.
   ============================================================= */
(() => {
  "use strict";
  const app = document.querySelector("[data-consultation-app]");
  if (!app) return;

  const peopleEl = app.querySelector("[data-consult-people]");
  const peopleState = app.querySelector("[data-consult-people-state]");
  const requestsEl = app.querySelector("[data-consult-requests]");
  const emptyEl = app.querySelector("[data-consult-empty]");
  const historyEl = app.querySelector("[data-consult-history]");
  const historyEmpty = app.querySelector("[data-consult-history-empty]");
  const connection = app.querySelector("[data-consult-connection]");
  const csrf = document.querySelector('meta[name="csrf-token"]')?.content || "";

  async function post(url, data = {}) {
    const response = await fetch(url, {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", "X-CSRFToken": csrf },
      body: JSON.stringify(data)
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || `Request failed (${response.status})`);
    return payload;
  }

  async function getJson(url) {
    const response = await fetch(url, { credentials: "same-origin", cache: "no-store" });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || `Request failed (${response.status})`);
    return payload;
  }

  async function heartbeat() {
    try {
      await post("/consultation/heartbeat");
      if (connection) { connection.textContent = "LIVE SYNC"; connection.style.color = "#6ee7b7"; }
    } catch (_) {
      if (connection) { connection.textContent = "RECONNECTING"; connection.style.color = "#fcd34d"; }
    }
  }

  function renderPeople(people) {
    if (!people.length) {
      peopleEl.innerHTML = '<div class="consult-empty"><div class="empty-ring">⌁</div><h3>No eligible colleague found</h3><p>Your consultation counterpart will appear here when an active account is available.</p></div>';
      return;
    }
    peopleEl.innerHTML = people.map(person => {
      const initials = (person.name || "BOA").split(/\s+/).map(x => x[0]).join("").slice(0, 2).toUpperCase();
      const available = Boolean(person.available);
      const badge = person.busy ? "BUSY • LIVE" : (person.online ? "ONLINE • AVAILABLE" : "OFFLINE • EMAIL INVITE");
      const buttonText = person.busy ? "Currently LIVE" : (person.online ? "Start LIVE" : "Request & notify");
      return `<div class="consult-person">
        <div class="person-left">
          <div class="avatar-orb">${escapeHtml(initials)}</div>
          <div><div class="person-name">${escapeHtml(person.name)}</div><div class="person-meta">${escapeHtml(person.role || "Medical colleague")}</div>
          <div class="presence-badge ${person.online ? (person.busy ? "busy" : "online") : "offline"}"><i></i>${badge}</div></div>
        </div>
        <button class="call-btn" data-call-person="${person.id}" ${person.busy ? "disabled" : ""}>${buttonText}</button>
      </div>`;
    }).join("");
  }

  function renderRequests(rows) {
    const incoming = rows.filter(x => !x.is_requester && x.status === "PENDING");
    const active = rows.filter(x => x.status === "ACCEPTED" || x.status === "LIVE");
    requestsEl.innerHTML = "";
    [...incoming, ...active].forEach(row => {
      const el = document.createElement("div");
      el.className = "consult-request";
      const label = row.status === "PENDING" ? "Incoming consultation request" : (row.status === "LIVE" ? "LIVE now" : "Accepted — ready to connect");
      const action = row.status === "PENDING"
        ? `<div class="request-actions"><button class="accept" data-accept="${row.id}">Accept & go LIVE</button><button class="decline" data-decline="${row.id}">Decline</button></div>`
        : `<div class="request-actions"><button class="accept" data-open="${escapeHtml(row.token)}">Open LIVE room</button></div>`;
      el.innerHTML = `<div><div class="person-name">${escapeHtml(row.other?.name || "BOA colleague")}</div><div class="person-meta">${escapeHtml(row.other?.role || "Medical colleague")} · ${label}</div><div class="person-meta">Duration: ${escapeHtml(row.duration_label || "00:00")}</div></div>${action}`;
      requestsEl.appendChild(el);
    });
    emptyEl.style.display = (incoming.length || active.length) ? "none" : "block";
  }

  function renderHistory(rows) {
    if (!historyEl || !historyEmpty) return;
    historyEl.innerHTML = "";
    historyEmpty.style.display = rows.length ? "none" : "block";
    rows.forEach(row => {
      const started = row.started_at ? new Date(row.started_at).toLocaleString() : "Not connected";
      const ended = row.ended_at ? new Date(row.ended_at).toLocaleString() : "—";
      const status = row.status === "ENDED" ? "COMPLETED" : row.status;
      const el = document.createElement("div");
      el.className = "consult-request";
      el.innerHTML = `<div>
        <div class="person-name">${escapeHtml(row.other?.name || "BOA colleague")}</div>
        <div class="person-meta">${escapeHtml(row.other?.role || "Medical colleague")} · ${escapeHtml(status)}</div>
        <div class="person-meta">Started: ${escapeHtml(started)}</div>
        <div class="person-meta">Ended: ${escapeHtml(ended)}</div>
      </div><div class="request-duration"><strong>${escapeHtml(row.duration_label || "00:00")}</strong><small>${escapeHtml(row.end_reason || "—")}</small></div>`;
      historyEl.appendChild(el);
    });
  }

  async function refresh() {
    try {
      const [people, mine, history] = await Promise.all([
        getJson("/consultation/people"),
        getJson("/consultation/mine"),
        getJson("/consultation/history")
      ]);
      if (people.ok) {
        renderPeople(people.people || []);
        const online = (people.people || []).filter(x => x.online).length;
        const available = (people.people || []).filter(x => x.available).length;
        peopleState.textContent = `${online} online · ${available} available · presence updates every few seconds`;
      }
      if (mine.ok) renderRequests(mine.consultations || []);
      if (history.ok) renderHistory(history.consultations || []);
    } catch (error) {
      peopleState.textContent = error.message || "Presence connection is temporarily unavailable — retrying automatically.";
    }
  }

  peopleEl.addEventListener("click", async (event) => {
    const button = event.target.closest("[data-call-person]");
    if (!button || button.disabled) return;
    button.disabled = true;
    try {
      const result = await post("/consultation/request", { receiver_id: Number(button.dataset.callPerson) });
      if (result.ok && result.consultation?.token) {
        window.location.href = `/consultation/${encodeURIComponent(result.consultation.token)}/join`;
      } else {
        throw new Error(result.error || "Unable to create consultation request.");
      }
    } catch (error) {
      button.disabled = false;
      alert(error.message || "Unable to create consultation request.");
      refresh();
    }
  });

  requestsEl.addEventListener("click", async (event) => {
    const accept = event.target.closest("[data-accept]");
    const decline = event.target.closest("[data-decline]");
    const open = event.target.closest("[data-open]");
    try {
      if (accept) {
        await post(`/consultation/${accept.dataset.accept}/accept`);
        const mine = await getJson("/consultation/mine");
        const row = (mine.consultations || []).find(x => String(x.id) === String(accept.dataset.accept));
        if (row?.token) window.location.href = `/consultation/${encodeURIComponent(row.token)}/join`;
      } else if (decline) {
        await post(`/consultation/${decline.dataset.decline}/decline`);
        refresh();
      } else if (open) {
        window.location.href = `/consultation/${encodeURIComponent(open.dataset.open)}/join`;
      }
    } catch (error) {
      alert(error.message || "Consultation action failed.");
      refresh();
    }
  });

  app.querySelector("[data-consult-refresh]")?.addEventListener("click", refresh);
  heartbeat();
  refresh();
  window.setInterval(heartbeat, 8000);
  window.setInterval(refresh, 4000);

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>'"]/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;","\"":"&quot;"}[ch]));
  }
})();

/* =============================================================
   LIVE WEBRTC ROOM
   Robust two-way media, serialized ICE signaling, ICE restart and
   connection recovery. Flask carries signaling only; media stays WebRTC.
   ============================================================= */
(() => {
  "use strict";
  const room = document.querySelector("[data-consult-room]");
  if (!room) return;

  const id = room.dataset.consultationId;
  const isRequester = room.dataset.isRequester === "1";
  const remoteVideo = room.querySelector("[data-remote-video]");
  const localVideo = room.querySelector("[data-local-video]");
  const placeholder = room.querySelector("[data-remote-placeholder]");
  const status = room.querySelector("[data-room-status]");
  const durationEl = room.querySelector("[data-room-duration]");
  const mediaMessage = room.querySelector("[data-media-message]");
  const diagnostics = room.querySelector("[data-media-diagnostics]");
  const enableButtons = [...room.querySelectorAll("[data-enable-media]")];
  const csrf = document.querySelector('meta[name="csrf-token"]')?.content || "";

  let pc = null;
  let localStream = null;
  let answerCreated = false;
  let offerCreated = false;
  let startedRecorded = false;
  let ended = false;
  let startedAtMs = null;
  let remoteTrackReceived = false;
  let remoteStream = null;
  let knownRequesterCandidates = 0;
  let knownReceiverCandidates = 0;
  let mediaAttemptInProgress = false;
  let heartbeatTimer = null;
  let pollTimer = null;
  let restartTimer = null;
  let lastRestartAt = 0;
  let checkingSince = 0;
  let checkingWatchdog = null;
  let restartAttempts = 0;
  let lastRemoteOffer = "";
  let lastRemoteAnswer = "";
  let iceConfigPromise = null;
  let candidateSendChain = Promise.resolve();
  const pendingCandidates = [];

  const fallbackIceServers = [
    { urls: "stun:stun.l.google.com:19302" },
    { urls: "stun:stun.cloudflare.com:3478" }
  ];

  async function post(url, data = {}) {
    const response = await fetch(url, {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", "X-CSRFToken": csrf },
      body: JSON.stringify(data),
      keepalive: Boolean(data.keepalive)
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(payload.error || `Request failed (${response.status})`);
      error.status = response.status;
      throw error;
    }
    return payload;
  }

  async function state() {
    const response = await fetch(`/consultation/${id}/state`, {
      credentials: "same-origin",
      cache: "no-store"
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || `State request failed (${response.status})`);
    return payload;
  }

  async function loadIceConfig() {
    if (iceConfigPromise) return iceConfigPromise;
    iceConfigPromise = fetch("/consultation/ice-config", {
      credentials: "same-origin",
      cache: "no-store"
    }).then(async response => {
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || !payload.ok || !Array.isArray(payload.ice_servers)) {
        return fallbackIceServers;
      }
      return payload.ice_servers.length ? payload.ice_servers : fallbackIceServers;
    }).catch(() => fallbackIceServers);
    return iceConfigPromise;
  }

  async function sendSignal(kind, value) {
    // Candidate writes are deliberately serialized. The old implementation
    // fired many POSTs at once; with SQLite this could cause two candidate
    // requests to read/modify/write the same JSON column and overwrite one
    // another. Losing even one srflx/relay candidate can prevent connectivity.
    if (kind !== "candidate") {
      return post(`/consultation/${id}/signal`, { kind, value });
    }
    candidateSendChain = candidateSendChain
      .catch(() => {})
      .then(() => post(`/consultation/${id}/signal`, { kind, value }));
    return candidateSendChain;
  }

  function setStatus(text, tone = "normal") {
    if (!status) return;
    status.textContent = text;
    if (tone === "success") status.style.color = "#6ee7b7";
    else if (tone === "warning") status.style.color = "#fcd34d";
    else if (tone === "error") status.style.color = "#fca5a5";
    else status.style.color = "#6ee7b7";
  }

  function setMediaMessage(text) {
    if (mediaMessage) mediaMessage.textContent = text;
  }

  function setDiagnostics(text, show = true) {
    if (!diagnostics) return;
    diagnostics.hidden = !show;
    diagnostics.textContent = text || "";
  }

  function setEnableButtons(show, label = "Enable camera & microphone") {
    enableButtons.forEach(button => {
      button.hidden = !show;
      button.disabled = false;
      button.textContent = label;
    });
  }

  function describeMediaError(error) {
    const name = error?.name || "UnknownError";
    const messages = {
      NotAllowedError: "Camera or microphone permission was denied. Allow both devices for this site, then press Enable media again.",
      PermissionDeniedError: "Camera or microphone permission was denied. Allow both devices for this site, then press Enable media again.",
      NotFoundError: "The browser could not find a camera or microphone. Connect/enable both devices and try again.",
      DevicesNotFoundError: "The browser could not find a camera or microphone. Connect/enable both devices and try again.",
      NotReadableError: "The camera or microphone could not be opened. Another application, browser tab, or browser profile may already be using the device. Close Teams, Zoom, OBS and other browser tabs using the device, then retry.",
      TrackStartError: "The camera or microphone could not be started. Close other apps using the device and retry.",
      OverconstrainedError: "The requested media settings are not supported by the available device.",
      SecurityError: "Browser security prevented camera/microphone access. Use HTTPS or localhost and allow device access.",
      AbortError: "The browser aborted camera/microphone startup. Retry the media connection.",
      TypeError: "Camera/microphone APIs are unavailable in this browser context. Use HTTPS or localhost."
    };
    const base = messages[name] || `Media startup failed (${name}).`;
    const detail = error?.message && error.message !== base ? ` ${error.message}` : "";
    return `${base}${detail} [${name}]`;
  }

  async function markStarted() {
    if (startedRecorded || ended || !pc) return;
    if (pc.connectionState !== "connected" || !remoteTrackReceived) return;

    startedRecorded = true;
    try {
      const result = await post(`/consultation/${id}/start`);
      startedAtMs = result.consultation?.started_at
        ? new Date(result.consultation.started_at).getTime()
        : Date.now();
      setStatus("● LIVE • ENCRYPTED", "success");
      placeholder?.classList.add("hidden");
      setMediaMessage("Secure two-way media connection established.");
      setDiagnostics("Camera ✓  Microphone ✓  Signaling ✓  ICE ✓  Remote media ✓  LIVE ✓", true);
    } catch (error) {
      startedRecorded = false;
      console.warn("Unable to record consultation start", error);
    }
  }

  async function endCall(reason = "ENDED") {
    if (ended) return;
    ended = true;
    clearInterval(heartbeatTimer);
    clearInterval(pollTimer);
    clearTimeout(restartTimer);
    clearCheckingWatchdog();
    try {
      await post(`/consultation/${id}/end`, { reason });
    } catch (error) {
      console.warn("Unable to record consultation end", error);
    }
    pc?.close();
    localStream?.getTracks().forEach(track => track.stop());
    window.location.href = "/consultation/";
  }

  async function roomHeartbeat() {
    if (ended) return;
    try {
      await post(`/consultation/${id}/heartbeat`);
    } catch (error) {
      if (error?.status === 409) {
        clearInterval(heartbeatTimer);
        return;
      }
      console.warn("Consultation heartbeat failed", error);
    }
  }

  async function addCandidate(candidate) {
    if (!candidate || !pc) return;
    if (!pc.remoteDescription) {
      pendingCandidates.push(candidate);
      return;
    }
    try {
      await pc.addIceCandidate(new RTCIceCandidate(candidate));
    } catch (error) {
      console.warn("Unable to add remote ICE candidate", error, candidate);
    }
  }

  async function flushCandidates() {
    if (!pc?.remoteDescription) return;
    while (pendingCandidates.length) {
      const candidate = pendingCandidates.shift();
      try {
        await pc.addIceCandidate(new RTCIceCandidate(candidate));
      } catch (error) {
        console.warn("Unable to flush remote ICE candidate", error, candidate);
      }
    }
  }

  function clearCheckingWatchdog() {
    if (checkingWatchdog) {
      clearTimeout(checkingWatchdog);
      checkingWatchdog = null;
    }
    checkingSince = 0;
  }

  function scheduleIceRestart(reason = "network change") {
    if (!isRequester || ended || !pc) return;
    const now = Date.now();
    if (now - lastRestartAt < 8000) return;
    clearTimeout(restartTimer);
    restartTimer = setTimeout(async () => {
      if (!pc || ended || pc.connectionState === "connected") return;
      lastRestartAt = Date.now();
      restartAttempts += 1;
      try {
        setStatus("RECONNECTING SECURE MEDIA", "warning");
        setMediaMessage(`Refreshing the secure media path (${reason})…`);
        const offer = await pc.createOffer({ iceRestart: true });
        await pc.setLocalDescription(offer);
        await sendSignal("offer", pc.localDescription.toJSON());
        offerCreated = true;
        // Give the restarted ICE agent a bounded amount of time. A browser can
        // remain in "checking" forever when every STUN path is unreachable.
        // The next poll will continue signaling the fresh candidates.
        if (restartAttempts >= 2) {
          setDiagnostics("ICE restart requested. Waiting for a reachable peer path…", true);
        }
      } catch (error) {
        console.warn("ICE restart failed", error);
      }
    }, 1200);
  }

  function wirePeerEvents() {
    pc.onicecandidate = event => {
      if (event.candidate) {
        sendSignal("candidate", event.candidate.toJSON()).catch(error => {
          console.warn("ICE signaling failed", error);
        });
      }
    };

    pc.onicecandidateerror = event => {
      console.warn("ICE candidate error", {
        url: event.url,
        errorCode: event.errorCode,
        errorText: event.errorText,
        address: event.address,
        port: event.port
      });
      if (event.errorCode === 701) {
        setDiagnostics("A STUN server did not respond. ICE will continue using other candidates and can recover with a restart.", true);
      }
    };

    pc.oniceconnectionstatechange = () => {
      const ice = pc.iceConnectionState;
      if (ice === "new") {
        clearCheckingWatchdog();
        setStatus("PREPARING SECURE MEDIA", "warning");
      }
      if (ice === "checking") {
        setStatus("CHECKING SECURE MEDIA PATH", "warning");
        if (!checkingSince) checkingSince = Date.now();
        clearTimeout(checkingWatchdog);
        // Do not let a dead STUN/TURN path leave the room stuck in CHECKING
        // indefinitely. Twelve seconds is long enough for normal LAN/NAT
        // negotiation but short enough to recover from unreachable STUN.
        checkingWatchdog = setTimeout(() => {
          if (ended || !pc || pc.iceConnectionState !== "checking") return;
          setDiagnostics("ICE is still checking after 12 seconds. Refreshing the secure peer path…", true);
          scheduleIceRestart("ICE checking timeout");
        }, 12000);
      }
      if (ice === "connected" || ice === "completed") {
        clearCheckingWatchdog();
        restartAttempts = 0;
        setStatus("MEDIA PATH CONNECTED", "success");
        setDiagnostics(`ICE ${ice} ✓  Waiting for remote audio/video…`, true);
        markStarted();
      }
      if (ice === "disconnected") {
        clearCheckingWatchdog();
        scheduleIceRestart("temporary ICE disconnect");
      }
      if (ice === "failed") {
        clearCheckingWatchdog();
        setStatus("MEDIA PATH FAILED — RECONNECTING", "error");
        setDiagnostics("ICE failed. Retrying the secure peer path…", true);
        scheduleIceRestart("ICE failure");
      }
    };

    pc.onconnectionstatechange = () => {
      const connectionState = pc.connectionState;
      if (connectionState === "connected") {
        setStatus("● LIVE • ENCRYPTED", "success");
        markStarted();
      } else if (connectionState === "connecting") {
        setStatus("CONNECTING SECURELY", "warning");
      } else if (connectionState === "disconnected") {
        setStatus("CONNECTION INTERRUPTED — RECONNECTING", "warning");
        scheduleIceRestart("peer disconnect");
      } else if (connectionState === "failed") {
        setStatus("CONNECTION FAILED — RECONNECTING", "error");
        scheduleIceRestart("peer connection failure");
      } else if (connectionState === "closed") {
        setStatus("CONSULTATION CONNECTION CLOSED", "warning");
      }
    };

    pc.onsignalingstatechange = () => {
      console.debug("[BOA WebRTC] signalingState", pc.signalingState);
    };

    pc.ontrack = event => {
      if (!event.track) return;
      remoteTrackReceived = true;
      remoteStream = event.streams?.[0] || remoteStream || new MediaStream();
      if (!event.streams?.[0]) remoteStream.addTrack(event.track);
      remoteVideo.srcObject = remoteStream;
      remoteVideo.autoplay = true;
      remoteVideo.playsInline = true;
      placeholder?.classList.add("hidden");
      setMediaMessage("Medical colleague connected. Secure two-way audio/video is active.");
      setDiagnostics("Remote video ✓  Remote audio ✓  Secure peer media connected.", true);
      remoteVideo.play().catch(() => {
        setDiagnostics("Remote media is connected. Tap the remote video once if your browser requires a playback gesture.", true);
      });
      markStarted();
    };
  }

  async function createPeer() {
    const iceServers = await loadIceConfig();
    pc = new RTCPeerConnection({
      bundlePolicy: "max-bundle",
      rtcpMuxPolicy: "require",
      iceTransportPolicy: "all",
      iceCandidatePoolSize: 8,
      iceServers
    });
    wirePeerEvents();
    if (localStream) {
      localStream.getTracks().forEach(track => pc.addTrack(track, localStream));
    }
    return pc;
  }

  async function acquireMedia() {
    if (localStream) return localStream;
    if (mediaAttemptInProgress) return null;
    mediaAttemptInProgress = true;
    setEnableButtons(false);
    setDiagnostics("Requesting secure access to camera and microphone…", true);
    setMediaMessage("Allow camera and microphone access in the browser permission prompt.");
    setStatus("REQUESTING DEVICE ACCESS", "warning");

    try {
      const hostname = String(window.location.hostname || "").toLowerCase();
      const isLoopbackOrigin = ["localhost", "127.0.0.1", "::1", "[::1]"].includes(hostname);

      if (!navigator.mediaDevices?.getUserMedia) {
        throw Object.assign(new Error(
          `This browser did not expose camera/microphone access to this page. Origin: ${window.location.origin}. Secure context: ${window.isSecureContext ? "yes" : "no"}. Use HTTPS or localhost.`
        ), { name: "SecurityError" });
      }

      if (!window.isSecureContext && !isLoopbackOrigin) {
        throw Object.assign(
          new Error(`Camera/microphone requires HTTPS or localhost. Current origin: ${window.location.origin}`),
          { name: "SecurityError" }
        );
      }

      try {
        localStream = await navigator.mediaDevices.getUserMedia({
          audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
          video: { width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 30, max: 30 } }
        });
      } catch (firstError) {
        if (["OverconstrainedError", "ConstraintNotSatisfiedError"].includes(firstError?.name)) {
          localStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
        } else {
          throw firstError;
        }
      }

      localVideo.srcObject = localStream;
      localVideo.muted = true;
      await localVideo.play().catch(() => {});

      if (!pc) await createPeer();
      // createPeer already adds local tracks when localStream exists.
      if (!pc.getSenders().some(sender => sender.track === localStream.getAudioTracks()[0]) &&
          !pc.getSenders().some(sender => sender.track === localStream.getVideoTracks()[0])) {
        localStream.getTracks().forEach(track => pc.addTrack(track, localStream));
      }

      if (!localStream.getAudioTracks().length || !localStream.getVideoTracks().length) {
        throw Object.assign(new Error("Both media tracks are required."), { name: "NotFoundError" });
      }

      setDiagnostics("Camera ✓  Microphone ✓  Waiting for secure peer connection…", true);
      setMediaMessage("Your camera and microphone are ready. Establishing the encrypted peer connection…");
      setEnableButtons(false);
      return localStream;
    } catch (error) {
      localStream?.getTracks().forEach(track => track.stop());
      localStream = null;
      pc?.close();
      pc = null;
      offerCreated = false;
      answerCreated = false;
      remoteTrackReceived = false;
      lastRemoteOffer = "";
      lastRemoteAnswer = "";
      const detail = describeMediaError(error);
      setStatus("MEDIA ACCESS REQUIRED", "error");
      setMediaMessage(detail);
      setDiagnostics(detail, true);
      setEnableButtons(true, "Retry camera & microphone");
      return null;
    } finally {
      mediaAttemptInProgress = false;
    }
  }

  async function setupPeer() {
    if (!localStream && !(await acquireMedia())) return false;
    if (!pc) await createPeer();
    return true;
  }

  async function negotiate(current) {
    if (!(await setupPeer())) return;

    if (isRequester && ["ACCEPTED", "LIVE"].includes(current.status)) {
      if (!offerCreated || (current.offer && current.offer !== lastRemoteOffer && pc.signalingState === "stable" && !current.answer)) {
        const offer = await pc.createOffer({
          offerToReceiveAudio: true,
          offerToReceiveVideo: true
        });
        await pc.setLocalDescription(offer);
        await sendSignal("offer", pc.localDescription.toJSON());
        offerCreated = true;
        setStatus("CALLING SECURELY", "warning");
      }
    }

    if (!isRequester && current.offer) {
      const offerText = typeof current.offer === "string" ? current.offer : JSON.stringify(current.offer);
      if (offerText !== lastRemoteOffer &&
          (pc.signalingState === "stable" || pc.signalingState === "have-local-offer")) {
        try {
          const offer = JSON.parse(offerText);
          await pc.setRemoteDescription(new RTCSessionDescription(offer));
          lastRemoteOffer = offerText;
          answerCreated = false;
          await flushCandidates();
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          await sendSignal("answer", pc.localDescription.toJSON());
          answerCreated = true;
          setStatus("JOINING LIVE CALL", "warning");
        } catch (error) {
          console.warn("Unable to process remote offer", error);
        }
      }
    }

    if (isRequester && current.answer) {
      const answerText = typeof current.answer === "string" ? current.answer : JSON.stringify(current.answer);
      if (answerText !== lastRemoteAnswer &&
          (pc.signalingState === "have-local-offer" || pc.signalingState === "have-remote-pranswer")) {
        try {
          await pc.setRemoteDescription(new RTCSessionDescription(JSON.parse(answerText)));
          lastRemoteAnswer = answerText;
          await flushCandidates();
        } catch (error) {
          console.warn("Unable to process remote answer", error);
        }
      }
    }

    const candidates = isRequester ? (current.receiver_candidates || []) : (current.requester_candidates || []);
    const seen = isRequester ? knownReceiverCandidates : knownRequesterCandidates;
    for (let i = seen; i < candidates.length; i += 1) {
      await addCandidate(candidates[i]);
    }
    if (isRequester) knownReceiverCandidates = candidates.length;
    else knownRequesterCandidates = candidates.length;
    await flushCandidates();
  }

  async function poll() {
    if (ended) return;
    try {
      const payload = await state();
      if (!payload.ok) return;
      const current = payload.consultation;
      if (current.started_at) startedAtMs = new Date(current.started_at).getTime();
      if (durationEl && current.duration_label && current.status !== "LIVE") durationEl.textContent = current.duration_label;

      if (current.status === "DECLINED") {
        setStatus("CONSULTATION DECLINED", "error");
        return;
      }
      if (current.status === "ENDED") {
        setStatus(`CONSULTATION ENDED · ${current.duration_label || "00:00"}`, "warning");
        clearInterval(pollTimer);
        clearInterval(heartbeatTimer);
        return;
      }
      if (current.status === "PENDING") {
        setStatus("WAITING FOR MEDICAL COLLEAGUE", "warning");
        setMediaMessage("The consultation request is waiting for acceptance.");
        return;
      }

      await negotiate(current);
    } catch (error) {
      console.warn("[BOA WebRTC] poll/negotiate error", error);
      setStatus(error.message || "Synchronizing consultation…", "warning");
    }
  }

  room.querySelector("[data-toggle-mic]")?.addEventListener("click", event => {
    const track = localStream?.getAudioTracks?.()[0];
    if (!track) {
      setEnableButtons(true, "Enable camera & microphone");
      return;
    }
    track.enabled = !track.enabled;
    event.currentTarget.classList.toggle("active", !track.enabled);
    event.currentTarget.textContent = track.enabled ? "🎙 Microphone" : "🔇 Microphone off";
  });

  room.querySelector("[data-toggle-camera]")?.addEventListener("click", event => {
    const track = localStream?.getVideoTracks?.()[0];
    if (!track) {
      setEnableButtons(true, "Enable camera & microphone");
      return;
    }
    track.enabled = !track.enabled;
    event.currentTarget.classList.toggle("active", !track.enabled);
    event.currentTarget.textContent = track.enabled ? "▣ Camera" : "▣ Camera off";
  });

  enableButtons.forEach(button => {
    button.addEventListener("click", async () => {
      button.disabled = true;
      await acquireMedia();
      await poll();
    });
  });

  remoteVideo?.addEventListener("click", () => remoteVideo.play().catch(() => {}));
  room.querySelector("[data-end-call]")?.addEventListener("click", () => endCall("USER_ENDED"));

  window.addEventListener("online", () => {
    if (pc?.connectionState !== "connected") scheduleIceRestart("network restored");
    poll();
  });

  window.addEventListener("pagehide", () => {
    if (ended) return;
    clearInterval(pollTimer);
    clearInterval(heartbeatTimer);
    clearTimeout(restartTimer);
    clearCheckingWatchdog();
  });

  // Update the visible duration locally once the consultation is LIVE.
  window.setInterval(() => {
    if (!durationEl || !startedAtMs || ended) return;
    const seconds = Math.max(0, Math.floor((Date.now() - startedAtMs) / 1000));
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    durationEl.textContent = h > 0
      ? `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`
      : `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }, 1000);

  (async () => {
    setStatus("PREPARING SECURE CONSULTATION", "warning");
    await roomHeartbeat();
    await poll();
    heartbeatTimer = window.setInterval(roomHeartbeat, 5000);
    pollTimer = window.setInterval(poll, 700);
  })();
})();
