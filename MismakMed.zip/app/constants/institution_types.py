class InstitutionType:
    NORMAL = "Normal"
    OPTIC_EYE_CENTER = "Optic Eye Center"
    PHARMACY = "Pharmacy"
    HOSPITAL = "Hospital"
    EYE_CARE = "Eye Care"
    HEARING_CARE = "Hearing Care"
    LABORATORY = "Laboratory"
    OTHER = "Other"

    ALL = [
        NORMAL,
        OPTIC_EYE_CENTER,
        PHARMACY,
        HOSPITAL,
        EYE_CARE,
        HEARING_CARE,
        LABORATORY,
        OTHER,
    ]
