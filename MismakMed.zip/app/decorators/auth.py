from functools import wraps

from flask import abort

from flask_login import (
    current_user,
    login_required as flask_login_required
)


# ============================================================
# LOGIN REQUIRED
# ============================================================

def login_required(view):

    @wraps(view)
    @flask_login_required
    def wrapped(*args, **kwargs):

        return view(
            *args,
            **kwargs
        )

    return wrapped


# ============================================================
# ROLE HELPER
# ============================================================

def get_role_name(user=None):

    if user is None:
        user = current_user

    if not user or not user.is_authenticated:
        return None

    # Existing role_name property
    value = getattr(
        user,
        "role_name",
        None
    )

    if callable(value):
        value = value()

    if value:
        return str(
            value
        ).strip().lower()

    # Existing role relationship
    role = getattr(
        user,
        "role",
        None
    )

    if role:

        name = getattr(
            role,
            "name",
            None
        )

        if name:
            return str(
                name
            ).strip().lower()

    # Administrator fallback
    if getattr(
        user,
        "is_admin",
        False
    ):
        return "administrator"

    return None


# ============================================================
# ROLE CHECK
# ============================================================

def has_role(*roles):

    if not current_user.is_authenticated:
        return False

    current_role = get_role_name()

    if not current_role:
        return False

    allowed_roles = {
        str(role).strip().lower()
        for role in roles
    }

    return current_role in allowed_roles


# ============================================================
# GENERIC ROLE REQUIRED
# ============================================================

def roles_required(*roles):

    def decorator(view):

        @wraps(view)
        def wrapped(*args, **kwargs):

            if not current_user.is_authenticated:
                abort(401)

            if not has_role(*roles):
                abort(403)

            return view(
                *args,
                **kwargs
            )

        return wrapped

    return decorator


# ============================================================
# ADMIN
# ============================================================

def admin_required(view):

    @wraps(view)
    @flask_login_required
    def wrapped(*args, **kwargs):

        if not (
            getattr(
                current_user,
                "is_admin",
                False
            )
            or has_role(
                "administrator",
                "admin"
            )
        ):

            abort(403)

        return view(
            *args,
            **kwargs
        )

    return wrapped




# ============================================================
# EMPLOYEE
# ============================================================

def employee_required(view):

    return roles_required(
        "employee"
    )(view)


# ============================================================
# MEDICAL OFFICER
# ============================================================

def medical_officer_required(view):

    return roles_required(
        "medical officer",
        "medical_officer",
        "medical-officer"
    )(view)


# ============================================================
# HR
# ============================================================

def hr_required(view):

    return roles_required(
        "hr",
        "human resources",
        "human_resource"
    )(view)


# ============================================================
# MEDICAL OFFICER OR ADMIN
# ============================================================

def medical_or_admin_required(view):

    return roles_required(
        "medical officer",
        "medical_officer",
        "medical-officer",
        "administrator",
        "admin"
    )(view)


# ============================================================
# HR OR ADMIN
# ============================================================

def hr_or_admin_required(view):

    return roles_required(
        "hr",
        "human resources",
        "human_resource",
        "administrator",
        "admin"
    )(view)


# ============================================================
# ANY AUTHENTICATED USER
# ============================================================

def authenticated_required(view):

    @wraps(view)
    @flask_login_required
    def wrapped(*args, **kwargs):

        return view(
            *args,
            **kwargs
        )

    return wrapped