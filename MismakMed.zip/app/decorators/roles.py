from functools import wraps

from flask import abort

from flask_login import current_user


def role_name(user):
    """
    Returns the current user's role name.
    Supports the existing User model/property structure.
    """

    if not user or not user.is_authenticated:
        return None

    # Existing role_name property
    value = getattr(user, "role_name", None)

    if callable(value):
        value = value()

    if value:
        return str(value).strip().lower()

    # Existing relationship: user.role
    role = getattr(user, "role", None)

    if role:
        value = getattr(role, "name", None)

        if value:
            return str(value).strip().lower()

    # Fallback for administrator
    if getattr(user, "is_admin", False):
        return "administrator"

    return None


def user_has_role(*allowed_roles):
    """
    Check whether current_user has one of the supplied roles.
    """

    if not current_user.is_authenticated:
        return False

    current_role = role_name(current_user)

    if not current_role:
        return False

    allowed = {
        str(role).strip().lower()
        for role in allowed_roles
    }

    return current_role in allowed


def roles_required(*allowed_roles):
    """
    Route decorator for one or more allowed roles.
    """

    def decorator(view):

        @wraps(view)
        def wrapped(*args, **kwargs):

            if not current_user.is_authenticated:
                abort(401)

            if not user_has_role(*allowed_roles):
                abort(403)

            return view(*args, **kwargs)

        return wrapped

    return decorator


def employee_required(view):
    return roles_required("employee")(view)


def medical_officer_required(view):
    return roles_required(
        "medical officer",
        "medical_officer",
        "medical-officer"
    )(view)


def hr_required(view):
    return roles_required(
        "hr",
        "human resources",
        "human_resource"
    )(view)


def administrator_required(view):
    return roles_required(
        "administrator",
        "admin"
    )(view)


def medical_or_admin_required(view):
    return roles_required(
        "medical officer",
        "medical_officer",
        "medical-officer",
        "administrator",
        "admin"
    )(view)


def hr_or_admin_required(view):
    return roles_required(
        "hr",
        "human resources",
        "human_resource",
        "administrator",
        "admin"
    )(view)