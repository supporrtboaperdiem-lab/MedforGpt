from csv import writer
from io import StringIO

from flask import Blueprint, Response, jsonify, render_template, request
from flask_login import current_user

from app.decorators.auth import login_required
from app.extensions import db
from app.models.claim import MedicalClaim, MedicalClaimItem, MedicalClaimReceipt
from app.models.employee import Employee
from app.models.institution import Institution
from app.services.authorization_service import AuthorizationService
from app.services.claim_automation_service import ClaimAutomationService

reports_bp = Blueprint("reports", __name__, url_prefix="/reports")


def _allowed():
    return (
        AuthorizationService.is_administrator(current_user)
        or AuthorizationService.is_hr(current_user)
        or AuthorizationService.is_medical_officer(current_user)
        or AuthorizationService.is_employee(current_user)
    )


def _query():
    # Repair legacy beneficiary labels before applying filters, otherwise a
    # spouse claim incorrectly stored as EMPLOYEE could disappear from reports.
    from app.services.claim_service import ClaimService
    ClaimService._repair_spouse_labels(MedicalClaim.query.all())
    query = MedicalClaim.query
    if AuthorizationService.is_employee(current_user):
        query = query.filter(MedicalClaim.submitted_by_id == current_user.id)

    category = request.args.get("category", "").strip().upper()
    status = request.args.get("status", "").strip().upper()
    beneficiary = request.args.get("beneficiary", "").strip().upper()
    institution_id = request.args.get("institution_id", "").strip()
    employee_id = request.args.get("employee_id", "").strip()
    department = request.args.get("department", "").strip()
    date_from = request.args.get("date_from", "").strip()
    date_to = request.args.get("date_to", "").strip()

    if category in {"NORMAL", "OPTICS", "PHARMACY"}:
        query = query.filter(MedicalClaim.category == category)
    if status:
        query = query.filter(MedicalClaim.status == status)
    if beneficiary in {"EMPLOYEE", "SPOUSE"}:
        query = query.filter(MedicalClaim.beneficiary_type == beneficiary)
    if institution_id.isdigit():
        query = query.filter(MedicalClaim.institution_id == int(institution_id))
    if employee_id.isdigit():
        selected_employee_id = int(employee_id)
        employee_claim_match = db.or_(
            MedicalClaim.employee_id == selected_employee_id,
            db.session.query(MedicalClaimItem.id).filter(
                MedicalClaimItem.claim_id == MedicalClaim.id,
                MedicalClaimItem.employee_id == selected_employee_id,
            ).exists(),
        )
        query = query.filter(employee_claim_match)
    if department:
        employee_department_match = db.or_(
            db.session.query(Employee.id).filter(
                Employee.id == MedicalClaim.employee_id,
                db.func.lower(db.func.trim(Employee.department)) == department.lower(),
            ).exists(),
            db.session.query(MedicalClaimItem.id).join(Employee, Employee.id == MedicalClaimItem.employee_id).filter(
                MedicalClaimItem.claim_id == MedicalClaim.id,
                db.func.lower(db.func.trim(Employee.department)) == department.lower(),
            ).exists(),
        )
        query = query.filter(employee_department_match)
    # Report dates are based on the date printed on the receipt, not the
    # moment the user uploaded the claim. A claim is included when at least
    # one of its receipts falls inside the selected range.
    if date_from or date_to:
        receipt_date_query = db.session.query(MedicalClaimReceipt.id).filter(
            MedicalClaimReceipt.claim_id == MedicalClaim.id
        )
        if date_from:
            receipt_date_query = receipt_date_query.filter(db.func.date(MedicalClaimReceipt.receipt_date) >= date_from)
        if date_to:
            receipt_date_query = receipt_date_query.filter(db.func.date(MedicalClaimReceipt.receipt_date) <= date_to)
        query = query.filter(receipt_date_query.exists())

    return query.order_by(MedicalClaim.created_at.desc())


def _report_data(claims):
    claims = list(claims)
    items = [item for claim in claims for item in (claim.items or [])]
    approved_items = [item for claim in claims if claim.status == "APPROVED" for item in (claim.items or [])]
    # Financial totals are intentionally restricted to approved claims.
    receipt_total = sum(float(item.receipt_price or 0) for item in approved_items)
    reimbursable_total = sum(float(item.reimbursable_amount or 0) for item in approved_items)
    # The institution-facing reimbursable amount stays at 100%; for spouse
    # claims, show the 10% employee share as a separate report-only deduction.
    employee_deduction_total = sum(
        _employee_payroll_deduction(claim, item)[0]
        for claim in claims if claim.status == "APPROVED"
        for item in (claim.items or [])
    )
    approved_total = sum(float(item.approved_price or 0) for item in approved_items)

    by_category = {}
    by_status = {}
    by_beneficiary = {}
    by_institution = {}
    for claim in claims:
        by_category[claim.category] = by_category.get(claim.category, 0) + 1
        by_status[claim.status] = by_status.get(claim.status, 0) + 1
        by_beneficiary[claim.beneficiary_type] = by_beneficiary.get(claim.beneficiary_type, 0) + 1
        name = claim.institution.name if claim.institution else "Unknown"
        by_institution[name] = by_institution.get(name, 0) + 1

    return {
        "claims": claims,
        "total_claims": len(claims),
        "total_items": len(items),
        "receipt_total": receipt_total,
        "approved_total": approved_total,
        "reimbursable_total": reimbursable_total,
        "employee_deduction_total": employee_deduction_total,
        "by_category": sorted(by_category.items()),
        "by_status": sorted(by_status.items()),
        "by_beneficiary": sorted(by_beneficiary.items()),
        "by_institution": sorted(by_institution.items()),
    }


@reports_bp.route("/")
@login_required
def index():
    if not _allowed():
        return Response("Not authorized", status=403)
    if ClaimAutomationService.automatic_scoring_enabled() and ClaimAutomationService.automatic_approval_enabled():
        from app.services.claim_service import ClaimService
        ClaimService.auto_finalize_pending_normal_claims()
    claims = _query().all()
    data = _report_data(claims)
    institutions = Institution.query.order_by(Institution.name.asc()).all()
    departments = [
        row[0] for row in db.session.query(Employee.department)
        .filter(Employee.department.isnot(None))
        .filter(db.func.trim(Employee.department) != "")
        .distinct()
        .order_by(db.func.lower(Employee.department).asc())
        .all()
    ]
    selected_employee = Employee.query.get(int(request.args.get("employee_id"))) if request.args.get("employee_id", "").isdigit() else None
    return render_template(
        "reports/index.html",
        **data,
        institutions=institutions,
        departments=departments,
        selected_employee=selected_employee,
        selected_category=request.args.get("category", ""),
        selected_status=request.args.get("status", ""),
        selected_beneficiary=request.args.get("beneficiary", ""),
        selected_institution=request.args.get("institution_id", ""),
        selected_employee_id=request.args.get("employee_id", ""),
        selected_department=request.args.get("department", ""),
        selected_date_from=request.args.get("date_from", ""),
        selected_date_to=request.args.get("date_to", ""),
    )


@reports_bp.route("/employee-options")
@login_required
def employee_options():
    if not _allowed():
        return Response("Not authorized", status=403)
    q = request.args.get("q", "").strip()
    query = Employee.query
    if q:
        like = f"%{q.lower()}%"
        query = query.filter(db.or_(
            db.func.lower(Employee.full_name).like(like),
            db.func.lower(db.func.coalesce(Employee.employee_code, "")).like(like),
            db.func.lower(db.func.coalesce(Employee.employee_id, "")).like(like),
            db.func.lower(db.func.coalesce(Employee.employee_number, "")).like(like),
        ))
    rows = query.order_by(Employee.full_name.asc()).limit(20).all()
    payload = [{
        "id": row.id,
        "name": row.full_name,
        "code": row.employee_code or row.employee_number or row.employee_id or "",
        "employee_id": row.employee_id or "",
        "department": row.department or "",
    } for row in rows]
    return jsonify(payload)



def _employee_payroll_deduction(claim, item):
    """Employee-side deduction; never subtract this from institution reimbursement."""
    if not item or claim.status != "APPROVED":
        return 0.0, 0
    if claim.category == "PHARMACY" and item.validation_status == "EXCLUDED_100":
        return round(float(item.receipt_price or 0), 2), 100
    if claim.beneficiary_type == "SPOUSE":
        return round(float(item.reimbursable_amount or 0) * 0.10, 2), 10
    return 0.0, 0


def _institution_service_deduction(claim, item):
    """Only matched Normal services above the approved price are institution-side deductions."""
    if not item or claim.category != "NORMAL" or item.validation_status != "MATCHED":
        return 0.0
    return round(max(float(item.receipt_price or 0) - float(item.reimbursable_amount or 0), 0.0), 2)


def _spouse_deduction_rows():
    """Build one payroll-deduction row per item for directory-confirmed spouse claims."""
    from app.services.claim_service import ClaimService
    claims = ClaimService._repair_spouse_labels(MedicalClaim.query.all())
    if AuthorizationService.is_employee(current_user):
        claims = [claim for claim in claims if claim.submitted_by_id == current_user.id]

    status = request.args.get("status", "APPROVED").strip().upper()
    if status in {"APPROVED", "PENDING_REVIEW", "REJECTED"}:
        claims = [claim for claim in claims if claim.status == status]
    elif status != "ALL":
        claims = [claim for claim in claims if claim.status == "APPROVED"]

    category = request.args.get("category", "").strip().upper()
    if category in {"NORMAL", "OPTICS", "PHARMACY"}:
        claims = [claim for claim in claims if claim.category == category]
    institution_id = request.args.get("institution_id", "").strip()
    if institution_id.isdigit():
        claims = [claim for claim in claims if claim.institution_id == int(institution_id)]
    claim_id = request.args.get("claim_id", "").strip()
    if claim_id.isdigit():
        claims = [claim for claim in claims if claim.id == int(claim_id)]

    employee_query = request.args.get("employee_id", "").strip().casefold()
    employee_name_query = request.args.get("employee_name", "").strip().casefold()
    spouse_name_query = request.args.get("spouse_name", "").strip().casefold()
    service_query = request.args.get("service", "").strip().casefold()
    date_from = request.args.get("date_from", "").strip()
    date_to = request.args.get("date_to", "").strip()

    def _claim_receipt_dates(claim):
        return [r.receipt_date for r in (claim.receipts or []) if r.receipt_date]

    def _date_match(claim):
        if not date_from and not date_to:
            return True
        for receipt_date in _claim_receipt_dates(claim):
            receipt_day = receipt_date.strftime("%Y-%m-%d")
            if (not date_from or receipt_day >= date_from) and (not date_to or receipt_day <= date_to):
                return True
        return False

    filtered_claims = []
    for claim in claims:
        if claim.beneficiary_type != "SPOUSE":
            continue
        employee = claim.employee
        employee_code = ((getattr(employee, "employee_code", None) if employee else None)
                         or (getattr(employee, "employee_number", None) if employee else None)
                         or (getattr(employee, "employee_id", None) if employee else None) or "")
        employee_name = claim.employee_owner_name or (employee.full_name if employee else "") or ""
        spouse_name = claim.beneficiary_name or claim.patient_name or ""
        if employee_query and employee_query not in " ".join([employee_code, getattr(employee, "employee_number", "") or "", getattr(employee, "employee_id", "") or ""]).casefold():
            continue
        if employee_name_query and employee_name_query not in employee_name.casefold():
            continue
        if spouse_name_query and spouse_name_query not in spouse_name.casefold():
            continue
        if not _date_match(claim):
            continue
        matching_items = [item for item in (claim.items or []) if not service_query or service_query in (str(item.service_name or "") + " " + str(item.service_description or "")).casefold()]
        if service_query and not matching_items:
            continue
        filtered_claims.append((claim, employee, employee_code, employee_name, spouse_name, matching_items or [None]))

    rows = []
    for claim, employee, employee_code, employee_name, spouse_name, items in sorted(filtered_claims, key=lambda entry: entry[0].created_at, reverse=True):
        receipt_date = next((r.receipt_date for r in (claim.receipts or []) if r.receipt_date), None)
        for item in items:
            expense = float(item.receipt_price or 0) if item else 0.0
            institution_reimbursable = float(item.reimbursable_amount or 0) if item else 0.0
            deduction, deduction_percent = _employee_payroll_deduction(claim, item)
            rows.append({
                "employee_code": employee_code,
                "employee_name": employee_name,
                "spouse_name": spouse_name,
                "claim_id": claim.id,
                "receipt_date": (item.receipt.receipt_date if item and item.receipt and item.receipt.receipt_date else receipt_date),
                "eligible_expense": expense,
                "institution_reimbursable": institution_reimbursable,
                "coverage": 90,
                "deduction_percent": deduction_percent,
                "deduction": deduction,
                "institution_deduction": _institution_service_deduction(claim, item),
                "deduction_reason": "100% pharmacy exclusion" if item and claim.category == "PHARMACY" and item.validation_status == "EXCLUDED_100" else ("Spouse employee share" if deduction_percent == 10 else ""),
                "status": claim.status,
                "category": claim.category,
                "service": item.service_name if item else "",
                "institution": claim.institution.name if claim.institution else "",
            })
    return rows


@reports_bp.route("/spouse-deductions")
@login_required
def spouse_deductions():
    if not _allowed():
        return Response("Not authorized", status=403)
    rows = _spouse_deduction_rows()
    return render_template(
        "reports/spouse_deductions.html",
        rows=rows,
        total_deduction=sum(row["deduction"] for row in rows),
        selected_status=request.args.get("status", "APPROVED"),
        selected_date_from=request.args.get("date_from", ""),
        selected_date_to=request.args.get("date_to", ""),
        selected_category=request.args.get("category", ""),
        selected_institution=request.args.get("institution_id", ""),
        selected_employee_id=request.args.get("employee_id", ""),
        selected_employee_name=request.args.get("employee_name", ""),
        selected_spouse_name=request.args.get("spouse_name", ""),
        selected_claim_id=request.args.get("claim_id", ""),
        selected_service=request.args.get("service", ""),
        institutions=Institution.query.order_by(Institution.name.asc()).all(),
    )


@reports_bp.route("/spouse-deductions/export.csv")
@login_required
def export_spouse_deductions_csv():
    if not _allowed():
        return Response("Not authorized", status=403)
    rows = _spouse_deduction_rows()
    stream = StringIO()
    csv = writer(stream)
    # Mandatory identification columns are deliberately the first three.
    csv.writerow(["Employee Number/ID", "Employee Name", "Spouse Name", "Claim ID", "Receipt Date", "Eligible Expense ETB", "Institution Reimbursable ETB", "Spouse Coverage %", "Employee Deduction %", "Employee Deduction ETB", "Institution Service Deduction ETB", "Deduction Reason", "Service/Drug/Material", "Category", "Institution", "Claim Status"])
    for row in rows:
        csv.writerow([row["employee_code"], row["employee_name"], row["spouse_name"], row["claim_id"], row["receipt_date"].strftime("%Y-%m-%d") if row["receipt_date"] else "", f'{row["eligible_expense"]:.2f}', f'{row["institution_reimbursable"]:.2f}', row["coverage"], row["deduction_percent"], f'{row["deduction"]:.2f}', f'{row["institution_deduction"]:.2f}', row["deduction_reason"], row["service"], row["category"], row["institution"], row["status"]])
    return Response(stream.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=spouse_deduction_report.csv"})

@reports_bp.route("/export.csv")
@login_required
def export_csv():
    if not _allowed():
        return Response("Not authorized", status=403)

    claims = _query().all()
    stream = StringIO()
    csv = writer(stream)
    csv.writerow([
        "Employee Number/ID", "Claim ID", "Employee Record", "Beneficiary", "Beneficiary Tag",
        "Coverage %", "Employee Deduction %", "Employee Deduction ETB", "Institution Service Deduction ETB", "Category", "Patient", "Institution", "Status",
        "Service/Drug/Material", "Description", "Receipt Expense ETB",
        "Price List Approved ETB", "Difference ETB", "Institution Reimbursable ETB", "Receipt Date", "Uploaded By", "Created"
    ])
    for claim in claims:
        for item in (claim.items or [None]):
            # Show line-level values for all statuses; status remains explicit,
            # and report summary totals below remain approved-only.
            approved_reimbursable = float(item.reimbursable_amount or 0) if item else 0
            is_spouse = (claim.beneficiary_type or "EMPLOYEE") == "SPOUSE"
            employee = getattr(claim, "employee", None)
            employee_number_id = ((getattr(employee, "employee_code", None) or getattr(employee, "employee_number", None) or getattr(employee, "employee_id", None)) if employee else "") or ""
            csv.writerow([
                employee_number_id,
                claim.id,
                claim.employee_owner_name or "",
                claim.beneficiary_name or claim.patient_name or "",
                claim.beneficiary_type or "EMPLOYEE",
                claim.coverage_percentage or 100,
                _employee_payroll_deduction(claim, item)[1],
                _employee_payroll_deduction(claim, item)[0],
                _institution_service_deduction(claim, item),
                claim.category,
                claim.patient_name,
                claim.institution.name if claim.institution else "",
                claim.status,
                item.service_name if item else "",
                item.service_description if item else "",
                float(item.receipt_price or 0) if item else 0,
                float(item.approved_price or 0) if item and item.approved_price is not None else "",
                float(item.difference or 0) if item and item.difference is not None else "",
                approved_reimbursable,
                (item.receipt.receipt_date.strftime("%Y-%m-%d") if item and item.receipt and item.receipt.receipt_date else ((claim.receipts[0].receipt_date.strftime("%Y-%m-%d") if claim.receipts and claim.receipts[0].receipt_date else ""))),
                (claim.submitted_by.full_name if claim.submitted_by else ""),
                claim.created_at,
            ])

    return Response(
        stream.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=medical_claims_report.csv"},
    )
