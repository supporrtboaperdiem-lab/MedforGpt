from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import current_user

from app.decorators.auth import login_required
from app.services.authorization_service import AuthorizationService
from app.services.claim_service import ClaimService
from app.services.claim_automation_service import ClaimAutomationService


main_bp = Blueprint(
    "main",
    __name__
)


@main_bp.route("/", methods=["GET", "POST"])
@login_required
def index():
    """Role-aware home/dashboard.

    The dashboard uses the authenticated user's actual role from the
    database through AuthorizationService instead of relying on a
    session string or placeholder text.
    """

    role_name = AuthorizationService.role_name(current_user)

    if role_name == "administrator":
        display_role = "Administrator"
    elif AuthorizationService.is_hr(current_user):
        display_role = "HR"
    elif AuthorizationService.is_medical_officer(current_user):
        display_role = "Medical Officer"
    elif AuthorizationService.is_employee(current_user):
        display_role = "Employee"
    else:
        display_role = current_user.role_name or "Unknown"

    return render_template(
        "main/index.html",
        role_name=display_role,
        is_administrator=AuthorizationService.is_administrator(current_user),
        is_hr=AuthorizationService.is_hr(current_user),
        is_medical_officer=AuthorizationService.is_medical_officer(current_user),
        is_employee=AuthorizationService.is_employee(current_user),
        can_submit_normal_claim=(
            ClaimService.can_submit_normal_claim(current_user)
            if (
                AuthorizationService.is_hr(current_user)
                or AuthorizationService.is_medical_officer(current_user)
            )
            else False
        ),
        can_submit_price_list=AuthorizationService.can_submit_price_lists(current_user),
        can_review_price_lists=AuthorizationService.can_review_price_lists(current_user),
    )


@main_bp.route("/claim-automation", methods=["GET", "POST"])
@login_required
def claim_automation():
    """Administrator-controlled Normal/Optics claim automation settings."""
    if not AuthorizationService.is_administrator(current_user):
        flash("Only Administrators can change claim automation settings.", "error")
        return redirect(url_for("main.index"))

    if request.method == "POST":
        automatic_approval = request.form.get("automatic_approval", "no").strip().lower() == "yes"
        automatic_scoring = request.form.get("automatic_scoring", "no").strip().lower() == "yes"
        ClaimAutomationService.save_settings(automatic_approval, automatic_scoring)
        flash("Claim automation settings updated successfully.", "success")
        return redirect(url_for("main.claim_automation"))

    settings = ClaimAutomationService.get_settings()
    return render_template("main/claim_automation.html", settings=settings)
