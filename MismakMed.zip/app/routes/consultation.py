from datetime import datetime
import json

from flask import Blueprint, current_app, jsonify, redirect, render_template, request, session, url_for
from flask_login import current_user

from app.decorators.auth import login_required
from app.extensions import db
from app.models.medical_consultation import MedicalConsultation
from app.models.role import Role
from app.models.user import User
from app.services.consultation_service import (
    allowed_counterpart_roles,
    create_consultation,
    close_stale_live_consultations,
    end_consultation,
    get_user_consultation,
    is_online,
    list_counterparts,
    serialize,
    start_consultation,
    touch_presence,
)

consultation_bp = Blueprint("consultation", __name__, url_prefix="/consultation")


@consultation_bp.after_request
def consultation_security_headers(response):
    # Explicitly allow camera/microphone for this top-level application.
    # This does not bypass browser HTTPS requirements; it prevents a stricter
    # Permissions-Policy inherited from a proxy/browser from silently blocking
    # an otherwise valid WebRTC page.
    response.headers.setdefault("Permissions-Policy", "camera=(self), microphone=(self)")
    response.headers.setdefault("Cache-Control", "no-store")
    return response


def _can_consult(user):
    return bool(allowed_counterpart_roles(user))


def _json_error(message, status=400):
    return jsonify({"ok": False, "error": str(message)}), status


@consultation_bp.route("/")
@login_required
def index():
    if not _can_consult(current_user):
        return redirect(url_for("main.index"))
    touch_presence(current_user.id)
    return render_template("consultation/index.html")


@consultation_bp.route("/heartbeat", methods=["POST"])
@login_required
def heartbeat():
    if not _can_consult(current_user):
        return _json_error("Not eligible for medical consultation.", 403)
    touch_presence(current_user.id)
    return jsonify({"ok": True, "online": True, "server_time": datetime.utcnow().isoformat()})


@consultation_bp.route("/people")
@login_required
def people():
    if not _can_consult(current_user):
        return _json_error("Not eligible for medical consultation.", 403)
    touch_presence(current_user.id)
    close_stale_live_consultations()
    return jsonify({"ok": True, "people": list_counterparts(current_user)})


@consultation_bp.route("/request", methods=["POST"])
@login_required
def request_consultation():
    if not _can_consult(current_user):
        return _json_error("Not eligible for medical consultation.", 403)

    payload = request.get_json(silent=True) or {}
    receiver_id = payload.get("receiver_id")
    try:
        receiver_id = int(receiver_id)
    except (TypeError, ValueError):
        return _json_error("Invalid receiver.", 400)

    receiver = User.query.join(Role).filter(
        User.id == receiver_id,
        User.is_active.is_(True),
    ).first()

    if not receiver or receiver.id == current_user.id:
        return _json_error("Receiver is not available.", 404)

    receiver_role = (receiver.role_name or "").strip().lower()
    if receiver_role not in allowed_counterpart_roles(current_user):
        return _json_error("That user is not an eligible consultation participant.", 403)

    try:
        touch_presence(current_user.id)
        consultation, created = create_consultation(current_user, receiver)
        return jsonify({
            "ok": True,
            "created": created,
            "consultation": serialize(consultation, current_user),
            "receiver_online": is_online(receiver.id),
        })
    except ValueError as exc:
        db.session.rollback()
        return _json_error(str(exc), 409)
    except Exception as exc:
        db.session.rollback()
        # Return the actual safe server-side exception text instead of a
        # misleading generic browser "Request failed" message. Full details
        # remain in Flask's normal application log.
        print(f"[CONSULTATION][REQUEST][ERROR] {exc}", flush=True)
        return _json_error((f"Unable to create consultation request: {exc}" if current_app.debug else "Unable to create the consultation request. Check the application log for details."), 500)


@consultation_bp.route("/mine")
@login_required
def mine():
    if not _can_consult(current_user):
        return _json_error("Not eligible for medical consultation.", 403)
    touch_presence(current_user.id)
    close_stale_live_consultations()
    rows = (
        MedicalConsultation.query
        .filter(
            (MedicalConsultation.requester_id == current_user.id)
            | (MedicalConsultation.receiver_id == current_user.id),
            MedicalConsultation.status.in_(["PENDING", "ACCEPTED", "LIVE"]),
        )
        .order_by(MedicalConsultation.updated_at.desc())
        .limit(10)
        .all()
    )
    return jsonify({"ok": True, "consultations": [serialize(row, current_user) for row in rows]})


@consultation_bp.route("/history")
@login_required
def history():
    if not _can_consult(current_user):
        return _json_error("Not eligible for medical consultation.", 403)
    rows = (
        MedicalConsultation.query
        .filter(
            (MedicalConsultation.requester_id == current_user.id)
            | (MedicalConsultation.receiver_id == current_user.id),
            MedicalConsultation.status.in_(["ENDED", "DECLINED"]),
        )
        .order_by(MedicalConsultation.ended_at.desc(), MedicalConsultation.updated_at.desc())
        .limit(50)
        .all()
    )
    return jsonify({"ok": True, "consultations": [serialize(row, current_user) for row in rows]})


@consultation_bp.route("/<int:consultation_id>/accept", methods=["POST"])
@login_required
def accept(consultation_id):
    consultation = get_user_consultation(current_user, consultation_id)
    if not consultation or consultation.receiver_id != current_user.id:
        return _json_error("Not authorized.", 403)
    if consultation.status not in {"PENDING", "ACCEPTED"}:
        return _json_error("Consultation is no longer active.", 409)

    # Do not allow a medical officer/participant to accept two simultaneous calls.
    others = MedicalConsultation.query.filter(
        MedicalConsultation.id != consultation.id,
        ((MedicalConsultation.requester_id == current_user.id) | (MedicalConsultation.receiver_id == current_user.id)),
        MedicalConsultation.status.in_(["ACCEPTED", "LIVE"]),
    ).first()
    if others:
        return _json_error("You are already in another live consultation.", 409)

    now = datetime.utcnow()
    consultation.status = "ACCEPTED"
    consultation.accepted_at = consultation.accepted_at or now
    consultation.updated_at = now
    consultation.last_activity_at = now
    db.session.commit()
    touch_presence(current_user.id)
    return jsonify({"ok": True, "consultation": serialize(consultation, current_user)})


@consultation_bp.route("/<int:consultation_id>/decline", methods=["POST"])
@login_required
def decline(consultation_id):
    consultation = get_user_consultation(current_user, consultation_id)
    if not consultation:
        return _json_error("Not authorized.", 403)
    if consultation.status not in {"PENDING", "ACCEPTED"}:
        return _json_error("Consultation is no longer active.", 409)

    # A pending request may be declined by the receiver. An accepted call may
    # be ended by either participant through /end, not by this endpoint.
    if consultation.status == "PENDING" and consultation.receiver_id != current_user.id:
        return _json_error("Only the receiving participant can decline a pending request.", 403)

    consultation.status = "DECLINED"
    consultation.ended_at = datetime.utcnow()
    consultation.ended_by_id = current_user.id
    consultation.end_reason = "DECLINED"
    consultation.updated_at = datetime.utcnow()
    consultation.last_activity_at = datetime.utcnow()
    db.session.commit()
    return jsonify({"ok": True})


@consultation_bp.route("/<int:consultation_id>/start", methods=["POST"])
@login_required
def start(consultation_id):
    consultation = get_user_consultation(current_user, consultation_id)
    if not consultation:
        return _json_error("Not authorized.", 403)
    try:
        consultation = start_consultation(consultation, current_user)
        touch_presence(current_user.id)
        return jsonify({"ok": True, "consultation": serialize(consultation, current_user)})
    except PermissionError as exc:
        return _json_error(str(exc), 403)
    except ValueError as exc:
        return _json_error(str(exc), 409)


@consultation_bp.route("/<int:consultation_id>/end", methods=["POST"])
@login_required
def end(consultation_id):
    consultation = get_user_consultation(current_user, consultation_id)
    if not consultation:
        return _json_error("Not authorized.", 403)
    payload = request.get_json(silent=True) or {}
    reason = str(payload.get("reason") or "ENDED")[:100]
    try:
        consultation = end_consultation(consultation, current_user, reason)
        return jsonify({"ok": True, "consultation": serialize(consultation, current_user)})
    except PermissionError as exc:
        return _json_error(str(exc), 403)


@consultation_bp.route("/ice-config")
@login_required
def ice_config():
    """Return the server-side WebRTC ICE configuration.

    TURN credentials are never embedded in the page source. If no TURN
    server is configured, the browser receives the STUN-only configuration.
    """
    stun_urls = [
        value.strip()
        for value in str(current_app.config.get("WEBRTC_STUN_URLS", "")).split(",")
        if value.strip()
    ]
    turn_urls = [
        value.strip()
        for value in str(current_app.config.get("WEBRTC_TURN_URLS", "")).split(",")
        if value.strip()
    ]

    servers = [{"urls": url} for url in stun_urls]
    username = str(current_app.config.get("WEBRTC_TURN_USERNAME", "") or "").strip()
    credential = str(current_app.config.get("WEBRTC_TURN_CREDENTIAL", "") or "").strip()
    if turn_urls and username and credential:
        servers.append({
            "urls": turn_urls,
            "username": username,
            "credential": credential,
        })

    return jsonify({"ok": True, "ice_servers": servers})


@consultation_bp.route("/<int:consultation_id>/signal", methods=["POST"])
@login_required
def signal(consultation_id):
    consultation = get_user_consultation(current_user, consultation_id)
    if not consultation:
        return _json_error("Not authorized.", 403)
    if consultation.status not in {"ACCEPTED", "LIVE"}:
        return _json_error("Consultation is not ready for signaling.", 409)

    payload = request.get_json(silent=True) or {}
    kind = payload.get("kind")
    value = payload.get("value")

    if kind == "offer" and consultation.requester_id == current_user.id:
        consultation.offer = json.dumps(value) if not isinstance(value, str) else value
    elif kind == "answer" and consultation.receiver_id == current_user.id:
        consultation.answer = json.dumps(value) if not isinstance(value, str) else value
    elif kind == "candidate":
        target = "requester_candidates" if consultation.receiver_id == current_user.id else "receiver_candidates"
        existing = json.loads(getattr(consultation, target) or "[]")
        existing.append(value)
        setattr(consultation, target, json.dumps(existing))
    else:
        return _json_error("Invalid signaling operation.", 400)

    consultation.updated_at = datetime.utcnow()
    consultation.last_activity_at = datetime.utcnow()
    db.session.commit()
    touch_presence(current_user.id)
    return jsonify({"ok": True})


@consultation_bp.route("/<int:consultation_id>/state")
@login_required
def state(consultation_id):
    consultation = get_user_consultation(current_user, consultation_id)
    if not consultation:
        return _json_error("Not authorized.", 403)

    # The consultation room polls this endpoint continuously. Keep both the
    # user's presence and the consultation's activity timestamp alive so a
    # healthy LIVE call is never incorrectly closed by the stale-session
    # cleanup while media is flowing.
    now = datetime.utcnow()
    touch_presence(current_user.id)
    if consultation.status in {"ACCEPTED", "LIVE"}:
        consultation.last_activity_at = now
        consultation.updated_at = now
        db.session.commit()

    return jsonify({"ok": True, "consultation": serialize(consultation, current_user)})


@consultation_bp.route("/<int:consultation_id>/heartbeat", methods=["POST"])
@login_required
def consultation_heartbeat(consultation_id):
    consultation = get_user_consultation(current_user, consultation_id)
    if not consultation:
        return _json_error("Not authorized.", 403)
    if consultation.status not in {"ACCEPTED", "LIVE"}:
        return _json_error("Consultation is no longer active.", 409)

    now = datetime.utcnow()
    consultation.last_activity_at = now
    consultation.updated_at = now
    db.session.commit()
    touch_presence(current_user.id)
    return jsonify({"ok": True, "server_time": now.isoformat(), "status": consultation.status})


@consultation_bp.route("/<token>/join")
def join(token):
    consultation = MedicalConsultation.query.filter_by(token=token).first_or_404()
    if not current_user.is_authenticated:
        session["consultation_after_login"] = url_for("consultation.join", token=token)
        return redirect(url_for("auth.login"))
    if current_user.id not in {consultation.requester_id, consultation.receiver_id}:
        return render_template("consultation/forbidden.html"), 403

    # Clicking the secure email link is the receiver's acceptance action.
    if consultation.receiver_id == current_user.id and consultation.status == "PENDING":
        now = datetime.utcnow()
        consultation.status = "ACCEPTED"
        consultation.accepted_at = now
        consultation.updated_at = now
        consultation.last_activity_at = now
        db.session.commit()

    touch_presence(current_user.id)
    return render_template(
        "consultation/room.html",
        consultation=consultation,
        is_requester=consultation.requester_id == current_user.id,
    )
