from flask import Blueprint, current_app, flash, redirect, render_template, request, url_for
from flask_login import current_user
from app.services.authorization_service import AuthorizationService
from app.services.employee_directory_service import EmployeeDirectoryService
from app.decorators.auth import login_required
from werkzeug.utils import secure_filename
from pathlib import Path

from app.services.employee_service import EmployeeService

employee_bp = Blueprint(
    "employee",
    __name__,
    url_prefix="/employees"
)


@employee_bp.route("/")
def index():
    employees = EmployeeService.list_employees()
    return render_template("employee/index.html", employees=employees)


@employee_bp.route("/create", methods=["GET", "POST"])
def create():
    if request.method == "POST":
        success, message = EmployeeService.create_employee(request.form)

        if success:
            flash(message, "success")
            return redirect(url_for("employee.index"))

        flash(message, "error")

    return render_template("employee/create.html")

@employee_bp.route("/import", methods=["GET", "POST"])
@login_required
def import_directory():
    if not (AuthorizationService.is_hr(current_user) or getattr(current_user, "is_admin", False)):
        flash("Only HR or an administrator can import the employee directory.", "error")
        return redirect(url_for("employee.index"))
    if request.method == "POST":
        uploaded = request.files.get("employee_file")
        if not uploaded or not uploaded.filename:
            flash("Employee Excel file is required.", "error")
            return redirect(url_for("employee.import_directory"))
        if Path(uploaded.filename).suffix.lower() != ".xlsx":
            flash("Only .xlsx employee directory files are supported.", "error")
            return redirect(url_for("employee.import_directory"))
        folder = Path(current_app.config["UPLOAD_FOLDER"]) / "employee_directory"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / secure_filename(uploaded.filename)
        uploaded.save(path)
        try:
            result = EmployeeDirectoryService.import_excel(path)
            flash(f"Employee directory imported: {result['imported']} new, {result['updated']} updated, {result['skipped']} skipped.", "success")
        except Exception as exc:
            flash(f"Employee directory import failed: {exc}", "error")
        return redirect(url_for("employee.index"))
    return render_template("employee/import.html")

@employee_bp.route("/spouses", methods=["GET", "POST"])
@login_required
def spouse_directory():
    if not (AuthorizationService.is_hr(current_user) or getattr(current_user, "is_admin", False)):
        flash("Only HR or an administrator can manage the spouse directory.", "error")
        return redirect(url_for("employee.index"))
    from app.services.spouse_directory_service import SpouseDirectoryService
    if request.method == "POST":
        uploaded = request.files.get("spouse_file")
        if not uploaded or not uploaded.filename:
            flash("Spouse Excel file is required.", "error")
            return redirect(url_for("employee.spouse_directory"))
        if Path(uploaded.filename).suffix.lower() != ".xlsx":
            flash("Only .xlsx spouse directory files are supported.", "error")
            return redirect(url_for("employee.spouse_directory"))
        folder = Path(current_app.config["UPLOAD_FOLDER"]) / "spouse_directory"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / secure_filename(uploaded.filename)
        uploaded.save(path)
        try:
            result = SpouseDirectoryService.import_excel(path)
            flash(f"Spouse directory imported: {result['imported']} new, {result['updated']} updated, {result['skipped']} skipped.", "success")
        except Exception as exc:
            flash(f"Spouse directory import failed: {exc}", "error")
        return redirect(url_for("employee.spouse_directory"))
    rows = SpouseDirectoryService.list_all()
    return render_template("employee/spouse_directory.html", spouses=rows)
