from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import current_user
from app.decorators.auth import login_required
from app.services.authorization_service import AuthorizationService
from app.services.pharmacy_exclusion_service import load_manual_rules, save_manual_rules, excluded_names, is_excluded
from app.extensions import db
from app.models.claim import MedicalClaim

pharmacy_exclusions_bp = Blueprint("pharmacy_exclusions", __name__, url_prefix="/pharmacy-exclusions")

@pharmacy_exclusions_bp.route("/", methods=["GET", "POST"])
@login_required
def manage():
    if not (AuthorizationService.is_hr(current_user) or AuthorizationService.is_administrator(current_user)):
        flash("Only HR or an administrator can change pharmacy exclusion rules.", "error")
        return redirect(url_for("main.index"))
    if request.method == "POST":
        rules = {key: request.form.get(key, "").splitlines() for key in ("allow_names", "exclude_names", "exclude_brands", "exclude_categories")}
        save_manual_rules(rules)
        # Re-evaluate existing pharmacy lines so HR's changes also affect already
        # recorded deduction labels, including approved claims.
        changed = 0
        claims = MedicalClaim.query.filter_by(category="PHARMACY").all()
        for claim in claims:
            for item in (claim.items or []):
                excluded, _matched = is_excluded(item.service_name, item.service_description)
                new_status = "EXCLUDED_100" if excluded else "NOT_APPLICABLE"
                if item.validation_status != new_status:
                    item.validation_status = new_status
                    changed += 1
        db.session.commit()
        flash(f"Rules saved. Rechecked {changed} existing pharmacy line(s); affected deduction labels are now refreshed.", "success")
        return redirect(url_for("pharmacy_exclusions.manage"))
    return render_template("pharmacy_exclusions/manage.html", rules=load_manual_rules(), spreadsheet_names=excluded_names())
