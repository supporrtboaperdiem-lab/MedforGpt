from flask import Blueprint, current_app, flash, redirect, render_template, request, url_for
from flask_login import current_user
from app.extensions import db

from app.services.price_list_service import PriceListService
from app.services.authorization_service import AuthorizationService
from app.decorators.auth import login_required

price_list_bp = Blueprint(
    "price_list",
    __name__,
    url_prefix="/price-list"
)


@price_list_bp.route("/")
@login_required
def index():
    # HR/Administrator can review all price lists. Medical Officers can
    # submit price lists but must not review or approve them.
    if AuthorizationService.can_review_price_lists(current_user):
        batches = PriceListService.list_batches()
    elif AuthorizationService.is_medical_officer(current_user):
        batches = [
            batch for batch in PriceListService.list_batches()
            if batch.created_by_id == current_user.id
        ]
    else:
        batches = []

    return render_template(
        "price_list/index.html",
        batches=batches,
        can_submit_price_list=AuthorizationService.can_submit_price_lists(current_user),
        can_review_price_lists=AuthorizationService.can_review_price_lists(current_user),
        is_medical_officer=AuthorizationService.is_medical_officer(current_user),
    )



@price_list_bp.route("/institution/add", methods=["GET", "POST"])
@login_required
def add_institution():
    if not AuthorizationService.can_submit_price_lists(current_user):
        flash("You are not authorized to add institutions.", "error")
        return redirect(url_for("price_list.index"))
    from app.models.institution import Institution
    from app.constants.institution_types import InstitutionType
    allowed_types = [InstitutionType.NORMAL, InstitutionType.OPTIC_EYE_CENTER, InstitutionType.PHARMACY]
    if request.method == "POST":
        name = (request.form.get("name") or "").strip()
        institution_type = (request.form.get("institution_type") or "").strip()
        if not name:
            flash("Institution name is required.", "error")
        elif institution_type not in allowed_types:
            flash("Please select a valid institution type.", "error")
        elif Institution.query.filter(Institution.name.ilike(name)).first():
            flash("An institution with this name already exists.", "error")
        else:
            institution = Institution(name=name, institution_type=institution_type, is_active=True)
            db.session.add(institution)
            db.session.commit()
            flash(f"Institution '{name}' added successfully.", "success")
            return redirect(url_for("price_list.upload"))
    return render_template("price_list/add_institution.html", institution_types=allowed_types)

@price_list_bp.route("/upload", methods=["GET", "POST"])
@login_required
def upload():
    if not AuthorizationService.can_submit_price_lists(current_user):
        flash("You are not authorized to submit price lists.", "error")
        return redirect(url_for("main.index"))

    institutions = PriceListService.list_institutions()

    if request.method == "POST":
        success, message, batch_id = PriceListService.upload_price_list(
            form_data=request.form,
            file=request.files.get("price_list_file"),
            upload_folder=current_app.config["UPLOAD_FOLDER"],
            current_user=current_user,
        )

        flash(message, "success" if success else "error")

        if success:
            # HR may immediately review its submission. Medical Officers
            # submit only; HR remains the approver/reviewer.
            if AuthorizationService.can_review_price_lists(current_user):
                return redirect(url_for("price_list.review", batch_id=batch_id))
            return redirect(url_for("price_list.index"))

    return render_template(
        "price_list/upload.html",
        institutions=institutions
    )


@price_list_bp.route("/<int:batch_id>/review")
@login_required
def review(batch_id):
    if not AuthorizationService.can_review_price_lists(current_user):
        flash("Only HR can review and approve price lists.", "error")
        return redirect(url_for("price_list.index"))

    batch = PriceListService.get_batch(batch_id)

    if not batch:
        flash("Price list batch not found.", "error")
        return redirect(url_for("price_list.index"))

    items = PriceListService.get_batch_items(batch_id)

    return render_template(
        "price_list/review.html",
        batch=batch,
        items=items
    )


@price_list_bp.route("/item/<int:item_id>/edit", methods=["GET", "POST"])
@login_required
def edit_item(item_id):
    if not AuthorizationService.can_review_price_lists(current_user):
        flash("Only HR can edit price-list items during review.", "error")
        return redirect(url_for("price_list.index"))

    item = PriceListService.get_item(item_id)

    if not item:
        flash("Price list item not found.", "error")
        return redirect(url_for("price_list.index"))

    if request.method == "POST":
        success, message = PriceListService.update_item(
            item_id,
            request.form
        )

        flash(message, "success" if success else "error")

        return redirect(url_for(
            "price_list.review",
            batch_id=item.batch_id
        ))

    return render_template(
        "price_list/edit.html",
        item=item
    )


@price_list_bp.route("/item/<int:item_id>/delete", methods=["POST"])
@login_required
def delete_item(item_id):
    if not AuthorizationService.can_review_price_lists(current_user):
        flash("Only HR can delete price-list items during review.", "error")
        return redirect(url_for("price_list.index"))

    success, message, batch_id = PriceListService.delete_item(item_id)

    flash(message, "success" if success else "error")

    return redirect(url_for(
        "price_list.review",
        batch_id=batch_id
    ))


@price_list_bp.route("/<int:batch_id>/approve", methods=["POST"])
@login_required
def approve_batch(batch_id):
    if not AuthorizationService.can_review_price_lists(current_user):
        flash("Only HR can approve price lists.", "error")
        return redirect(url_for("price_list.index"))

    success, message = PriceListService.approve_batch(
        batch_id,
        current_user=current_user,
    )

    flash(message, "success" if success else "error")

    return redirect(url_for(
        "price_list.review",
        batch_id=batch_id
    ))


@price_list_bp.route("/<int:batch_id>/reject", methods=["POST"])
@login_required
def reject_batch(batch_id):
    if not AuthorizationService.can_review_price_lists(current_user):
        flash("Only HR can reject price lists.", "error")
        return redirect(url_for("price_list.index"))

    success, message = PriceListService.reject_batch(
        batch_id,
        current_user=current_user,
    )

    flash(message, "success" if success else "error")

    return redirect(url_for("price_list.index"))

@price_list_bp.route("/<int:batch_id>/add-item", methods=["GET", "POST"])
@login_required
def add_item(batch_id):
    if not AuthorizationService.can_review_price_lists(current_user):
        flash("Only HR can add price-list items during review.", "error")
        return redirect(url_for("price_list.index"))

    batch = PriceListService.get_batch(batch_id)

    if not batch:
        flash("Price list batch not found.", "error")
        return redirect(url_for("price_list.index"))

    if request.method == "POST":
        success, message = PriceListService.add_item_to_batch(
            batch_id,
            request.form
        )

        flash(message, "success" if success else "error")

        return redirect(url_for(
            "price_list.review",
            batch_id=batch_id
        ))

    return render_template(
        "price_list/add_item.html",
        batch=batch
    )