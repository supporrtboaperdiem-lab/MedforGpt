import json
import os

from flask import (
    Blueprint,
    current_app,
    flash,
    redirect,
    render_template,
    request,
    send_file,
    url_for
)

from flask_login import current_user

from app.services.authorization_service import (
    AuthorizationService
)
from app.services.claim_service import ClaimService, ClaimResolutionRequired
from app.decorators.auth import login_required
from app.services.claim_item_information_service import get_item_information
from app.services.claim_automation_service import ClaimAutomationService
from app.services.spouse_directory_service import SpouseDirectoryService


claim_bp = Blueprint(
    "claim",
    __name__,
    url_prefix="/claims"
)


@claim_bp.route("/")
@login_required
def index():

    # Bring legacy Normal claims into the current automatic scoring/approval
    # rules before the review menu is built.
    if ClaimAutomationService.automatic_scoring_enabled() and ClaimAutomationService.automatic_approval_enabled():
        ClaimService.auto_finalize_pending_normal_claims()

    # Optional search makes newly submitted requests immediately discoverable
    # by claim ID, employee, beneficiary, institution, or status.
    search = (request.args.get("q") or "").strip()

    # ========================================================
    # EMPLOYEE
    #
    # Employees see ONLY claims submitted by themselves.
    # ========================================================

    if AuthorizationService.is_employee(
        current_user
    ):

        claims = (
            ClaimService.list_claims_by_user(
                current_user.id
            )
        )

        can_submit = True

    elif AuthorizationService.is_medical_officer(current_user):

        # Medical Officers see ONLY claims submitted by themselves.
        claims = ClaimService.list_claims_by_user(current_user.id)
        can_submit = ClaimService.can_submit_normal_claim(current_user)

    else:

        # HR / Administrator retain all-claims visibility.
        claims = ClaimService.list_claims()

        if AuthorizationService.is_hr(current_user):
            can_submit = ClaimService.can_submit_normal_claim(current_user)
        else:
            can_submit = bool(
                ClaimService.allowed_categories_for_user(
                    current_user
                )
            )


    # HR must always be able to see claims that still require human action.
    # Auto Approval only removes successfully eligible Normal/Optics claims
    # from the review queue; it must never hide unresolved Normal claims or
    # Pharmacy claims, which always require review.
    if AuthorizationService.is_hr(current_user):
        claims = [
            claim for claim in claims
            if claim.status == "PENDING_REVIEW" or claim.status == "REJECTED" or claim.status == "APPROVED"
        ]

    if AuthorizationService.is_hr(current_user):
        from decimal import Decimal
        def _claim_has_deduction(claim):
            if claim.category != ClaimService.NORMAL:
                return False
            coverage = Decimal("1")
            return any(
                getattr(item, "validation_status", "") == "MATCHED" and
                Decimal(str(getattr(item, "receipt_price", 0) or 0)) * coverage - Decimal(str(getattr(item, "reimbursable_amount", 0) or 0)) > Decimal("0.004")
                for item in (claim.items or [])
            )
        claims.sort(key=lambda claim: (not _claim_has_deduction(claim), -(claim.id or 0)))

    if search:
        needle = search.casefold()
        def matches(claim):
            employee_names = [
                getattr(claim, "employee_owner_name", "") or "",
                getattr(claim, "patient_name", "") or "",
                getattr(claim, "beneficiary_name", "") or "",
            ]
            employee_names.extend(
                (getattr(item.employee, "full_name", "") or "")
                for item in (getattr(claim, "items", []) or [])
                if getattr(item, "employee", None)
            )
            institution_name = getattr(getattr(claim, "institution", None), "name", "") or ""
            haystack = " ".join([
                str(getattr(claim, "id", "")),
                getattr(claim, "category", "") or "",
                getattr(claim, "status", "") or "",
                institution_name,
                *employee_names,
            ]).casefold()
            return needle in haystack
        claims = [claim for claim in claims if matches(claim)]

    return render_template(
        "claim/index.html",

        claims=claims,
        search=search,

        can_submit=can_submit,

        is_hr=AuthorizationService.is_hr(
            current_user
        ),

        is_employee=AuthorizationService.is_employee(
            current_user
        ),

        is_medical_officer=(
            AuthorizationService.is_medical_officer(
                current_user
            )
        ),
        is_administrator=AuthorizationService.is_administrator(current_user),
    )


@claim_bp.route("/submit", methods=["GET", "POST"])
@login_required
def submit():
    allowed_categories = (
        ClaimService.allowed_categories_for_user(
            current_user
        )
    )

    if not allowed_categories:
        flash(
            "You are not authorized to submit claims.",
            "error"
        )
        return redirect(
            url_for("claim.index")
        )

    selected_category = (
        request.form.get(
            "claim_category",
            ""
        ).strip().upper()
        if request.method == "POST"
        else ""
    )

    if request.method == "POST":
        current_app.logger.info("[CLAIM][ROUTE] SUBMIT_POST user_id=%s form=%r file_count=%d", getattr(current_user, "id", None), dict(request.form), len(request.files.getlist("receipt_files")))
        print(f"[CLAIM][ROUTE] SUBMIT_POST user_id={getattr(current_user, 'id', None)} form={dict(request.form)!r} file_count={len(request.files.getlist('receipt_files'))}", flush=True)
        try:
            # Submission-screen controls are the per-submission source of truth.
            # They are persisted so the same automation behavior is used by
            # legacy revalidation and subsequent submissions. Both default ON.
            if (
                selected_category in {ClaimService.NORMAL, ClaimService.OPTICS, ClaimService.PHARMACY}
                and (AuthorizationService.is_hr(current_user)
                     or AuthorizationService.is_medical_officer(current_user)
                     or AuthorizationService.is_administrator(current_user))
            ):
                auto_approval = (request.form.get("automatic_approval") or "yes").strip().lower() == "yes"
                auto_scoring = (request.form.get("automatic_scoring") or "yes").strip().lower() == "yes"
                ClaimAutomationService.save_settings(auto_approval, auto_scoring)

            success, message, claim_id = ClaimService.submit_claim(
                form_data=request.form,
                files=request.files.getlist("receipt_files"),
                upload_folder=current_app.config["UPLOAD_FOLDER"],
                current_user=current_user
            )
        except ClaimResolutionRequired as exc:
            current_app.logger.warning("[CLAIM][ROUTE] SUBMIT_NEEDS_RESOLUTION token=%s details=%r", exc.token, exc.details)
            print(f"[CLAIM][ROUTE] SUBMIT_NEEDS_RESOLUTION token={exc.token} details={exc.details!r}", flush=True)
            # IMPORTANT: the resolver is a separate POST endpoint. Rendering the
            # resolver template directly from /claims/submit leaves the browser's
            # current URL as /claims/submit, so the resolver form posts back to
            # the normal submit handler without claim_category/files. That was
            # the reason the logs showed institution_id_0 with file_count=0 and
            # "Invalid claim category" and no claim was ever created.
            # Redirect to the tokenized resolver URL so the browser POSTs to
            # /claims/resolve/<token>. The pending JSON already preserves the
            # extracted receipts, AI data, category and unresolved matches.
            return redirect(url_for("claim.resolve", token=exc.token))

        current_app.logger.info("[CLAIM][ROUTE] SUBMIT_RESULT success=%s claim_id=%s message=%r", success, claim_id, message)
        print(f"[CLAIM][ROUTE] SUBMIT_RESULT success={success} claim_id={claim_id} message={message!r}", flush=True)
        # Duplicate/fraud rejections get a dedicated visible fraud alert rather
        # than being presented as an ordinary form error.
        flash_category = "success" if success else (
            "fraud" if str(message or "").startswith("Duplicate receipt rejected:")
            else "error"
        )
        flash(message, flash_category)
        if success and claim_id:
            # A multi-file submission can now create multiple claims: one per
            # matched employee. If several claim IDs were created, go to the
            # claims list so the user can see the complete batch. A single
            # claim still opens directly as before.
            if isinstance(claim_id, (list, tuple, set)):
                current_app.logger.info(
                    "[CLAIM][ROUTE] SUBMIT_BATCH_COMPLETE claim_ids=%s",
                    list(claim_id)
                )
                return redirect(url_for("claim.index"))
            if AuthorizationService.is_hr(current_user):
                return redirect(url_for("claim.review", claim_id=claim_id))
            if AuthorizationService.is_medical_officer(current_user):
                return redirect(url_for("claim.view", claim_id=claim_id))
            return redirect(url_for("claim.index"))

    return render_template(
        "claim/submit.html",
        allowed_categories=allowed_categories,
        selected_category=selected_category,
        is_employee=AuthorizationService.is_employee(current_user),
        spouse_names=[
            row.spouse_name
            for row in SpouseDirectoryService.find_for_employee(ClaimService._current_employee(current_user))
        ] if AuthorizationService.is_employee(current_user) and ClaimService._current_employee(current_user) else [],
        automation_settings=ClaimAutomationService.get_settings(),
    )

@claim_bp.route("/match-suggestions")
@login_required
def match_suggestions():
    """Live Google-style autocomplete for human receipt matching."""
    kind = (request.args.get("type") or "").strip().lower()
    q = (request.args.get("q") or "").strip()
    if kind == "institution":
        return {"results": ClaimService.search_institutions(q, 12)}
    if kind == "employee":
        from app.services.employee_directory_service import EmployeeDirectoryService
        return {"results": EmployeeDirectoryService.search_matches(q, 12)}
    return {"results": []}

@claim_bp.route("/resolve/<token>", methods=["GET", "POST"])
@login_required
def resolve(token):
    payload = ClaimService.load_pending_resolution(token, current_user)
    if not payload:
        flash("This claim-resolution session has expired. Please upload the receipts again.", "error")
        return redirect(url_for("claim.submit"))
    if request.method == "POST":
        current_app.logger.info("[CLAIM][ROUTE] RESOLVE_POST token=%s user_id=%s form=%r", token, getattr(current_user, "id", None), dict(request.form))
        print(f"[CLAIM][ROUTE] RESOLVE_POST token={token} user_id={getattr(current_user, 'id', None)} form={dict(request.form)!r}", flush=True)
        selections = {}
        for key, value in request.form.items():
            if key.startswith("employee_id_"):
                idx = key.split("_", 2)[2]
                selections.setdefault(idx, {})["employee_id"] = value
            elif key.startswith("employee_number_"):
                idx = key.split("_", 2)[2]
                selections.setdefault(idx, {})["employee_number"] = value
            elif key.startswith("employee_name_"):
                idx = key.split("_", 2)[2]
                selections.setdefault(idx, {})["employee_name"] = value
            elif key.startswith("institution_id_"):
                idx = key.split("_", 2)[2]
                selections.setdefault(idx, {})["institution_id"] = value
            elif key in {"beneficiary_type", "optics_lens_type", "optics_frame_price", "optics_lens_price"}:
                selections.setdefault("__form__", {})[key] = value
        try:
            success, message, claim_id = ClaimService.finalize_pending_resolution(token, selections, current_user)
        except Exception as exc:
            current_app.logger.exception("[CLAIM][ROUTE] RESOLVE_EXCEPTION token=%s user_id=%s", token, getattr(current_user, "id", None))
            print(f"[CLAIM][ROUTE] RESOLVE_EXCEPTION token={token} type={type(exc).__name__} error={exc!r}", flush=True)
            flash(f"Claim submission failed during final save: {exc}", "error")
            return render_template("claim/resolve.html", token=token, details=payload.get("unresolved", []), category=payload.get("category"), form_options=payload.get("form_options") or {})
        current_app.logger.info("[CLAIM][ROUTE] RESOLVE_RESULT success=%s claim_id=%s message=%r", success, claim_id, message)
        print(f"[CLAIM][ROUTE] RESOLVE_RESULT success={success} claim_id={claim_id} message={message!r}", flush=True)
        flash(message, "success" if success else "error")
        if success and claim_id:
            # Human resolution may finish a batch that contains several
            # employees. In that case there is no single claim to open, so
            # return to the list where all newly-created requests are visible.
            if isinstance(claim_id, (list, tuple, set)):
                current_app.logger.info(
                    "[CLAIM][ROUTE] RESOLVE_BATCH_COMPLETE claim_ids=%s",
                    list(claim_id)
                )
                return redirect(url_for("claim.index"))
            if AuthorizationService.is_hr(current_user):
                return redirect(url_for("claim.review", claim_id=claim_id))
            if AuthorizationService.is_medical_officer(current_user):
                return redirect(url_for("claim.view", claim_id=claim_id))
            return redirect(url_for("claim.index"))
    return render_template("claim/resolve.html", token=token, details=payload.get("unresolved", []), category=payload.get("category"), form_options=payload.get("form_options") or {})

def get_user_role():
    """
    Return the current user's role in normalized form.
    """
    role = getattr(current_user, "role_name", "")

    if role is None:
        return ""

    return str(role).strip().lower()

@claim_bp.route("/<int:claim_id>/review")
@login_required
def review(claim_id):
    claim = ClaimService.get_claim(claim_id)
    role = get_user_role()

    if not claim:
        flash(
            "Claim not found.",
            "error"
        )
        return redirect(
            url_for("claim.index")
        )

    from decimal import Decimal
    _coverage = Decimal("1")
    _has_deduction = claim.category == ClaimService.NORMAL and any(
        getattr(_item, "validation_status", "") == "MATCHED"
        and Decimal(str(getattr(_item, "receipt_price", 0) or 0))
            - Decimal(str(getattr(_item, "reimbursable_amount", 0) or 0)) > Decimal("0.004")
        for _item in (claim.items or [])
    )
    _is_uploader = AuthorizationService.owns_claim(claim, current_user)
    _uploader_discount_mode = (
        _is_uploader and claim.status == "APPROVED"
        and claim.category == ClaimService.NORMAL and _has_deduction
    )
    if not AuthorizationService.is_hr(current_user) and not _uploader_discount_mode:
        flash("Only HR can review claims. The uploader may edit only a discounted amount on their own approved claim.", "error")
        return redirect(url_for("claim.index"))

    if not AuthorizationService.can_view_claim(
        claim,
        current_user
    ):
        flash(
            "You are not authorized to view this claim.",
            "error"
        )
        return redirect(
            url_for("claim.index")
        )

    # Re-run the Normal-claim matcher at HR review time so older pending
    # claims also receive the precise service/price validation language.
    if claim.category == ClaimService.NORMAL and claim.status == "PENDING_REVIEW":
        try:
            from app.extensions import db
            changed = False
            for item in claim.items:
                item_institution_id = getattr(item, "institution_id", None) or claim.institution_id
                result = ClaimService._match_normal_item(
                    item_institution_id,
                    item.service_name,
                    item.unit_price,
                    service_code=getattr(item, "service_code", None),
                    raw_text=getattr(item, "service_description", None),
                )
                if result.get("matched") is not None and item.service_name != result["matched"].service_name:
                    item.service_name = result["matched"].service_name
                    changed = True
                if (
                    item.approved_price != result["approved_price"]
                    or item.difference != result["difference"]
                    or item.validation_status != result["status"]
                ):
                    item.approved_price = result["approved_price"]
                    item.difference = result["difference"]
                    item.validation_status = result["status"]
                    changed = True
            if changed:
                db.session.commit()

            # If automatic approval is enabled, a legacy pending Normal claim
            # that now has every service matched is finalized automatically.
            from decimal import Decimal
            coverage_factor = Decimal("1")
            has_deduction = any(
                getattr(item, "validation_status", "") == "MATCHED" and
                Decimal(str(getattr(item, "receipt_price", 0) or 0)) - Decimal(str(getattr(item, "reimbursable_amount", 0) or 0)) > Decimal("0.004")
                for item in claim.items
            )
            if (
                ClaimAutomationService.automatic_approval_enabled()
                and claim.items
                and all(getattr(item, "validation_status", "") == "MATCHED" for item in claim.items)
            ):
                claim.status = "APPROVED"
                db.session.commit()
                try:
                    from app.services.mail_service import send_claim_action_notification
                    send_claim_action_notification(claim, current_user, "APPROVED")
                except Exception as notify_exc:
                    current_app.logger.warning("Automatic Normal approval notification failed for claim %s: %s", claim.id, notify_exc)
        except Exception as exc:
            from app.extensions import db
            db.session.rollback()
            current_app.logger.warning(
                "Normal claim revalidation skipped for claim %s: %s",
                claim.id,
                exc,
            )

    item_information = {
        item.id: get_item_information(item)
        for item in claim.items
    }
    from decimal import Decimal
    coverage = Decimal("1")
    has_deductions = any(
        (claim.category == ClaimService.NORMAL
         and getattr(item, "validation_status", "") == "MATCHED"
         and Decimal(str(getattr(item, "receipt_price", 0) or 0)) - Decimal(str(getattr(item, "reimbursable_amount", 0) or 0)) > Decimal("0.004"))
        or (claim.category == ClaimService.PHARMACY and getattr(item, "validation_status", "") == "EXCLUDED_100")
        for item in claim.items
    )
    is_uploader = AuthorizationService.owns_claim(claim, current_user)
    can_edit_claim = AuthorizationService.is_hr(current_user) and (
        claim.status == "PENDING_REVIEW" or (claim.status == "APPROVED" and has_deductions)
    )
    can_edit_discount = bool(
        is_uploader and claim.status == "APPROVED" and has_deductions
        and claim.category == ClaimService.NORMAL
    )

    return render_template(
        "claim/review.html",
        claim=claim,
        item_information=item_information,
        has_deductions=has_deductions,
        can_edit_claim=can_edit_claim,
        can_edit_discount=can_edit_discount,
        is_uploader_discount_mode=can_edit_discount,
        read_only=not (can_edit_claim or can_edit_discount),
        can_approve=(
            AuthorizationService.is_hr(
                current_user
            )
            and claim.status == "PENDING_REVIEW"
        )
    )


@claim_bp.route("/<int:claim_id>/approved")
@login_required
def approved(claim_id):
    """Read-only evidence/details view for an already approved claim."""
    claim = ClaimService.get_claim(claim_id)
    if not claim:
        flash("Claim not found.", "error")
        return redirect(url_for("claim.index"))
    if claim.status != "APPROVED":
        flash("This claim is not approved yet.", "error")
        return redirect(url_for("claim.index"))
    if not (AuthorizationService.is_hr(current_user) or AuthorizationService.is_administrator(current_user)):
        flash("Only HR or Administrator can view approved claim details.", "error")
        return redirect(url_for("claim.index"))
    if not AuthorizationService.can_view_claim(claim, current_user):
        flash("You are not authorized to view this claim.", "error")
        return redirect(url_for("claim.index"))
    item_information = {item.id: get_item_information(item) for item in claim.items}
    return render_template("claim/review.html", claim=claim, item_information=item_information, can_approve=False, read_only=True)


@claim_bp.route("/<int:claim_id>/view")
@login_required
def view(claim_id):
    # Medical Officers get a read-only claim/evidence view. They must not
    # see HR approval/rejection controls.
    if not AuthorizationService.is_medical_officer(current_user):
        flash("Only Medical Officers can use the read-only claim view.", "error")
        return redirect(url_for("claim.index"))

    claim = ClaimService.get_claim(claim_id)
    if not claim:
        flash("Claim not found.", "error")
        return redirect(url_for("claim.index"))

    if not AuthorizationService.can_view_claim(claim, current_user):
        flash("You are not authorized to view this claim.", "error")
        return redirect(url_for("claim.index"))

    legacy_path = claim.receipt_file_path
    receipt_records = list(getattr(claim, "receipts", []) or [])
    receipt_available = any(os.path.isfile(r.file_path) for r in receipt_records)
    if not receipt_records and legacy_path and os.path.isfile(legacy_path):
        receipt_available = True

    receipt_metadata = {}
    for receipt in receipt_records:
        try:
            receipt_metadata[receipt.id] = json.loads(receipt.ai_extraction_json) if receipt.ai_extraction_json else {}
        except (TypeError, ValueError):
            receipt_metadata[receipt.id] = {}

    return render_template(
        "claim/view.html",
        claim=claim,
        receipt_available=receipt_available,
        receipt_records=receipt_records,
        receipt_metadata=receipt_metadata,
    )


@claim_bp.route("/<int:claim_id>/receipt")
@login_required
def receipt(claim_id):
    # HR and Medical Officers may view uploaded receipts. Medical Officers
    # can view claim evidence but never receive approval/rejection controls.
    if not (
        AuthorizationService.is_hr(current_user)
        or AuthorizationService.is_medical_officer(current_user)
    ):
        flash(
            "You are not authorized to view the uploaded claim receipt.",
            "error"
        )
        return redirect(url_for("claim.index"))

    claim = ClaimService.get_claim(claim_id)

    if not claim:
        flash(
            "Claim not found.",
            "error"
        )
        return redirect(
            url_for("claim.index")
        )

    if not AuthorizationService.can_view_claim(claim, current_user):
        flash("You are not authorized to view this claim.", "error")
        return redirect(url_for("claim.index"))

    receipt_path = claim.receipt_file_path
    receipt_records = list(getattr(claim, "receipts", []) or [])
    if receipt_records:
        receipt = receipt_records[0]
        receipt_path = receipt.file_path

    if not receipt_path or not os.path.isfile(receipt_path):
        flash(
            "The uploaded receipt could not be found.",
            "error"
        )
        return redirect(url_for("claim.review", claim_id=claim_id))

    return send_file(receipt_path, as_attachment=False)


@claim_bp.route("/<int:claim_id>/receipts/<int:receipt_id>")
@login_required
def receipt_item(claim_id, receipt_id):
    if not (AuthorizationService.is_hr(current_user) or AuthorizationService.is_medical_officer(current_user)):
        flash("You are not authorized to view uploaded claim receipts.", "error")
        return redirect(url_for("claim.index"))

    claim = ClaimService.get_claim(claim_id)
    if not claim or not AuthorizationService.can_view_claim(claim, current_user):
        flash("You are not authorized to view this claim.", "error")
        return redirect(url_for("claim.index"))

    receipt = next((r for r in getattr(claim, "receipts", []) if r.id == receipt_id), None)
    if not receipt or not receipt.file_path or not os.path.isfile(receipt.file_path):
        flash("The uploaded receipt could not be found.", "error")
        return redirect(url_for("claim.view", claim_id=claim_id) if AuthorizationService.is_medical_officer(current_user) else url_for("claim.review", claim_id=claim_id))

    return send_file(receipt.file_path, as_attachment=False, download_name=receipt.original_filename)


@claim_bp.route(
    "/<int:claim_id>/approve",
    methods=["POST"]
)
@login_required
def approve(claim_id):
    success, message = (
        ClaimService.approve_claim(
            claim_id,
            current_user=current_user
        )
    )

    flash(
        message,
        "success" if success else "error"
    )

    return redirect(
        url_for(
            "claim.review",
            claim_id=claim_id
        )
    )


@claim_bp.route(
    "/<int:claim_id>/reject",
    methods=["POST"]
)
@login_required
def reject(claim_id):
    success, message = (
        ClaimService.reject_claim(
            claim_id,
            current_user=current_user
        )
    )

    flash(
        message,
        "success" if success else "error"
    )

    return redirect(
        url_for(
            "claim.review",
            claim_id=claim_id
        )
    )


@claim_bp.route("/<int:claim_id>/items/<int:item_id>/update", methods=["POST"])
@login_required
def update_item(claim_id, item_id):
    if not AuthorizationService.is_hr(current_user):
        flash("Only HR can edit claim services.", "error")
        return redirect(url_for("claim.index"))
    claim = ClaimService.get_claim(claim_id)
    if not claim:
        flash("Claim not found.", "error")
        return redirect(url_for("claim.index"))
    from decimal import Decimal
    cov = Decimal("1")
    has_deductions = any(
        (claim.category == ClaimService.NORMAL and getattr(x, "validation_status", "") == "MATCHED"
         and Decimal(str(getattr(x, "receipt_price", 0) or 0)) - Decimal(str(getattr(x, "reimbursable_amount", 0) or 0)) > Decimal("0.004"))
        or (claim.category == ClaimService.PHARMACY and getattr(x, "validation_status", "") == "EXCLUDED_100")
        for x in claim.items
    )
    if claim.status != "PENDING_REVIEW" and not (claim.status == "APPROVED" and has_deductions):
        flash("Only pending claims or approved claims with deductions can be edited.", "error")
        return redirect(url_for("claim.index"))
    item = next((x for x in claim.items if x.id == item_id), None)
    if not item:
        flash("Claim service not found.", "error")
        return redirect(url_for("claim.review", claim_id=claim_id))
    try:
        from decimal import Decimal, ROUND_HALF_UP
        item.item_category = request.form.get("item_category", "MEDICAL_SERVICE").strip() or "MEDICAL_SERVICE"
        item.service_name = request.form.get("service_name", "").strip()
        item.service_description = request.form.get("service_description", "").strip() or item.service_name
        item.unit_price = Decimal(request.form.get("unit_price", "0") or "0").quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        item.receipt_price = Decimal(request.form.get("receipt_price", "0") or "0").quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        if not item.service_name or item.receipt_price < 0 or item.unit_price < 0:
            raise ValueError("Service name and non-negative prices are required.")
        item.approved_price = None
        item.difference = None
        item.validation_status = "NOT_APPLICABLE"
        if claim.category == ClaimService.PHARMACY:
            from app.services.pharmacy_exclusion_service import is_excluded
            excluded, _matched_exclusion = is_excluded(item.service_name, item.service_description)
            if excluded:
                item.validation_status = "EXCLUDED_100"
            else:
                item.validation_status = "NOT_APPLICABLE"
        if claim.category == ClaimService.NORMAL:
            from app.repositories.price_list_repository import ActivePriceRepository
            item_institution_id = getattr(item, "institution_id", None) or claim.institution_id
            active_batch = ActivePriceRepository.get_active_batch(item_institution_id) if item_institution_id else None
            if not active_batch:
                item.validation_status = "PRICE_LIST_UNAVAILABLE"
            if active_batch:
                match_result = ClaimService._match_normal_item(
                    item_institution_id,
                    item.service_name,
                    item.unit_price,
                    service_code=getattr(item, "service_code", None),
                    raw_text=getattr(item, "service_description", None),
                )
                item.approved_price = match_result["approved_price"]
                item.difference = match_result["difference"]
                item.validation_status = match_result["status"]
        coverage = Decimal("100")
        reimbursable_base = item.receipt_price
        if claim.category == ClaimService.NORMAL and item.approved_price is not None:
            quantity = Decimal("1")
            if item.unit_price is not None and item.unit_price > 0:
                try:
                    inferred_qty = (item.receipt_price / item.unit_price).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
                    if inferred_qty >= 1:
                        quantity = inferred_qty
                except Exception:
                    quantity = Decimal("1")
            reimbursable_base = item.approved_price * quantity
        item.reimbursable_amount = reimbursable_base.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        if claim.category == ClaimService.NORMAL:
            receipt_cap = item.receipt_price.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            item.reimbursable_amount = min(item.reimbursable_amount, receipt_cap)
        from app.extensions import db
        # Any manual edit requires a fresh HR decision, even when automatic
        # approval is enabled; do not silently re-approve an edited deduction.
        claim.status = "PENDING_REVIEW"
        db.session.commit()
        flash("Claim service updated and price matching recalculated.", "success")
    except Exception as exc:
        from app.extensions import db
        db.session.rollback()
        flash(f"Unable to update service: {exc}", "error")
    return redirect(url_for("claim.review", claim_id=claim_id))


@claim_bp.route("/<int:claim_id>/items/<int:item_id>/discount", methods=["POST"])
@login_required
def update_discount(claim_id, item_id):
    """Allow only the original uploader to propose a revised reimbursable amount on their own approved deducted Normal claim."""
    from decimal import Decimal, ROUND_HALF_UP
    claim = ClaimService.get_claim(claim_id)
    if not claim or not AuthorizationService.owns_claim(claim, current_user):
        flash("Only the original uploader may edit a discounted amount on their own claim.", "error")
        return redirect(url_for("claim.index"))
    if claim.status != "APPROVED" or claim.category != ClaimService.NORMAL:
        flash("Only an approved Normal claim with a deduction can be edited by its uploader.", "error")
        return redirect(url_for("claim.index"))
    item = next((x for x in (claim.items or []) if x.id == item_id), None)
    if not item or getattr(item, "validation_status", "") != "MATCHED":
        flash("The selected line is not an eligible matched service.", "error")
        return redirect(url_for("claim.review", claim_id=claim_id))
    coverage = Decimal("1")
    receipt_eligible = (Decimal(str(item.receipt_price or 0))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    current_reimbursable = Decimal(str(item.reimbursable_amount or 0))
    if receipt_eligible - current_reimbursable <= Decimal("0.004"):
        flash("This line has no current deduction to edit.", "error")
        return redirect(url_for("claim.review", claim_id=claim_id))
    try:
        proposed = Decimal(request.form.get("reimbursable_amount", "")).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        if proposed < 0 or proposed > receipt_eligible:
            raise ValueError(f"Reimbursable amount must be between 0.00 and {receipt_eligible:.2f} ETB.")
        item.reimbursable_amount = proposed
        # Discount edits are allowed only on an already approved, matched claim.
        # Keep it approved; the red deduction marker remains visible if the
        # revised amount is still below the receipt-eligible amount.
        claim.status = "APPROVED"
        from app.extensions import db
        db.session.commit()
        flash("Discounted amount saved. The claim remains approved.", "success")
    except Exception as exc:
        from app.extensions import db
        db.session.rollback()
        flash(f"Unable to update discounted amount: {exc}", "error")
    return redirect(url_for("claim.index"))


@claim_bp.route("/<int:claim_id>/items/<int:item_id>/delete", methods=["POST"])
@login_required
def delete_item(claim_id, item_id):
    if not AuthorizationService.is_hr(current_user):
        flash("Only HR can remove claim services.", "error")
        return redirect(url_for("claim.index"))
    claim = ClaimService.get_claim(claim_id)
    if not claim:
        flash("Claim not found.", "error")
        return redirect(url_for("claim.index"))
    from decimal import Decimal
    cov = Decimal("1")
    has_deductions = any(
        (claim.category == ClaimService.NORMAL and getattr(x, "validation_status", "") == "MATCHED"
         and Decimal(str(getattr(x, "receipt_price", 0) or 0)) - Decimal(str(getattr(x, "reimbursable_amount", 0) or 0)) > Decimal("0.004"))
        or (claim.category == ClaimService.PHARMACY and getattr(x, "validation_status", "") == "EXCLUDED_100")
        for x in claim.items
    )
    if claim.status != "PENDING_REVIEW" and not (claim.status == "APPROVED" and has_deductions):
        flash("Only pending claims or approved claims with deductions can be edited.", "error")
        return redirect(url_for("claim.index"))
    item = next((x for x in claim.items if x.id == item_id), None)
    if not item:
        flash("Claim service not found.", "error")
        return redirect(url_for("claim.review", claim_id=claim_id))
    from app.extensions import db
    db.session.delete(item)
    claim.status = "PENDING_REVIEW"
    db.session.commit()
    flash("Claim service removed. The claim is back in HR review.", "success")
    return redirect(url_for("claim.review", claim_id=claim_id))
