# ============================================================
# FILE:
# D:\Medical\MedicalReimbursementSystem\app\routes\auth.py
# ============================================================

from flask import Blueprint, session
from flask import flash
from flask import redirect
from flask import render_template
from flask import request
from flask import url_for

from app.decorators.auth import admin_required
from app.decorators.auth import login_required
#from app.routes.auth import administrator_required
from app.decorators.auth import current_user
from app.models.role import Role
from app.services.auth_service import AuthService
from app.services.mail_service import send_account_creation_notification, send_role_submission_notification

from datetime import datetime

from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    request,
    url_for
)

from flask_login import (
    current_user,
    login_required
)

from app.extensions import db
from app.models.user import User


auth_bp = Blueprint(
    "auth",
    __name__,
    url_prefix="/auth"
)

# ======================================
# last add
#========================================

@auth_bp.route(
    "/role-approvals/<int:user_id>/approve",
    methods=["POST"]
)
#@administrator_required
def approve_role(user_id):

    if not administrator_required():
        flash(
            "Administrator access required.",
            "danger"
        )
        return redirect(url_for("main.index"))

    user = User.query.get_or_404(user_id)

    if user.role_approval_status != "PENDING":
        flash(
            "This role request is not pending.",
            "warning"
        )
        return redirect(
            url_for("auth.role_approvals")
        )

    success, message = AuthService.approve_role(user, current_user)

    flash(
        message,
        "success" if success else "error"
    )

    return redirect(
        url_for("auth.role_approvals")
    )


@auth_bp.route(
    "/role-approvals/<int:user_id>/reject",
    methods=["POST"]
)
#@administrator_required
def reject_role(user_id):

    if not administrator_required():
        flash(
            "Administrator access required.",
            "danger"
        )
        return redirect(url_for("main.index"))

    user = User.query.get_or_404(user_id)

    if user.role_approval_status != "PENDING":
        flash(
            "This role request is not pending.",
            "warning"
        )
        return redirect(
            url_for("auth.role_approvals")
        )

    reason = request.form.get(
        "reason",
        ""
    ).strip()

    success, message = AuthService.reject_role(
        user,
        current_user,
        reason
    )

    flash(
        message,
        "warning" if success else "error"
    )

    return redirect(
        url_for("auth.role_approvals")
    )



def administrator_required():
    return (
        current_user.is_authenticated
        and current_user.is_admin
    )

@auth_bp.route("/role-approvals")
#@administrator_required
def role_approvals():

    if not administrator_required():
        flash(
            "Administrator access required.",
            "danger"
        )
        return redirect(url_for("main.index"))

    pending_users = (
        User.query
        .filter(
            User.role_approval_status == "PENDING"
        )
        .order_by(
            User.role_requested_at.asc()
        )
        .all()
    )

    return render_template(
        "auth/role_approvals.html",
        pending_users=pending_users
    )


# ============================================================
# LOGIN
# ============================================================

# ============================================================
# LOGIN
# EMAIL + PASSWORD ONLY
# ============================================================

@auth_bp.route(
    "/login",
    methods=["GET", "POST"]
)
def login():

    if request.method == "POST":

        email = (
            request.form.get(
                "email",
                ""
            )
            .strip()
            .lower()
        )

        password = request.form.get(
            "password",
            ""
        )

        success, message = AuthService.login(
            email,
            password,
            ip_address=request.headers.get(
                "X-Forwarded-For",
                request.remote_addr
            ).split(",")[0].strip(),
            user_agent=request.headers.get(
                "User-Agent",
                "Unknown"
            )
        )

        if success:

            flash(
                message,
                "success"
            )

            consultation_after_login = session.pop("consultation_after_login", None)
            if consultation_after_login:
                return redirect(consultation_after_login)

            next_url = request.args.get("next") or request.form.get("next")
            if next_url and next_url.startswith("/") and not next_url.startswith("//"):
                return redirect(next_url)

            return redirect(
                url_for("main.index")
            )

        flash(
            message,
            "error"
        )

    return render_template(
        "auth/login.html"
    )


# ============================================================
# PUBLIC REGISTRATION
#
# USER ENTERS:
#   - EMAIL
#   - PASSWORD
#   - CONFIRM PASSWORD
#   - REQUESTED ROLE
#
# USER DOES NOT ENTER:
#   - username
#   - full_name
#
# username   = email
# full_name  = email
#
# EMPLOYEE:
#   automatically approved
#
# OTHER ROLES:
#   PENDING administrator approval
#
# IMPORTANT:
#   This route does NOT use current_user.
#   Registration is for unauthenticated users.
# ============================================================

@auth_bp.route(
    "/register",
    methods=["GET", "POST"]
)
def register():

    roles = (
        Role.query
        .order_by(
            Role.name.asc()
        )
        .all()
    )

    # ========================================================
    # GET
    # ========================================================

    if request.method == "GET":

        return render_template(
            "auth/register.html",
            roles=roles
        )

    # ========================================================
    # POST
    # ========================================================

    email = (
        request.form.get(
            "email",
            ""
        )
        .strip()
        .lower()
    )

    password = request.form.get(
        "password",
        ""
    )

    confirm_password = request.form.get(
        "confirm_password",
        ""
    )

    selected_role_name = (
        request.form.get(
            "role",
            ""
        )
        .strip()
    )

    # ========================================================
    # EMAIL
    # ========================================================

    if not email:

        flash(
            "Email is required.",
            "error"
        )

        return render_template(
            "auth/register.html",
            roles=roles
        )

    # ========================================================
    # PASSWORD
    # ========================================================

    if not password:

        flash(
            "Password is required.",
            "error"
        )

        return render_template(
            "auth/register.html",
            roles=roles
        )

    if len(password) < 6:

        flash(
            "Password must be at least 6 characters.",
            "error"
        )

        return render_template(
            "auth/register.html",
            roles=roles
        )

    if confirm_password and password != confirm_password:

        flash(
            "Passwords do not match.",
            "error"
        )

        return render_template(
            "auth/register.html",
            roles=roles
        )

   # ============================================================
    # ROLE VALIDATION
    # ============================================================

    if not selected_role_name:

        flash(
            "Please select a requested role.",
            "error"
        )

        return render_template(
            "auth/register.html",
            roles=roles
        )


    # ============================================================
    # ADMINISTRATOR CAN NEVER BE CREATED THROUGH PUBLIC
    # REGISTRATION
    # ============================================================

    if selected_role_name.strip().lower() in {
        "administrator",
        "admin"
    }:

        flash(
            "Administrator accounts cannot be created through public registration.",
            "error"
        )

        return render_template(
            "auth/register.html",
            roles=roles
        )


    selected_role = (
        Role.query
        .filter(
            Role.name.ilike(
                selected_role_name
            )
        )
        .first()
    )

    if not selected_role:

        flash(
            "Selected role does not exist.",
            "error"
        )

        return render_template(
            "auth/register.html",
            roles=roles
        )

    restricted_email_role = selected_role.name.strip().lower() in {"employee", "hr"}

    if not restricted_email_role and not confirm_password:
        flash(
            "Please confirm your password.",
            "error"
        )
        return render_template(
            "auth/register.html",
            roles=roles
        )

    if restricted_email_role and not email.endswith("@bankofabyssinia.com"):
        flash(
            "Employee and HR accounts must use a @bankofabyssinia.com email address.",
            "error"
        )
        return render_template(
            "auth/register.html",
            roles=roles
        )

    # ========================================================
    # BOA LDAP VERIFICATION FOR EMPLOYEE / HR
    # Registration does not create an independent password for
    # these roles. The supplied password is verified directly
    # against Active Directory and is never stored in plaintext.
    # ========================================================
    if restricted_email_role:
        from app.services.ldap_service import authenticate_user
        ldap_ok, ldap_user, ldap_message = authenticate_user(email, password)
        if not ldap_ok:
            flash(
                "BOA LDAP verification failed. Check your organizational email and password.",
                "error"
            )
            print(f"[AUTH][REGISTER][LDAP] verification failed for {email}", flush=True)
            return render_template("auth/register.html", roles=roles)

        email = (ldap_user.get("email") or email).strip().lower()

    # ========================================================
    # EXISTING EMAIL
    # ========================================================

    existing_user = (
        User.query
        .filter(
            User.email == email
        )
        .first()
    )

    if existing_user:

        flash(
            "An account with this email already exists.",
            "error"
        )

        return render_template(
            "auth/register.html",
            roles=roles
        )

    # ========================================================
    # GENERATE OTP
    # ========================================================

    import secrets
    from datetime import datetime, timedelta
    from werkzeug.security import generate_password_hash

    otp = str(
        secrets.randbelow(900000) + 100000
    )

    # ========================================================
    # IMPORTANT
    #
    # DO NOT STORE THE PLAINTEXT PASSWORD IN SESSION.
    #
    # Store the password hash instead.
    # ========================================================

    password_hash = generate_password_hash(
        password
    )

    # ========================================================
    # STORE TEMPORARY REGISTRATION
    # ========================================================

    session["registration_email"] = email

    session["registration_password_hash"] = (
        password_hash
    )

    session["registration_role_id"] = (
        selected_role.id
    )

    session["registration_otp"] = otp

    session["registration_otp_expires"] = (
        (
            datetime.utcnow()
            + timedelta(minutes=10)
        ).timestamp()
    )

    # ========================================================
    # SEND OTP
    # ========================================================

    from app.services.mail_service import (
        send_registration_otp
    )

    email_sent = send_registration_otp(
        email,
        otp
    )

    if not email_sent:

        session.pop(
            "registration_email",
            None
        )

        session.pop(
            "registration_password_hash",
            None
        )

        session.pop(
            "registration_role_id",
            None
        )

        session.pop(
            "registration_otp",
            None
        )

        session.pop(
            "registration_otp_expires",
            None
        )

        flash(
            "Unable to send verification email. "
            "Please try again.",
            "error"
        )

        return render_template(
            "auth/register.html",
            roles=roles
        )

    # ========================================================
    # REDIRECT TO OTP PAGE
    # ========================================================

    flash(
        "A 6-digit verification code has been "
        "sent to your email.",
        "success"
    )

    return redirect(
        url_for(
            "auth.verify_registration_otp"
        )
    )
@auth_bp.route(
    "/register/verify-otp",
    methods=["GET", "POST"]
)
def verify_registration_otp():

    from datetime import datetime
    from werkzeug.security import check_password_hash

    # ========================================================
    # CHECK REGISTRATION SESSION
    # ========================================================

    email = session.get(
        "registration_email"
    )

    password_hash = session.get(
        "registration_password_hash"
    )

    role_id = session.get(
        "registration_role_id"
    )

    stored_otp = session.get(
        "registration_otp"
    )

    expires_at = session.get(
        "registration_otp_expires"
    )

    if not all(
        [
            email,
            password_hash,
            role_id,
            stored_otp,
            expires_at
        ]
    ):

        flash(
            "Registration verification session has expired. "
            "Please register again.",
            "error"
        )

        return redirect(
            url_for(
                "auth.register"
            )
        )

    # ========================================================
    # OTP EXPIRATION
    # ========================================================

    if datetime.utcnow().timestamp() > float(
        expires_at
    ):

        session.pop(
            "registration_email",
            None
        )

        session.pop(
            "registration_password_hash",
            None
        )

        session.pop(
            "registration_role_id",
            None
        )

        session.pop(
            "registration_otp",
            None
        )

        session.pop(
            "registration_otp_expires",
            None
        )

        flash(
            "Verification code expired. "
            "Please register again.",
            "error"
        )

        return redirect(
            url_for(
                "auth.register"
            )
        )

    # ========================================================
    # GET
    # ========================================================

    if request.method == "GET":

        return render_template(
            "auth/verify_otp.html",
            email=email
        )

    # ========================================================
    # POST
    # ========================================================

    entered_otp = (
        request.form.get(
            "otp",
            ""
        )
        .strip()
    )

    # ========================================================
    # OTP VALIDATION
    # ========================================================

    if entered_otp != str(stored_otp):

        flash(
            "Invalid verification code.",
            "error"
        )

        return render_template(
            "auth/verify_otp.html",
            email=email
        )

    # ========================================================
    # CHECK EMAIL AGAIN
    #
    # Prevent duplicate accounts if another account was
    # created while this registration was waiting.
    # ========================================================

    existing_user = (
        User.query
        .filter(
            User.email == email
        )
        .first()
    )

    if existing_user:

        session.clear()

        flash(
            "An account with this email already exists.",
            "error"
        )

        return redirect(
            url_for(
                "auth.login"
            )
        )

    # ========================================================
    # GET ROLE
    # ========================================================

    role = (
        Role.query
        .filter(
            Role.id == role_id
        )
        .first()
    )

    if not role:

        session.clear()

        flash(
            "The requested role no longer exists.",
            "error"
        )

        return redirect(
            url_for(
                "auth.register"
            )
        )

    # ========================================================
    # EMPLOYEE = AUTOMATIC APPROVAL
    #
    # EVERYTHING ELSE = PENDING ADMIN APPROVAL
    # ========================================================

    is_employee = (
        role.name.strip().lower()
        == "employee"
    )

    if is_employee:

        approval_status = "APPROVED"

    else:

        approval_status = "PENDING"

    # ========================================================
    # CREATE USER ONLY NOW
    #
    # OTP WAS SUCCESSFULLY VERIFIED.
    # ========================================================

    user = User(
        username=email,
        full_name=email,
        email=email,
        role_id=role.id,
        is_active=True
    )

    # We already hashed the password before OTP.
    user.password_hash = password_hash

    # ========================================================
    # ROLE STATUS
    # ========================================================

    if hasattr(
        user,
        "role_approval_status"
    ):

        user.role_approval_status = (
            approval_status
        )

    if hasattr(
        user,
        "role_status"
    ):

        user.role_status = (
            approval_status
        )

    if hasattr(
        user,
        "role_requested_at"
    ):

        user.role_requested_at = (
            datetime.utcnow()
        )

    if (
        is_employee
        and hasattr(
            user,
            "role_approved_at"
        )
    ):

        user.role_approved_at = (
            datetime.utcnow()
        )

    # ========================================================
    # SAVE
    # ========================================================

    try:

        db.session.add(
            user
        )

        db.session.commit()

    except Exception as e:

        db.session.rollback()

        print(
            "[REGISTRATION][ERROR]",
            repr(e)
        )

        flash(
            "Unable to create account.",
            "error"
        )

        return redirect(
            url_for(
                "auth.register"
            )
        )

    # Email notifications must never prevent a successful account creation.
    try:
        send_account_creation_notification(user)
        if not is_employee:
            send_role_submission_notification(user)
    except Exception as exc:
        print("[MAIL][REGISTRATION][ERROR]", repr(exc))

    # ========================================================
    # DELETE OTP REGISTRATION SESSION
    # ========================================================

    session.pop(
        "registration_email",
        None
    )

    session.pop(
        "registration_password_hash",
        None
    )

    session.pop(
        "registration_role_id",
        None
    )

    session.pop(
        "registration_otp",
        None
    )

    session.pop(
        "registration_otp_expires",
        None
    )

    # ========================================================
    # RESULT
    # ========================================================

    if is_employee:

        flash(
            "Email verified and account created successfully. "
            "You may now log in.",
            "success"
        )

    else:

        flash(
            "Email verified and account created successfully. "
            "Your requested role is pending Administrator approval.",
            "success"
        )

    return redirect(
        url_for(
            "auth.login"
        )
    )

# ============================================================
# LOGOUT
# ============================================================

@auth_bp.route(
    "/logout"
)
@login_required
def logout():

    AuthService.logout()

    flash(
        "Logged out successfully.",
        "success"
    )

    return redirect(
        url_for("auth.login")
    )


# ============================================================
# USERS
# ============================================================

@auth_bp.route(
    "/users"
)
@admin_required
def users():

    users = AuthService.list_users()

    return render_template(
        "auth/users.html",
        users=users
    )


# ============================================================
# CREATE USER
# ============================================================

@auth_bp.route(
    "/users/create",
    methods=["GET", "POST"]
)
@admin_required
def create_user():

    roles = (
        Role.query
        .order_by(
            Role.name.asc()
        )
        .all()
    )

    if request.method == "POST":

        success, message = (
            AuthService.create_user(
                username=request.form.get(
                    "username",
                    ""
                ),
                full_name=request.form.get(
                    "full_name",
                    ""
                ),
                email=request.form.get(
                    "email",
                    ""
                ),
                password=request.form.get(
                    "password",
                    ""
                ),
                role_name=request.form.get(
                    "role",
                    ""
                )
            )
        )

        flash(
            message,
            "success"
            if success
            else "error"
        )

        if success:

            return redirect(
                url_for(
                    "auth.users"
                )
            )

    return render_template(
        "auth/create_user.html",
        roles=roles
    )


# ============================================================
# ENABLE USER
# ============================================================

@auth_bp.route(
    "/users/<int:user_id>/enable",
    methods=["POST"]
)
@admin_required
def enable(user_id):

    user = AuthService.get_user(
        user_id
    )

    if not user:

        flash(
            "User not found.",
            "error"
        )

        return redirect(
            url_for("auth.users")
        )

    AuthService.enable_user(
        user,
        administrator=current_user
    )

    flash(
        "User enabled.",
        "success"
    )

    return redirect(
        url_for("auth.users")
    )


# ============================================================
# DISABLE USER
# ============================================================

@auth_bp.route(
    "/users/<int:user_id>/disable",
    methods=["POST"]
)
@admin_required
def disable(user_id):

    user = AuthService.get_user(
        user_id
    )

    if not user:

        flash(
            "User not found.",
            "error"
        )

        return redirect(
            url_for("auth.users")
        )

    AuthService.disable_user(
        user,
        administrator=current_user
    )

    flash(
        "User disabled.",
        "success"
    )

    return redirect(
        url_for("auth.users")
    )


# ============================================================
# PENDING ROLE APPROVALS
# ============================================================

'''@auth_bp.route(
    "/role-approvals"
)
@admin_required
def role_approvals():

    users = (
        AuthService
        .pending_role_requests()
    )

    return render_template(
        "auth/role_approvals.html",
        users=users
    )'''


# ============================================================
# APPROVE ROLE
# ============================================================

'''@auth_bp.route(
    "/role-approvals/<int:user_id>/approve",
    methods=["POST"]
)
@admin_required
def approve_role(user_id):

    administrator = current_user()

    user = AuthService.get_user(
        user_id
    )

    success, message = (
        AuthService.approve_role(
            user,
            administrator
        )
    )

    flash(
        message,
        "success"
        if success
        else "error"
    )

    return redirect(
        url_for(
            "auth.role_approvals"
        )
    )'''


# ============================================================
# REJECT ROLE
# ============================================================

'''@auth_bp.route(
    "/role-approvals/<int:user_id>/reject",
    methods=["POST"]
)
@admin_required
def reject_role(user_id):

    administrator = current_user()

    user = AuthService.get_user(
        user_id
    )

    reason = request.form.get(
        "reason",
        ""
    )

    success, message = (
        AuthService.reject_role(
            user,
            administrator,
            reason
        )
    )

    flash(
        message,
        "success"
        if success
        else "error"
    )

    return redirect(
        url_for(
            "auth.role_approvals"
        )
    )'''


# ============================================================
# CHANGE PASSWORD
# ============================================================

@auth_bp.route(
    "/change-password",
    methods=["GET", "POST"]
)
@login_required
def change_password():

    user = (
        AuthService.current_user()
    )

    if request.method == "POST":

        success, message = (
            AuthService.change_password(
                user,
                request.form.get(
                    "old_password",
                    ""
                ),
                request.form.get(
                    "new_password",
                    ""
                )
            )
        )

        flash(
            message,
            "success"
            if success
            else "error"
        )

        if success:

            return redirect(
                url_for("main.index")
            )

    return render_template(
        "auth/change_password.html"
    )