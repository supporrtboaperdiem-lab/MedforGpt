from app.extensions import db
from app.models.base import BaseModel


class Employee(BaseModel):
    __tablename__ = "employees"

    # employee_code remains the legacy application key. For imported directory
    # records it is populated from Employee ID, falling back to Employee Number.
    employee_code = db.Column(db.String(50), unique=True, nullable=False, index=True)
    employee_id = db.Column(db.String(100), nullable=True, index=True)
    employee_number = db.Column(db.String(100), nullable=True, index=True)
    username = db.Column(db.String(150), nullable=True, index=True)
    user_principal_name = db.Column(db.String(255), nullable=True, index=True)
    email = db.Column(db.String(255), nullable=True)
    first_name = db.Column(db.String(100), nullable=True)
    middle_name = db.Column(db.String(100), nullable=True)
    last_name = db.Column(db.String(100), nullable=True)
    job_title = db.Column(db.String(255), nullable=True)
    department = db.Column(db.String(255), nullable=True, index=True)
    company = db.Column(db.String(255), nullable=True)
    office = db.Column(db.String(255), nullable=True, index=True)
    division = db.Column(db.String(255), nullable=True)
    employee_type = db.Column(db.String(100), nullable=True)
    mobile = db.Column(db.String(100), nullable=True)
    telephone = db.Column(db.String(100), nullable=True)
    business_address = db.Column(db.String(500), nullable=True)
    city = db.Column(db.String(100), nullable=True)
    state_region = db.Column(db.String(100), nullable=True)
    country = db.Column(db.String(100), nullable=True)
    manager = db.Column(db.String(255), nullable=True, index=True)
    description = db.Column(db.Text, nullable=True)

    full_name = db.Column(db.String(200), nullable=False)

    expenses = db.relationship("Expense", back_populates="employee", lazy=True)
    documents = db.relationship("Document", back_populates="employee", lazy=True)

    def __repr__(self):
        return f"<Employee {self.employee_code} - {self.full_name}>"
