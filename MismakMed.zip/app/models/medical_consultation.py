from datetime import datetime
import secrets

from app.extensions import db


class MedicalConsultation(db.Model):
    __tablename__ = "medical_consultations"

    id = db.Column(db.Integer, primary_key=True)
    token = db.Column(db.String(96), unique=True, nullable=False, index=True)
    requester_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    receiver_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)

    # Legacy compatibility: an earlier consultation schema used
    # medical_officer_id as a required column. Keep it mapped so existing
    # databases can continue to accept new consultation rows while the
    # current requester/receiver model remains authoritative.
    medical_officer_id = db.Column(
        db.Integer,
        db.ForeignKey("users.id"),
        nullable=True,
        index=True,
    )

    status = db.Column(db.String(20), nullable=False, default="PENDING", index=True)
    offer = db.Column(db.Text, nullable=True)
    answer = db.Column(db.Text, nullable=True)
    requester_candidates = db.Column(db.Text, nullable=False, default="[]")
    receiver_candidates = db.Column(db.Text, nullable=False, default="[]")
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_activity_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    accepted_at = db.Column(db.DateTime, nullable=True)
    started_at = db.Column(db.DateTime, nullable=True)
    ended_at = db.Column(db.DateTime, nullable=True)
    duration_seconds = db.Column(db.Integer, nullable=False, default=0)
    ended_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True, index=True)
    end_reason = db.Column(db.String(100), nullable=True)

    # Legacy schema compatibility: older consultation tables require an
    # expires_at value for every request. Keep the field mapped and always
    # populate it for new rows so existing databases continue to accept
    # inserts without changing or dropping their schema.
    expires_at = db.Column(db.DateTime, nullable=False, index=True)

    requester = db.relationship("User", foreign_keys=[requester_id], lazy=True)
    receiver = db.relationship("User", foreign_keys=[receiver_id], lazy=True)
    ended_by = db.relationship("User", foreign_keys=[ended_by_id], lazy=True)

    @staticmethod
    def new_token():
        return secrets.token_urlsafe(48)


class MedicalPresence(db.Model):
    __tablename__ = "medical_presence"

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), primary_key=True)
    last_seen_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, index=True)

    user = db.relationship("User", foreign_keys=[user_id], lazy=True)
