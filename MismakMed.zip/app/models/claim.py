from app.extensions import db
from app.models.base import BaseModel


class MedicalClaim(BaseModel):
    __tablename__ = "medical_claims"

    # Existing employee relationship.
    # DO NOT REMOVE.
    employee_id = db.Column(
        db.Integer,
        db.ForeignKey("employees.id"),
        nullable=True,
        index=True
    )

    # NEW:
    # The actual authenticated User who submitted the claim.
    #
    # This is what we use for ownership/security.
    submitted_by_id = db.Column(
        db.Integer,
        db.ForeignKey("users.id"),
        nullable=True,
        index=True
    )

    # Optics claims intentionally have no institution/provider association.
    # Normal and Pharmacy claims still require a matched institution.
    institution_id = db.Column(
        db.Integer,
        db.ForeignKey("institutions.id"),
        nullable=True,
        index=True
    )

    patient_name = db.Column(
        db.String(200),
        nullable=False
    )

    category = db.Column(
        db.String(20),
        nullable=False,
        default="NORMAL",
        server_default="NORMAL",
        index=True
    )

    # Beneficiary is always reported under the owning employee.
    # Spouse institution-facing reimbursement remains 100% of eligible items;
    # 90% coverage and the 10% employee share are shown separately in reports.
    beneficiary_type = db.Column(
        db.String(20),
        nullable=False,
        default="EMPLOYEE",
        server_default="EMPLOYEE",
        index=True
    )

    beneficiary_name = db.Column(
        db.String(200),
        nullable=True
    )

    employee_owner_name = db.Column(
        db.String(200),
        nullable=True
    )

    coverage_percentage = db.Column(
        db.Numeric(5, 2),
        nullable=False,
        default=100,
        server_default="100"
    )

    # Optics reimbursement policy inputs/results. These are stored at claim
    # level because frame/lens eligibility is a lifetime benefit per employee.
    optics_lens_type = db.Column(db.String(30), nullable=True)
    optics_frame_price = db.Column(db.Numeric(12, 2), nullable=True)
    optics_lens_price = db.Column(db.Numeric(12, 2), nullable=True)
    optics_frame_reimbursable = db.Column(db.Numeric(12, 2), nullable=True)
    optics_lens_reimbursable = db.Column(db.Numeric(12, 2), nullable=True)
    optics_reimbursable_total = db.Column(db.Numeric(12, 2), nullable=True)

    receipt_file_path = db.Column(
        db.String(500),
        nullable=False
    )

    status = db.Column(
        db.String(50),
        nullable=False,
        default="PENDING_REVIEW"
    )

    # Existing relationships.
    employee = db.relationship("Employee")
    institution = db.relationship("Institution")

    # NEW relationship to authenticated User.
    submitted_by = db.relationship(
        "User",
        foreign_keys=[submitted_by_id]
    )

    items = db.relationship(
        "MedicalClaimItem",
        back_populates="claim",
        lazy=True,
        cascade="all, delete-orphan"
    )

    receipts = db.relationship(
        "MedicalClaimReceipt",
        back_populates="claim",
        lazy=True,
        cascade="all, delete-orphan",
        order_by="MedicalClaimReceipt.id.asc()"
    )


class MedicalClaimItem(BaseModel):
    __tablename__ = "medical_claim_items"

    claim_id = db.Column(
        db.Integer,
        db.ForeignKey("medical_claims.id"),
        nullable=False,
        index=True
    )

    service_name = db.Column(
        db.String(255),
        nullable=False
    )

    # Expense-level category/service classification. This is intentionally
    # separate from the claim category (NORMAL/OPTICS/PHARMACY).
    item_category = db.Column(
        db.String(100),
        nullable=True,
        default="MEDICAL_SERVICE",
        server_default="MEDICAL_SERVICE"
    )

    # Unit price is extracted from the receipt and is the primary key used
    # when matching a Normal-claim service against the approved price list.
    unit_price = db.Column(
        db.Numeric(12, 2),
        nullable=True
    )

    # Allows one submitted claim to contain expenses belonging to multiple
    # employees. Existing claim-level employee_id remains for compatibility.
    employee_id = db.Column(
        db.Integer,
        db.ForeignKey("employees.id"),
        nullable=True,
        index=True
    )

    # Institution/provider for this individual expense. This is important when
    # several receipts for the same employee come from different providers.
    institution_id = db.Column(
        db.Integer,
        db.ForeignKey("institutions.id"),
        nullable=True,
        index=True
    )

    receipt_id = db.Column(
        db.Integer,
        db.ForeignKey("medical_claim_receipts.id"),
        nullable=True,
        index=True
    )

    service_description = db.Column(
        db.Text,
        nullable=True
    )

    receipt_price = db.Column(
        db.Numeric(12, 2),
        nullable=False
    )

    approved_price = db.Column(
        db.Numeric(12, 2),
        nullable=True
    )

    difference = db.Column(
        db.Numeric(12, 2),
        nullable=True
    )

    reimbursable_amount = db.Column(
        db.Numeric(12, 2),
        nullable=False,
        default=0,
        server_default="0"
    )

    validation_status = db.Column(
        db.String(50),
        nullable=False,
        default="NEEDS_REVIEW"
    )

    claim = db.relationship(
        "MedicalClaim",
        back_populates="items"
    )

    employee = db.relationship("Employee", foreign_keys=[employee_id])
    institution = db.relationship("Institution", foreign_keys=[institution_id])
    receipt = db.relationship("MedicalClaimReceipt", foreign_keys=[receipt_id])

class MedicalClaimReceipt(BaseModel):
    """Individual receipt/evidence file belonging to a medical claim."""

    __tablename__ = "medical_claim_receipts"

    claim_id = db.Column(
        db.Integer,
        db.ForeignKey("medical_claims.id"),
        nullable=False,
        index=True
    )

    file_path = db.Column(
        db.String(500),
        nullable=False
    )

    original_filename = db.Column(
        db.String(255),
        nullable=False
    )

    # Date printed on the receipt, extracted by the multimodal AI. This is
    # the business/reporting date; claim.created_at remains the upload time.
    receipt_date = db.Column(
        db.DateTime,
        nullable=True,
        index=True
    )

    # Server-side timestamp of the actual upload/submission of this receipt.
    # This is deliberately separate from receipt_date, which is the date
    # printed on the document.
    uploaded_at = db.Column(
        db.DateTime,
        nullable=True,
        index=True
    )

    # Fraud/duplicate-detection fingerprints. file_sha256 is the strongest
    # exact-file guard; image_phash catches re-encoded/re-photographed copies;
    # metadata fingerprints catch the same receipt when image hashing is not
    # available.
    file_sha256 = db.Column(
        db.String(64),
        nullable=True,
        unique=True,
        index=True
    )
    image_phash = db.Column(
        db.String(64),
        nullable=True,
        index=True
    )
    receipt_metadata_fingerprint = db.Column(
        db.String(64),
        nullable=True,
        index=True
    )
    receipt_metadata_key = db.Column(
        db.String(500),
        nullable=True,
        index=True
    )

    # Structured multimodal-AI extraction for this individual receipt.
    # Stored as JSON text so the schema remains SQLite/PostgreSQL compatible.
    ai_extraction_json = db.Column(
        db.Text,
        nullable=True
    )

    claim = db.relationship(
        "MedicalClaim",
        back_populates="receipts"
    )
