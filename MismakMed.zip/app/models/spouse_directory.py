from app.extensions import db
from app.models.base import BaseModel


class SpouseDirectory(BaseModel):
    __tablename__ = "spouse_directory"

    employee_number = db.Column(db.String(100), nullable=False, index=True)
    employee_name = db.Column(db.String(200), nullable=False)
    spouse_name = db.Column(db.String(200), nullable=False)
    job_title = db.Column(db.String(255), nullable=True)
    salary = db.Column(db.Numeric(14, 2), nullable=True)
    place_of_assignment = db.Column(db.String(255), nullable=True)
    department = db.Column(db.String(255), nullable=True)
    remark = db.Column(db.String(500), nullable=True)
    is_active = db.Column(db.Boolean, nullable=False, default=True)

    __table_args__ = (
        db.UniqueConstraint("employee_number", "spouse_name", name="uq_spouse_employee_name"),
    )
