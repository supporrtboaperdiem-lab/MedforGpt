from datetime import datetime

from werkzeug.security import check_password_hash
from werkzeug.security import generate_password_hash

from app.extensions import db
from flask_login import UserMixin

class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    username = db.Column(
        db.String(100),
        unique=True,
        nullable=False
    )

    full_name = db.Column(
        db.String(200),
        nullable=False
    )

    email = db.Column(
        db.String(200),
        unique=True,
        nullable=False
    )


    password_hash = db.Column(
        db.String(255),
        nullable=False
    )

    role_id = db.Column(
        db.Integer,
        db.ForeignKey("roles.id"),
        nullable=False
    )

    is_active = db.Column(
        db.Boolean,
        default=True,
        nullable=False
    )

    role_status = db.Column(
        db.String(30),
        nullable=False,
        default="APPROVED"
    )

    role_requested_at = db.Column(
        db.DateTime,
        nullable=True
    )

    role_approved_at = db.Column(
        db.DateTime,
        nullable=True
    )

    role_rejected_at = db.Column(
        db.DateTime,
        nullable=True
    )

    role_approved_by = db.Column(
        db.Integer,
        db.ForeignKey("users.id"),
        nullable=True
    )

    role_rejected_by = db.Column(
        db.Integer,
        db.ForeignKey("users.id"),
        nullable=True
    )

    role_rejection_reason = db.Column(
        db.Text,
        nullable=True
    )

    role_approval_status = db.Column(
        db.String(30),
        nullable=False,
        default="APPROVED"
    )

    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )

    role = db.relationship(
        "Role",
        back_populates="users"
    )

    approver = db.relationship(
        "User",
        foreign_keys=[role_approved_by],
        remote_side=[id],
        post_update=True
    )

    rejector = db.relationship(
        "User",
        foreign_keys=[role_rejected_by],
        remote_side=[id],
        post_update=True
    )

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def verify_password(self, password):
        return check_password_hash(
            self.password_hash,
            password
        )
    def check_password(self, password):
        return check_password_hash(
            self.password_hash,
            password
        )

    def get_id(self):
        return str(self.id)

    @property
    def role_name(self):
        if self.role:
            return self.role.name
        return None

    def has_role(self, role_name):
        if not self.role:
            return False

        return self.role.name.lower() == role_name.lower()

    @property
    def is_admin(self):
        return self.has_role("Administrator")

    @property
    def is_hr(self):
        return self.has_role("HR")

    @property
    def is_medical(self):
        return self.has_role("Medical Officer")

    @property
    def is_employee(self):
        return self.has_role("Employee")

    @property
    def role_requires_approval(self):
        return not self.is_employee

    @property
    def role_is_approved(self):
        return self.role_approval_status == "APPROVED"

    @property
    def role_is_pending(self):
        return self.role_approval_status == "PENDING"

    @property
    def role_is_rejected(self):
        return self.role_approval_status == "REJECTED"

    def approve_role(self, administrator_id):
        self.role_approval_status = "APPROVED"
        self.role_status = "APPROVED"
        self.role_approved_by = administrator_id
        self.role_approved_at = datetime.utcnow()
        self.role_rejected_by = None
        self.role_rejected_at = None
        self.role_rejection_reason = None

    def reject_role(self, administrator_id, reason=None):
        self.role_approval_status = "REJECTED"
        self.role_status = "REJECTED"
        self.role_rejected_by = administrator_id
        self.role_rejected_at = datetime.utcnow()
        self.role_rejection_reason = reason

    def __repr__(self):
        return f"<User {self.username}>"