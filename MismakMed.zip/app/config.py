import os
from pathlib import Path
from dotenv import load_dotenv, dotenv_values

BASE_DIR = Path(__file__).resolve().parent.parent

_ENV_FILE = BASE_DIR / ".env"
load_dotenv(_ENV_FILE)
_DOTENV_VALUES = dotenv_values(_ENV_FILE)

def _env(name, default=""):
    """
    Resolve configuration with OS environment as the authoritative source.

    Precedence:
      1. Non-empty process environment variable (e.g. ~/.bash_profile)
      2. Non-empty value from app/.env (dummy/local fallback)
      3. Supplied default

    This intentionally treats an empty OS variable as unset so a placeholder
    in app/.env cannot accidentally mask a real deployment value, while a
    non-empty OS value always wins over app/.env.
    """
    runtime_value = os.getenv(name)
    if runtime_value is not None and str(runtime_value).strip():
        return str(runtime_value).strip()
    file_value = _DOTENV_VALUES.get(name)
    if file_value is not None and str(file_value).strip():
        return str(file_value).strip()
    return default


def normalize_database_uri(uri):
    """
    Make relative SQLite URLs independent of the shell working directory.

    SQLAlchemy interprets ``sqlite:///instance/medical.db`` relative to the
    current working directory.  That is fragile for Flask/Gunicorn/systemd
    deployments.  Relative SQLite paths are therefore resolved relative to
    the project root (BASE_DIR), while absolute SQLite URLs and non-SQLite
    database URLs are left unchanged.
    """
    value = str(uri or "").strip()

    if not value.startswith("sqlite:///"):
        return value

    # Keep in-memory databases untouched.
    if value in {"sqlite:///:memory:", "sqlite://"}:
        return value

    # sqlite:////absolute/path.db already has four slashes and is absolute.
    if value.startswith("sqlite:////"):
        return value

    relative_path = value[len("sqlite:///"):].split("?", 1)[0]
    query = ""
    if "?" in value:
        query = "?" + value.split("?", 1)[1]

    if not relative_path:
        return value

    absolute_path = (BASE_DIR / relative_path).resolve()
    absolute_path.parent.mkdir(parents=True, exist_ok=True)
    return "sqlite:///" + str(absolute_path) + query


def _env_float(name, default):
    value = _env(name, str(default))
    try:
        return float(value)
    except (TypeError, ValueError):
        raise ValueError(f"Invalid numeric environment setting {name}={value!r}")


def _env_bool(name, default=False):
    value = _env(name, "true" if default else "false").lower()
    return value in {"1", "true", "yes", "on"}


class Config:
    SECRET_KEY = _env("SECRET_KEY", "dev-secret-key")

    SQLALCHEMY_DATABASE_URI = normalize_database_uri(
        _env(
            "DATABASE_URL",
            "sqlite:///instance/medical.db"
        )
    )

    SQLALCHEMY_TRACK_MODIFICATIONS = False

    UPLOAD_FOLDER = _env(
        "UPLOAD_FOLDER",
        str(BASE_DIR / "uploads")
    )

    EXPORT_FOLDER = _env(
        "EXPORT_FOLDER",
        str(BASE_DIR / "exports")
    )
    EMPLOYEE_DIRECTORY_FOLDER = _env(
        "EMPLOYEE_DIRECTORY_FOLDER",
        str(BASE_DIR / "uploads" / "employee_directory")
    )

    LOG_LEVEL = _env("LOG_LEVEL", "INFO")

    # Local multimodal AI server used for medical claim extraction.
    # This URL is intentionally exposed here so administrators can edit it
    # easily without changing application logic.
    # =========================================================================
    # AI CONNECTION — OS environment is authoritative.
    # Set OLLAMA_SERVER_URL and OLLAMA_API_KEY in ~/.bash_profile (or the
    # process environment). app/.env is only a dummy/local fallback.
    # =========================================================================
    OLLAMA_SERVER_URL = _env("OLLAMA_SERVER_URL", "")
    OLLAMA_API_KEY = _env("OLLAMA_API_KEY", "")
    # Lite mode uses the organization's LAN llama.cpp server configured for CPU-only inference.
    # Override OLLAMA_CPU_SERVER_URL in the process environment or app/.env if its address changes.
    OLLAMA_CPU_SERVER_URL = _env("OLLAMA_CPU_SERVER_URL", "http://10.101.2.245:8080")
    OLLAMA_CPU_API_KEY = _env("OLLAMA_CPU_API_KEY", "")
    OLLAMA_MODEL = _env(
        "OLLAMA_MODEL",
        "gemma-4-26B-A4B-it-Q4_K_M.gguf"
    )
    OLLAMA_HEALTH_TIMEOUT_SECONDS = float(
        _env("OLLAMA_HEALTH_TIMEOUT_SECONDS", "2")
    )
    OLLAMA_CONNECT_TIMEOUT_SECONDS = float(
        _env("OLLAMA_CONNECT_TIMEOUT_SECONDS", "3")
    )
    OLLAMA_READ_TIMEOUT_SECONDS = float(
        _env("OLLAMA_READ_TIMEOUT_SECONDS", "0")
    )

    # Parallel receipt extraction. Keep this below the concurrency supported by
    # the Ollama host/GPU; 4 is a safe default and can be overridden in the
    # deployment environment without changing application code.
    OLLAMA_MAX_CONCURRENT_REQUESTS = int(
        _env("OLLAMA_MAX_CONCURRENT_REQUESTS", "8")
    )
    # Structured receipt JSON is compact; keep the output budget bounded so
    # high-parallel llama.cpp slots retain enough context for the image prompt.
    OLLAMA_MAX_OUTPUT_TOKENS = int(
        _env("OLLAMA_MAX_OUTPUT_TOKENS", "768")
    )

    # WebRTC ICE configuration. Keep TURN credentials out of source code.
    # Example:
    # WEBRTC_STUN_URLS=stun:stun.l.google.com:19302,stun:stun.cloudflare.com:3478
    # WEBRTC_TURN_URLS=turn:10.5.36.120:3478?transport=udp,turn:10.5.36.120:3478?transport=tcp
    # WEBRTC_TURN_USERNAME=boa
    # WEBRTC_TURN_CREDENTIAL=change-me
    WEBRTC_STUN_URLS = _env(
        "WEBRTC_STUN_URLS",
        "stun:stun.l.google.com:19302,stun:stun.cloudflare.com:3478"
    )
    WEBRTC_TURN_URLS = _env("WEBRTC_TURN_URLS", "")
    WEBRTC_TURN_USERNAME = _env("WEBRTC_TURN_USERNAME", "")
    WEBRTC_TURN_CREDENTIAL = _env("WEBRTC_TURN_CREDENTIAL", "")


class DevelopmentConfig(Config):
    DEBUG = True


class TestingConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"


class ProductionConfig(Config):
    DEBUG = False


config_by_name = {
    "development": DevelopmentConfig,
    "testing": TestingConfig,
    "production": ProductionConfig,
}