from app.extensions import db
from app.models.employee import Employee


class EmployeeRepository:
    @staticmethod
    def get_all():
        return Employee.query.order_by(Employee.created_at.desc()).all()

    @staticmethod
    def get_by_code(employee_code):
        return Employee.query.filter_by(employee_code=employee_code).first()

    @staticmethod
    def get_by_employee_id(employee_id):
        return Employee.query.filter_by(employee_id=employee_id).all()

    @staticmethod
    def get_by_employee_number(employee_number):
        return Employee.query.filter_by(employee_number=employee_number).all()

    @staticmethod
    def get_by_exact_name(full_name):
        return Employee.query.filter_by(full_name=full_name).all()

    @staticmethod
    def create(employee_code, full_name, **fields):
        employee = Employee(employee_code=employee_code, full_name=full_name, **fields)
        db.session.add(employee)
        db.session.commit()
        return employee
