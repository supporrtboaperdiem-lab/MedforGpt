from app.extensions import db

from app.models.claim import (
    MedicalClaim,
    MedicalClaimItem,
    MedicalClaimReceipt
)


class ClaimRepository:

    @staticmethod
    def get_all():
        return (
            MedicalClaim.query
            .order_by(MedicalClaim.created_at.desc())
            .all()
        )

    @staticmethod
    def get_by_submitter(user_id):
        return (
            MedicalClaim.query
            .filter(MedicalClaim.submitted_by_id == user_id)
            .order_by(MedicalClaim.created_at.desc())
            .all()
        )

    @staticmethod
    def get_by_id(claim_id):
        return MedicalClaim.query.get(claim_id)

    @staticmethod
    def create_claim(
        institution_id,
        patient_name,
        receipt_file_path,
        employee_id=None,
        submitted_by_id=None,
        category="NORMAL",
        beneficiary_type="EMPLOYEE",
        beneficiary_name=None,
        employee_owner_name=None,
        coverage_percentage=100,
        optics_lens_type=None,
        optics_frame_price=None,
        optics_lens_price=None,
        optics_frame_reimbursable=None,
        optics_lens_reimbursable=None,
        optics_reimbursable_total=None,
    ):
        claim = MedicalClaim(
            employee_id=employee_id,
            submitted_by_id=submitted_by_id,
            institution_id=institution_id,
            patient_name=patient_name,
            category=category,
            receipt_file_path=receipt_file_path,
            status="PENDING_REVIEW",
            beneficiary_type=beneficiary_type,
            beneficiary_name=beneficiary_name,
            employee_owner_name=employee_owner_name,
            coverage_percentage=coverage_percentage,
            optics_lens_type=optics_lens_type,
            optics_frame_price=optics_frame_price,
            optics_lens_price=optics_lens_price,
            optics_frame_reimbursable=optics_frame_reimbursable,
            optics_lens_reimbursable=optics_lens_reimbursable,
            optics_reimbursable_total=optics_reimbursable_total,
        )
        db.session.add(claim)
        db.session.flush()
        return claim


    @staticmethod
    def create_receipt(claim_id, file_path, original_filename, ai_extraction_json=None, receipt_date=None, uploaded_at=None, file_sha256=None, image_phash=None, receipt_metadata_fingerprint=None, receipt_metadata_key=None):
        receipt = MedicalClaimReceipt(
            claim_id=claim_id,
            file_path=file_path,
            original_filename=original_filename,
            receipt_date=receipt_date,
            uploaded_at=uploaded_at,
            file_sha256=file_sha256,
            image_phash=image_phash,
            receipt_metadata_fingerprint=receipt_metadata_fingerprint,
            receipt_metadata_key=receipt_metadata_key,
            ai_extraction_json=ai_extraction_json,
        )
        db.session.add(receipt)
        db.session.flush()
        return receipt

    @staticmethod
    def create_item(
        claim_id,
        service_name,
        receipt_price,
        item_category="MEDICAL_SERVICE",
        unit_price=None,
        receipt_id=None,
        employee_id=None,
        institution_id=None,
        approved_price=None,
        difference=None,
        validation_status="NEEDS_REVIEW",
        service_description=None,
        reimbursable_amount=0,
    ):
        item = MedicalClaimItem(
            claim_id=claim_id,
            service_name=service_name,
            item_category=item_category,
            unit_price=unit_price,
            receipt_id=receipt_id,
            employee_id=employee_id,
            institution_id=institution_id,
            service_description=service_description,
            receipt_price=receipt_price,
            approved_price=approved_price,
            difference=difference,
            validation_status=validation_status,
            reimbursable_amount=reimbursable_amount,
        )
        db.session.add(item)
        return item

    @staticmethod
    def approve_claim(claim):
        claim.status = "APPROVED"
        db.session.commit()
        return claim

    @staticmethod
    def reject_claim(claim):
        claim.status = "REJECTED"
        db.session.commit()
        return claim
