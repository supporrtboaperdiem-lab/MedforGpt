from app.models.price_list import PriceListItem
from app.models.price_list_batch import PriceListBatch


class ActivePriceRepository:
    @staticmethod
    def _active_batch_query():
        return PriceListBatch.query.filter_by(
            status="APPROVED",
            is_active=True
        )

    @staticmethod
    def has_any_active_price_list():
        return ActivePriceRepository._active_batch_query().first() is not None

    @staticmethod
    def get_active_price(institution_id, service_name):
        active_batch = PriceListBatch.query.filter_by(
            institution_id=institution_id,
            status="APPROVED",
            is_active=True
        ).first()

        if not active_batch:
            return None

        return PriceListItem.query.filter_by(
            batch_id=active_batch.id,
            service_name=service_name
        ).first()

    @staticmethod
    def get_active_batch(institution_id):
        return PriceListBatch.query.filter_by(
            institution_id=institution_id,
            status="APPROVED",
            is_active=True
        ).first()

    @staticmethod
    def get_active_institution_ids():
        return [
            row[0]
            for row in (
                ActivePriceRepository._active_batch_query()
                .with_entities(PriceListBatch.institution_id)
                .distinct()
                .all()
            )
        ]
