"""Development HTTPS launcher for BOA Medical Reimbursement System.

Run from the project root with:
    python -m app.dev_https

The Flask development server creates a temporary self-signed certificate.
For a phone on the same Wi-Fi, open the HTTPS URL printed by this script and
proceed past the certificate warning before granting camera/microphone access.
For production, use a trusted certificate/reverse proxy instead.
"""
import os

from app import create_app


app = create_app()

if __name__ == "__main__":
    host = os.getenv("BOA_HOST", "0.0.0.0")
    port = int(os.getenv("BOA_PORT", "5000"))
    app.run(
        host=host,
        port=port,
        debug=True,
        ssl_context="adhoc",
        threaded=True,
    )
