
## AI multi-employee medical claim workflow

The claim submission page now requires only the claim category and receipt files. The healthcare institution and employee are derived from each receipt by the local multimodal Gemma/llama.cpp service.

### Employee directory

HR or an administrator can open **Employee Directory** and import the authoritative `.xlsx` employee file. The importer stores Employee ID, Employee Number, name, Department, Manager, Office and the other supplied directory fields. Employee ID is the primary exact identifier; when a receipt supplies organizational fields, they must agree with the imported record.

### Multiple employees in one submission

One submission may contain multiple receipts for the same employee or different employees. Each extracted expense item is linked to its matched employee and source receipt. The claim review page groups/identifies all matched employees.

### Normal price-list matching

For Normal claims the receipt AI must provide a unit price when visible. Matching uses the approved price list's unit price as the primary matching key, with the service name used to disambiguate when multiple services share the same price. The extracted unit price is retained on each claim item.

### HR claim editing

While a claim is pending HR review, HR can manually edit an item's Category, Service / Drug / Material, description, Unit Price and Line Amount. Saving an edited Normal item recalculates the approved price, difference, validation status and reimbursable amount. HR can also remove an item.

PaddleOCR remains removed; claim receipt extraction continues to use the local Gemma/llama.cpp multimodal engine only.


## Bundled Employee Directory
The supplied `data/employee_directory/bo_ldap_users.xlsx` is included with the full project as the authoritative employee-directory source. On a fresh installation, the application automatically imports it when the Employee table is empty. Existing installations are not automatically overwritten; HR/admin can refresh the directory through **Employee Directory -> Import Employee Directory**.

The receipt workflow uses the directory to resolve employees and authoritative department, manager, office, Employee ID, and Employee Number data. A receipt must resolve to exactly one directory employee before its claim item is accepted.

### Intelligent Employee Matching
Employee identification now uses a multi-signal fuzzy scoring engine rather than exact-name matching alone. It combines whole-name similarity, token-set/token-order similarity, per-token edit similarity, and optional employee number/department/office/manager evidence. This is designed to tolerate common receipt/AI transcription errors such as duplicated letters, missing letters, swapped tokens, spacing differences, and minor spelling changes (for example `Shiimelis` vs `Shimelis`). Hard Employee ID matches remain authoritative, while fuzzy matches require a high confidence score and a safety margin over the next-best directory candidate.

## Smart human-assisted receipt matching

When AI cannot uniquely match a healthcare institution or employee to master data, claim submission no longer fails immediately. The application opens a glassmorphism review dialog with ranked suggestions. Institutions can be searched live, and employees can be searched by name, Employee ID, Employee Number, department, or office. A receipt employee can also be resolved directly by entering the exact Employee Number. The pending receipt files and AI extraction are retained for up to one hour while the user completes the match, so the receipts do not need to be uploaded again.

## Claim submission diagnostics
Claim submission now emits `[CLAIM][TRACE]` diagnostics to the Flask console and `logs/app.log`, including receipt save, AI extraction, employee/institution matching, human-resolution selections, DB flush/commit, claim ID verification, and final route result. This is intended to make submission persistence failures immediately traceable.

## Environment configuration (OS environment is authoritative)

This application is designed so deployment secrets and changing AI endpoints
are supplied by the operating-system environment. `app/.env` is only a safe
dummy/local fallback template. Non-empty OS variables always take precedence.

For a shell-based deployment, set the values in `~/.bash_profile`, then run:

```bash
source ~/.bash_profile
```

For Kaggle/Cloudflare AI access, only these values need to change when the
Quick Tunnel URL changes:

```bash
export OLLAMA_SERVER_URL='https://YOUR-TUNNEL.trycloudflare.com/v1/chat/completions'
export OLLAMA_API_KEY='YOUR_AI_API_KEY'
export OLLAMA_MODEL='gemma-4-26B-A4B-it-Q4_K_M.gguf'
```

Other application settings such as `SECRET_KEY`, `DATABASE_URL`, LDAP and
mail credentials follow the same OS-first configuration model. Do not put
real credentials in `app/.env`. Restart the Flask/Gunicorn process after
changing environment variables so the process receives the new values.

