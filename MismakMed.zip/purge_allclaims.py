import os
import shutil
import sqlite3
from datetime import datetime


DB_PATH = "/u01/Medical/instance/medical.db"


def backup_database():
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{DB_PATH}.before_claim_cleanup_{timestamp}"

    shutil.copy2(DB_PATH, backup_path)

    print(f"[OK] Database backup created:")
    print(f"     {backup_path}")

    return backup_path


def get_tables(conn):
    rows = conn.execute("""
        SELECT name
        FROM sqlite_master
        WHERE type = 'table'
          AND name NOT LIKE 'sqlite_%'
        ORDER BY name
    """).fetchall()

    return [row[0] for row in rows]


def get_foreign_keys(conn, table):
    return conn.execute(
        f'PRAGMA foreign_key_list("{table}")'
    ).fetchall()


def count_rows(conn, table):
    try:
        return conn.execute(
            f'SELECT COUNT(*) FROM "{table}"'
        ).fetchone()[0]
    except sqlite3.Error:
        return 0


def find_claim_related_tables(conn):
    """
    Discover tables that either:
      - are named like claim tables
      - contain a FK pointing to claims
      - contain claim_id
    """

    tables = get_tables(conn)

    related = set()

    for table in tables:
        lower = table.lower()

        if "claim" in lower:
            related.add(table)

        # Inspect columns
        try:
            columns = conn.execute(
                f'PRAGMA table_info("{table}")'
            ).fetchall()

            column_names = {
                str(row[1]).lower()
                for row in columns
            }

            if "claim_id" in column_names:
                related.add(table)

        except sqlite3.Error:
            pass

        # Inspect FK relationships
        try:
            fks = get_foreign_keys(conn, table)

            for fk in fks:
                # PRAGMA foreign_key_list:
                # (id, seq, table, from, to, on_update, on_delete, match)
                referenced_table = str(fk[2]).lower()

                if "claim" in referenced_table:
                    related.add(table)

        except sqlite3.Error:
            pass

    return sorted(related)


def clean_claims():
    if not os.path.isfile(DB_PATH):
        raise FileNotFoundError(
            f"Database not found: {DB_PATH}"
        )

    print("=" * 70)
    print("MEDICAL REIMBURSEMENT - CLAIM CLEANUP")
    print("=" * 70)
    print()
    print(f"Database: {DB_PATH}")
    print()

    # ------------------------------------------------------------
    # SAFETY BACKUP
    # ------------------------------------------------------------
    backup_path = backup_database()

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row

    try:
        conn.execute("PRAGMA foreign_keys = OFF")

        tables = get_tables(conn)
        claim_tables = find_claim_related_tables(conn)

        print()
        print("Claim-related tables discovered:")
        print("-" * 70)

        for table in claim_tables:
            print(
                f"{table:<45} "
                f"{count_rows(conn, table):>10} rows"
            )

        print()

        # --------------------------------------------------------
        # Ask for explicit confirmation
        # --------------------------------------------------------
        confirmation = input(
            "TYPE DELETE ALL CLAIMS to continue: "
        ).strip()

        if confirmation != "DELETE ALL CLAIMS":
            print()
            print("[CANCELLED] Nothing was deleted.")
            return

        print()
        print("[INFO] Starting cleanup...")

        # --------------------------------------------------------
        # Delete child/claim-related tables first.
        #
        # Tables containing claim_id should normally be deleted
        # before the claims table itself.
        # --------------------------------------------------------
        ordered = []

        for table in claim_tables:
            if table.lower() != "claims":
                ordered.append(table)

        # Put claims last.
        if "claims" in claim_tables:
            ordered.append("claims")

        # Case-insensitive fallback for unusual capitalization.
        if "claims" not in claim_tables:
            for table in claim_tables:
                if table.lower() == "claims":
                    ordered.append(table)

        deleted = {}

        for table in ordered:
            before = count_rows(conn, table)

            if before == 0:
                deleted[table] = 0
                continue

            conn.execute(f'DELETE FROM "{table}"')

            deleted[table] = before

            print(
                f"[DELETED] {table:<45} "
                f"{before:>10} rows"
            )

        # --------------------------------------------------------
        # Reset SQLite AUTOINCREMENT counters for deleted tables.
        # --------------------------------------------------------
        try:
            for table in ordered:
                conn.execute(
                    "DELETE FROM sqlite_sequence WHERE name = ?",
                    (table,)
                )
        except sqlite3.Error:
            pass

        conn.commit()

        # --------------------------------------------------------
        # Verify
        # --------------------------------------------------------
        print()
        print("[VERIFY]")
        print("-" * 70)

        remaining = False

        for table in ordered:
            rows = count_rows(conn, table)

            print(
                f"{table:<45} "
                f"{rows:>10} remaining"
            )

            if rows:
                remaining = True

        print()
        print("=" * 70)

        if remaining:
            print(
                "[WARNING] Some claim-related records remain."
            )
        else:
            print(
                "[SUCCESS] All discovered claim records were removed."
            )

        print("=" * 70)
        print()
        print(f"Backup kept at:")
        print(f"  {backup_path}")

    except Exception:
        conn.rollback()
        print()
        print("[ERROR] Cleanup failed.")
        print("[INFO] Transaction was rolled back.")
        raise

    finally:
        conn.close()


if __name__ == "__main__":
    clean_claims()