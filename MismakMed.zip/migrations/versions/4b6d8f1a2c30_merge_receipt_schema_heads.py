"""Merge the two existing migration heads before receipt fraud changes.

Revision ID: 4b6d8f1a2c30
Revises: e91b7c2d4f10, f2a8b7c9d001
"""
from alembic import op

revision = "4b6d8f1a2c30"
down_revision = ("e91b7c2d4f10", "f2a8b7c9d001")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
