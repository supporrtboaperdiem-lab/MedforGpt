"""Add optics lifetime policy fields and allow optics claims without institutions.
Revision ID: f2a8b7c9d001
Revises: c4f7d2e8a901
"""
from alembic import op
import sqlalchemy as sa
revision = "f2a8b7c9d001"
down_revision = "c4f7d2e8a901"
branch_labels = None
depends_on = None

def upgrade():
    with op.batch_alter_table("medical_claims", schema=None) as batch_op:
        batch_op.alter_column("institution_id", existing_type=sa.Integer(), nullable=True)
        batch_op.add_column(sa.Column("optics_lens_type", sa.String(30), nullable=True))
        batch_op.add_column(sa.Column("optics_frame_price", sa.Numeric(12,2), nullable=True))
        batch_op.add_column(sa.Column("optics_lens_price", sa.Numeric(12,2), nullable=True))
        batch_op.add_column(sa.Column("optics_frame_reimbursable", sa.Numeric(12,2), nullable=True))
        batch_op.add_column(sa.Column("optics_lens_reimbursable", sa.Numeric(12,2), nullable=True))
        batch_op.add_column(sa.Column("optics_reimbursable_total", sa.Numeric(12,2), nullable=True))
    with op.batch_alter_table("medical_claim_items", schema=None) as batch_op:
        batch_op.add_column(sa.Column("institution_id", sa.Integer(), nullable=True))
        batch_op.create_index("ix_medical_claim_items_institution_id", ["institution_id"], unique=False)
        batch_op.create_foreign_key("fk_medical_claim_items_institution_id", "institutions", ["institution_id"], ["id"])

def downgrade():
    with op.batch_alter_table("medical_claim_items", schema=None) as batch_op:
        batch_op.drop_constraint("fk_medical_claim_items_institution_id", type="foreignkey")
        batch_op.drop_index("ix_medical_claim_items_institution_id")
        batch_op.drop_column("institution_id")
    with op.batch_alter_table("medical_claims", schema=None) as batch_op:
        batch_op.drop_column("optics_reimbursable_total")
        batch_op.drop_column("optics_lens_reimbursable")
        batch_op.drop_column("optics_frame_reimbursable")
        batch_op.drop_column("optics_lens_price")
        batch_op.drop_column("optics_frame_price")
        batch_op.drop_column("optics_lens_type")
        batch_op.alter_column("institution_id", existing_type=sa.Integer(), nullable=False)
