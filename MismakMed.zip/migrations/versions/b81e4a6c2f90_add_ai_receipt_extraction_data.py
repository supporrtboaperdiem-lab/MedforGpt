"""Store structured multimodal AI extraction data on receipts.

Revision ID: b81e4a6c2f90
Revises: 7c4f1b2a9d11
"""
from alembic import op
import sqlalchemy as sa

revision = "b81e4a6c2f90"
down_revision = "7c4f1b2a9d11"
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table("medical_claim_receipts", schema=None) as batch_op:
        batch_op.add_column(sa.Column("ai_extraction_json", sa.Text(), nullable=True))


def downgrade():
    with op.batch_alter_table("medical_claim_receipts", schema=None) as batch_op:
        batch_op.drop_column("ai_extraction_json")
