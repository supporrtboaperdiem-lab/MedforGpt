"""Add role approval fields to users

Revision ID: de5c83df3485
Revises: 3a23566159dc
Create Date: 2026-08-10 11:18:53.743072
"""

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "de5c83df3485"
down_revision = "3a23566159dc"
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table("users", schema=None) as batch_op:
        batch_op.add_column(
            sa.Column(
                "role_status",
                sa.String(length=50),
                nullable=False,
                server_default="ACTIVE",
            )
        )

        batch_op.add_column(
            sa.Column(
                "role_requested_at",
                sa.DateTime(),
                nullable=True,
            )
        )

        batch_op.add_column(
            sa.Column(
                "role_approved_at",
                sa.DateTime(),
                nullable=True,
            )
        )

        batch_op.add_column(
            sa.Column(
                "role_rejected_at",
                sa.DateTime(),
                nullable=True,
            )
        )

        batch_op.add_column(
            sa.Column(
                "role_approved_by",
                sa.Integer(),
                nullable=True,
            )
        )

        batch_op.add_column(
            sa.Column(
                "role_rejected_by",
                sa.Integer(),
                nullable=True,
            )
        )

        batch_op.add_column(
            sa.Column(
                "role_rejection_reason",
                sa.Text(),
                nullable=True,
            )
        )

        batch_op.create_foreign_key(
            "fk_users_role_approved_by",
            "users",
            ["role_approved_by"],
            ["id"],
        )

        batch_op.create_foreign_key(
            "fk_users_role_rejected_by",
            "users",
            ["role_rejected_by"],
            ["id"],
        )


def downgrade():
    with op.batch_alter_table("users", schema=None) as batch_op:
        batch_op.drop_constraint(
            "fk_users_role_rejected_by",
            type_="foreignkey",
        )

        batch_op.drop_constraint(
            "fk_users_role_approved_by",
            type_="foreignkey",
        )

        batch_op.drop_column("role_rejection_reason")
        batch_op.drop_column("role_rejected_by")
        batch_op.drop_column("role_approved_by")
        batch_op.drop_column("role_rejected_at")
        batch_op.drop_column("role_approved_at")
        batch_op.drop_column("role_requested_at")
        batch_op.drop_column("role_status")