"""Add receipt upload timestamps and fraud/duplicate fingerprints.

Revision ID: 5c7e9a2b4d11
Revises: 4b6d8f1a2c30
"""
from alembic import op
import sqlalchemy as sa

revision = "5c7e9a2b4d11"
down_revision = "4b6d8f1a2c30"
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table("medical_claim_receipts", schema=None) as batch_op:
        batch_op.add_column(sa.Column("uploaded_at", sa.DateTime(), nullable=True))
        batch_op.add_column(sa.Column("file_sha256", sa.String(length=64), nullable=True))
        batch_op.add_column(sa.Column("image_phash", sa.String(length=64), nullable=True))
        batch_op.add_column(sa.Column("receipt_metadata_fingerprint", sa.String(length=64), nullable=True))
        batch_op.add_column(sa.Column("receipt_metadata_key", sa.String(length=500), nullable=True))
        batch_op.create_index("ix_medical_claim_receipts_uploaded_at", ["uploaded_at"], unique=False)
        batch_op.create_index("ix_medical_claim_receipts_file_sha256", ["file_sha256"], unique=False)
        batch_op.create_index("ix_medical_claim_receipts_image_phash", ["image_phash"], unique=False)
        batch_op.create_index("ix_medical_claim_receipts_receipt_metadata_fingerprint", ["receipt_metadata_fingerprint"], unique=False)
        batch_op.create_index("ix_medical_claim_receipts_receipt_metadata_key", ["receipt_metadata_key"], unique=False)

    # Exact-file hashes are unique when present. Legacy NULLs remain valid.
    op.execute(
        "CREATE UNIQUE INDEX IF NOT EXISTS uq_medical_claim_receipts_file_sha256 "
        "ON medical_claim_receipts(file_sha256) WHERE file_sha256 IS NOT NULL"
    )


def downgrade():
    op.execute("DROP INDEX IF EXISTS uq_medical_claim_receipts_file_sha256")
    with op.batch_alter_table("medical_claim_receipts", schema=None) as batch_op:
        batch_op.drop_index("ix_medical_claim_receipts_receipt_metadata_key")
        batch_op.drop_index("ix_medical_claim_receipts_receipt_metadata_fingerprint")
        batch_op.drop_index("ix_medical_claim_receipts_image_phash")
        batch_op.drop_index("ix_medical_claim_receipts_file_sha256")
        batch_op.drop_index("ix_medical_claim_receipts_uploaded_at")
        batch_op.drop_column("receipt_metadata_key")
        batch_op.drop_column("receipt_metadata_fingerprint")
        batch_op.drop_column("image_phash")
        batch_op.drop_column("file_sha256")
        batch_op.drop_column("uploaded_at")
