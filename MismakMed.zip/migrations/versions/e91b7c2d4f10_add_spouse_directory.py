"""add dedicated spouse directory

Revision ID: e91b7c2d4f10
Revises: c4f7d2e8a901
"""
from alembic import op
import sqlalchemy as sa

revision = "e91b7c2d4f10"
down_revision = "c4f7d2e8a901"
branch_labels = None
dependencies = None

def upgrade():
    op.create_table(
        "spouse_directory",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
        sa.Column("employee_number", sa.String(100), nullable=False),
        sa.Column("employee_name", sa.String(200), nullable=False),
        sa.Column("spouse_name", sa.String(200), nullable=False),
        sa.Column("job_title", sa.String(255)),
        sa.Column("salary", sa.Numeric(14, 2)),
        sa.Column("place_of_assignment", sa.String(255)),
        sa.Column("department", sa.String(255)),
        sa.Column("remark", sa.String(500)),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.UniqueConstraint("employee_number", "spouse_name", name="uq_spouse_employee_name"),
    )
    op.create_index("ix_spouse_directory_employee_number", "spouse_directory", ["employee_number"])

def downgrade():
    op.drop_index("ix_spouse_directory_employee_number", table_name="spouse_directory")
    op.drop_table("spouse_directory")
