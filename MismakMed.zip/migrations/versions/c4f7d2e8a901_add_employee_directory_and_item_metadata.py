"""Add employee directory fields and expense-level matching metadata.
Revision ID: c4f7d2e8a901
Revises: b81e4a6c2f90
"""
from alembic import op
import sqlalchemy as sa
revision = "c4f7d2e8a901"
down_revision = "b81e4a6c2f90"
branch_labels = None
depends_on = None

def upgrade():
    employee_cols = {
        "employee_id": sa.Column("employee_id", sa.String(100)), "employee_number": sa.Column("employee_number", sa.String(100)),
        "username": sa.Column("username", sa.String(150)), "user_principal_name": sa.Column("user_principal_name", sa.String(255)),
        "email": sa.Column("email", sa.String(255)), "first_name": sa.Column("first_name", sa.String(100)),
        "middle_name": sa.Column("middle_name", sa.String(100)), "last_name": sa.Column("last_name", sa.String(100)),
        "job_title": sa.Column("job_title", sa.String(255)), "department": sa.Column("department", sa.String(255)),
        "company": sa.Column("company", sa.String(255)), "office": sa.Column("office", sa.String(255)),
        "division": sa.Column("division", sa.String(255)), "employee_type": sa.Column("employee_type", sa.String(100)),
        "mobile": sa.Column("mobile", sa.String(100)), "telephone": sa.Column("telephone", sa.String(100)),
        "business_address": sa.Column("business_address", sa.String(500)), "city": sa.Column("city", sa.String(100)),
        "state_region": sa.Column("state_region", sa.String(100)), "country": sa.Column("country", sa.String(100)),
        "manager": sa.Column("manager", sa.String(255)), "description": sa.Column("description", sa.Text()),
    }
    with op.batch_alter_table("employees") as batch:
        for c in employee_cols.values(): batch.add_column(c)
    with op.batch_alter_table("medical_claim_items") as batch:
        batch.add_column(sa.Column("item_category", sa.String(100), server_default="MEDICAL_SERVICE"))
        batch.add_column(sa.Column("unit_price", sa.Numeric(12,2), nullable=True))
        batch.add_column(sa.Column("employee_id", sa.Integer(), nullable=True))
        batch.add_column(sa.Column("receipt_id", sa.Integer(), nullable=True))

def downgrade():
    with op.batch_alter_table("medical_claim_items") as batch:
        batch.drop_column("receipt_id"); batch.drop_column("employee_id"); batch.drop_column("unit_price"); batch.drop_column("item_category")
    with op.batch_alter_table("employees") as batch:
        for name in ["description","manager","country","state_region","city","business_address","telephone","mobile","employee_type","division","office","company","department","job_title","last_name","middle_name","first_name","email","user_principal_name","username","employee_number","employee_id"]: batch.drop_column(name)
