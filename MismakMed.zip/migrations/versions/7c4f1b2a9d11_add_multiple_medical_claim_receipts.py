"""Add multiple receipt files per medical claim.

Revision ID: 7c4f1b2a9d11
Revises: de5c83df3485
"""
from alembic import op
import sqlalchemy as sa

revision = "7c4f1b2a9d11"
down_revision = "de5c83df3485"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "medical_claim_receipts",
        sa.Column("claim_id", sa.Integer(), nullable=False),
        sa.Column("file_path", sa.String(length=500), nullable=False),
        sa.Column("original_filename", sa.String(length=255), nullable=False),
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(["claim_id"], ["medical_claims.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    with op.batch_alter_table("medical_claim_receipts", schema=None) as batch_op:
        batch_op.create_index(
            batch_op.f("ix_medical_claim_receipts_claim_id"),
            ["claim_id"],
            unique=False,
        )


def downgrade():
    with op.batch_alter_table("medical_claim_receipts", schema=None) as batch_op:
        batch_op.drop_index(batch_op.f("ix_medical_claim_receipts_claim_id"))
    op.drop_table("medical_claim_receipts")
