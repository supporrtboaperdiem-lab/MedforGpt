
#!/usr/bin/env python3

import os
import re
import sys
import sqlite3
from datetime import datetime
from difflib import SequenceMatcher
from collections import defaultdict, deque

DB_PATH = "/u01/Medical/instance/medical.db"
MIN_MATCH_SCORE = 0.55


def qi(name):
    return '"' + str(name).replace('"', '""') + '"'


def normalize(value):
    value = str(value or "").lower().strip()
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return " ".join(value.split())


def similarity(a, b):
    a, b = normalize(a), normalize(b)

    if not a or not b:
        return 0.0
    if a == b:
        return 1.0

    sequence = SequenceMatcher(None, a, b).ratio()
    ta, tb = set(a.split()), set(b.split())
    token = len(ta & tb) / max(len(ta | tb), 1)

    if a in b or b in a:
        sequence = max(sequence, 0.90)

    return max(sequence, token)


def get_tables(conn):
    return [
        r[0] for r in conn.execute("""
            SELECT name
            FROM sqlite_master
            WHERE type = 'table'
              AND name NOT LIKE 'sqlite_%'
            ORDER BY name
        """).fetchall()
    ]


def get_table_info(conn, table):
    return conn.execute(
        f"PRAGMA table_info({qi(table)})"
    ).fetchall()


def get_columns(conn, table):
    return [r[1] for r in get_table_info(conn, table)]


def get_primary_key(conn, table):
    return [
        r[1] for r in sorted(
            (r for r in get_table_info(conn, table) if r[5] > 0),
            key=lambda r: r[5]
        )
    ]


def backup_database():
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = (
        f"{DB_PATH}.before_institution_delete_{timestamp}"
    )

    if os.path.exists(backup_path):
        raise FileExistsError(backup_path)

    source = sqlite3.connect(DB_PATH, timeout=60)
    destination = sqlite3.connect(backup_path)

    try:
        source.backup(destination)
    finally:
        destination.close()
        source.close()

    print(f"[BACKUP] {backup_path}")
    return backup_path


def find_institution(conn, requested_name):
    name_columns = {
        "name", "institution_name", "title",
        "facility_name", "organization_name",
        "organisation_name",
    }

    matches = []

    for table in get_tables(conn):
        if not any(word in table.lower() for word in (
            "institution", "facility", "hospital",
            "clinic", "organization", "organisation"
        )):
            continue

        for column in get_columns(conn, table):
            if column.lower() not in name_columns:
                continue

            cursor = conn.execute(f"SELECT * FROM {qi(table)}")
            names = [d[0] for d in cursor.description]

            for values in cursor.fetchall():
                record = dict(zip(names, values))
                actual = record.get(column)

                if actual is None:
                    continue

                score = similarity(requested_name, actual)

                if score < MIN_MATCH_SCORE:
                    continue

                pk = get_primary_key(conn, table)
                identity = (
                    tuple(record[c] for c in pk)
                    if pk else tuple(sorted(record.items()))
                )

                matches.append({
                    "table": table,
                    "record": record,
                    "name": str(actual),
                    "score": score,
                    "identity": identity,
                })

    unique = {}

    for item in matches:
        key = (item["table"], item["identity"])
        if key not in unique or item["score"] > unique[key]["score"]:
            unique[key] = item

    matches = sorted(
        unique.values(), key=lambda item: item["score"],
        reverse=True
    )

    if not matches:
        return None

    best = matches[0]

    if len(matches) > 1:
        second = matches[1]
        different = (
            best["table"] != second["table"]
            or best["identity"] != second["identity"]
        )

        if different and best["score"] - second["score"] < 0.12:
            print("\n[AMBIGUOUS] Possible matches:")

            for item in matches[:10]:
                print(
                    f"  {item['name']} | {item['table']} "
                    f"| score={item['score']:.2f}"
                )

            raise RuntimeError(
                "Ambiguous institution name. Use a more distinctive name."
            )

    return best


def foreign_key_groups(conn, table):
    rows = conn.execute(
        f"PRAGMA foreign_key_list({qi(table)})"
    ).fetchall()

    groups = defaultdict(list)

    for row in rows:
        groups[row[0]].append({
            "seq": row[1],
            "parent": row[2],
            "child_column": row[3],
            "parent_column": row[4],
        })

    return [
        sorted(group, key=lambda item: item["seq"])
        for group in groups.values()
    ]


def parent_column(conn, table, fk):
    if fk["parent_column"]:
        return fk["parent_column"]

    pk = get_primary_key(conn, table)

    if len(pk) != 1:
        raise RuntimeError(f"Cannot resolve parent key for {table}")

    return pk[0]


def identity_for(conn, table, record):
    pk = get_primary_key(conn, table)

    if pk:
        return ("pk", tuple(record[c] for c in pk))

    if "__purge_rowid__" in record:
        return ("rowid", record["__purge_rowid__"])

    raise RuntimeError(f"Cannot safely identify a row in {table}")


def matching_children(conn, child_table, group, parent_record):
    conditions, params = [], []

    for fk in group:
        column = parent_column(conn, fk["parent"], fk)
        value = parent_record.get(column)

        if value is None:
            return []

        conditions.append(f"{qi(fk['child_column'])} = ?")
        params.append(value)

    sql_where = " AND ".join(conditions)

    try:
        cursor = conn.execute(
            f"SELECT rowid AS __purge_rowid__, * "
            f"FROM {qi(child_table)} WHERE {sql_where}",
            params
        )
        has_rowid = True
    except sqlite3.OperationalError:
        cursor = conn.execute(
            f"SELECT * FROM {qi(child_table)} WHERE {sql_where}",
            params
        )
        has_rowid = False

    names = [d[0] for d in cursor.description]
    result = []

    for values in cursor.fetchall():
        record = dict(zip(names, values))
        pk = get_primary_key(conn, child_table)

        if pk:
            identity = ("pk", tuple(record[c] for c in pk))
        elif has_rowid:
            identity = ("rowid", record["__purge_rowid__"])
        else:
            raise RuntimeError(
                f"Cannot identify rows in {child_table}"
            )

        result.append((identity, record))

    return result


def discover_dependencies(conn, root_table, root_record):
    reverse = defaultdict(list)

    for child in get_tables(conn):
        for group in foreign_key_groups(conn, child):
            reverse[group[0]["parent"]].append((child, group))

    root_key = (
        root_table, identity_for(conn, root_table, root_record)
    )

    selected = {root_key: root_record}
    queue = deque([(root_table, root_record)])

    while queue:
        parent_table, parent_record = queue.popleft()

        for child_table, group in reverse.get(parent_table, []):
            for identity, record in matching_children(
                conn, child_table, group, parent_record
            ):
                key = (child_table, identity)

                if key not in selected:
                    selected[key] = record
                    queue.append((child_table, record))

    return selected


def calculate_delete_order(conn, selected):
    """
    Build child -> parent edges. Children must be deleted first.
    """
    nodes = list(selected.keys())
    node_set = set(nodes)
    outgoing = defaultdict(set)
    indegree = {node: 0 for node in nodes}
    lookup = defaultdict(list)

    for node in nodes:
        table, _ = node
        record = selected[node]

        for column in get_columns(conn, table):
            value = record.get(column)

            if value is not None:
                lookup[(table, column, value)].append(node)

    for child_node in nodes:
        child_table, _ = child_node
        child_record = selected[child_node]

        for group in foreign_key_groups(conn, child_table):
            parent_table = group[0]["parent"]
            candidates = None

            for fk in group:
                value = child_record.get(fk["child_column"])

                if value is None:
                    candidates = set()
                    break

                column = parent_column(conn, parent_table, fk)
                found = set(
                    lookup.get((parent_table, column, value), [])
                )

                candidates = found if candidates is None else candidates & found

            for parent_node in candidates or ():
                if parent_node not in node_set or parent_node == child_node:
                    continue

                if parent_node not in outgoing[child_node]:
                    outgoing[child_node].add(parent_node)
                    indegree[parent_node] += 1

    queue = deque(node for node in nodes if indegree[node] == 0)
    ordered = []

    while queue:
        node = queue.popleft()
        ordered.append(node)

        for parent in outgoing[node]:
            indegree[parent] -= 1
            if indegree[parent] == 0:
                queue.append(parent)

    if len(ordered) != len(nodes):
        cyclic = [node for node in nodes if indegree[node] > 0]
        raise RuntimeError(
            "Circular foreign-key dependencies found. "
            f"Example rows: {cyclic[:10]}"
        )

    return ordered


def delete_rows(conn, selected, ordered):
    deleted = defaultdict(int)

    for table, identity in ordered:
        record = selected[(table, identity)]
        pk = get_primary_key(conn, table)

        if pk:
            where = " AND ".join(f"{qi(c)} = ?" for c in pk)
            params = [record[c] for c in pk]
        else:
            if "__purge_rowid__" not in record:
                raise RuntimeError(
                    f"Cannot safely delete a row in {table}"
                )
            where = "rowid = ?"
            params = [record["__purge_rowid__"]]

        try:
            cursor = conn.execute(
                f"DELETE FROM {qi(table)} WHERE {where}",
                params
            )
        except sqlite3.IntegrityError as exc:
            raise RuntimeError(
                f"Delete failed in table {table}, "
                f"identity={identity}: {exc}"
            ) from exc

        if cursor.rowcount != 1:
            raise RuntimeError(
                f"Expected one deleted row in {table}; "
                f"got {cursor.rowcount}"
            )

        deleted[table] += 1

    return deleted


def show_foreign_key_diagnostics(conn):
    try:
        violations = conn.execute(
            "PRAGMA foreign_key_check"
        ).fetchmany(30)

        if not violations:
            print("[DIAGNOSTIC] No foreign-key violations found.")
            return

        print("\n[FOREIGN-KEY DIAGNOSTICS]")

        for table, rowid, parent, fk_id in violations:
            print(
                f"  table={table}, rowid={rowid}, "
                f"parent={parent}, fk_id={fk_id}"
            )

    except sqlite3.Error as exc:
        print(f"[DIAGNOSTIC] {exc}")


def verify_no_direct_references(conn, root_table, root_record):
    for child in get_tables(conn):
        for group in foreign_key_groups(conn, child):
            if group[0]["parent"] != root_table:
                continue

            conditions, params = [], []

            for fk in group:
                column = parent_column(conn, root_table, fk)
                conditions.append(f"{qi(fk['child_column'])} = ?")
                params.append(root_record.get(column))

            count = conn.execute(
                f"SELECT COUNT(*) FROM {qi(child)} WHERE "
                + " AND ".join(conditions),
                params
            ).fetchone()[0]

            if count:
                raise RuntimeError(
                    f"{count} records remain in {child} "
                    f"referencing {root_table}"
                )


def main():
    print("=" * 68)
    print("INSTITUTION AND RELATED RECORD PURGE")
    print("=" * 68)
    print(f"Database: {DB_PATH}\n")

    if not os.path.isfile(DB_PATH):
        raise FileNotFoundError(DB_PATH)

    requested = input(
        "Enter institution name (partial name or typo accepted): "
    ).strip()

    if len(requested) < 3:
        raise ValueError("Enter at least three characters.")

    backup_path = backup_database()
    conn = sqlite3.connect(DB_PATH, timeout=60)

    try:
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("BEGIN IMMEDIATE")

        match = find_institution(conn, requested)

        if not match:
            raise RuntimeError(
                f"No institution matched {requested!r}"
            )

        root_table = match["table"]
        root_record = match["record"]

        print("\n[MATCH]")
        print(f"  Institution: {match['name']}")
        print(f"  Table: {root_table}")
        print(f"  Match score: {match['score']:.2f}")

        selected = discover_dependencies(
            conn, root_table, root_record
        )

        summary = defaultdict(int)

        for table, _ in selected:
            summary[table] += 1

        print("\n[DEPENDENT ROWS]")

        for table, count in sorted(summary.items()):
            print(f"  {table}: {count}")

        print(f"\nTotal rows scheduled: {len(selected)}")

        ordered = calculate_delete_order(conn, selected)
        deleted = delete_rows(conn, selected, ordered)

        verify_no_direct_references(
            conn, root_table, root_record
        )

        conn.commit()

        print("\n" + "=" * 68)
        print("SUCCESS")
        print("=" * 68)
        print(f"Institution: {match['name']}")
        print(f"Rows deleted: {sum(deleted.values())}")

        for table, count in sorted(deleted.items()):
            print(f"  {table}: {count}")

        print(f"Backup retained: {backup_path}")

    except Exception as exc:
        print(f"\n[ERROR] {exc}")
        show_foreign_key_diagnostics(conn)
        conn.rollback()
        print("[ROLLBACK] Changes were not committed.")
        print(f"[BACKUP] {backup_path}")
        raise

    finally:
        conn.close()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[CANCELLED]")
        sys.exit(130)
    except Exception:
        sys.exit(1)
