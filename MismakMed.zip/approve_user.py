import sys

from app import create_app
from app.extensions import db
from app.models import User


app = create_app()


def approve_user(email):

    email = email.strip().lower()

    with app.app_context():

        user = User.query.filter(
            db.func.lower(User.email) == email
        ).first()

        if not user:
            print(f"ERROR: User not found: {email}")
            return False

        print(f"User: {user.email}")
        print(f"Current status: {user.status}")

        if str(user.status).upper() != "PENDING":
            print(
                f"ERROR: User is not pending. "
                f"Current status: {user.status}"
            )
            return False

        user.status = "APPROVED"

        db.session.commit()

        print()
        print("=" * 50)
        print("USER APPROVED SUCCESSFULLY")
        print("=" * 50)
        print(f"Email:  {user.email}")
        print(f"Status: {user.status}")
        print("=" * 50)

        return True


if __name__ == "__main__":

    if len(sys.argv) != 2:
        print("Usage:")
        print("  python approve_user.py user@example.com")
        sys.exit(1)

    email = sys.argv[1]

    try:
        success = approve_user(email)
        sys.exit(0 if success else 1)

    except Exception as e:

        db.session.rollback()

        print()
        print("ERROR:")
        print(str(e))

        sys.exit(1)