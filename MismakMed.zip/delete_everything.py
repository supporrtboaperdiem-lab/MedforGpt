import os
import shutil
import sqlite3
from datetime import datetime


DB_PATH = "/u01/Medical/instance/medical.db"


# ============================================================
# BACKUP
# ============================================================

def backup_database():
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{DB_PATH}.before_full_cleanup_{timestamp}"

    shutil.copy2(DB_PATH, backup_path)

    print("[OK] Database backup created:")
    print(f"     {backup_path}")
    print()

    return backup_path


# ============================================================
# DATABASE HELPERS
# ============================================================

def get_tables(conn):
    rows = conn.execute("""
        SELECT name
        FROM sqlite_master
        WHERE type = 'table'
          AND name NOT LIKE 'sqlite_%'
        ORDER BY name
    """).fetchall()

    return [row[0] for row in rows]


def count_rows(conn, table):
    try:
        return conn.execute(
            f'SELECT COUNT(*) FROM "{table}"'
        ).fetchone()[0]
    except sqlite3.Error:
        return 0


def get_columns(conn, table):
    try:
        rows = conn.execute(
            f'PRAGMA table_info("{table}")'
        ).fetchall()

        return {
            str(row[1]).lower()
            for row in rows
        }

    except sqlite3.Error:
        return set()


def get_foreign_keys(conn, table):
    try:
        return conn.execute(
            f'PRAGMA foreign_key_list("{table}")'
        ).fetchall()

    except sqlite3.Error:
        return []


# ============================================================
# IDENTIFY TARGET TABLES
# ============================================================

def find_related_tables(conn, keywords, id_columns):
    """
    Find tables belonging to a particular dataset.

    Detection is based on:

      1. Table name containing a keyword
      2. Column names containing known ID fields
      3. Foreign keys pointing to a table whose name
         contains one of the keywords
    """

    tables = get_tables(conn)

    related = set()

    # --------------------------------------------------------
    # Pass 1:
    # Table names and columns
    # --------------------------------------------------------

    for table in tables:

        lower_table = table.lower()

        # Table name
        if any(keyword in lower_table for keyword in keywords):
            related.add(table)

        # Columns
        columns = get_columns(conn, table)

        if columns.intersection(
            {column.lower() for column in id_columns}
        ):
            related.add(table)

    # --------------------------------------------------------
    # Pass 2:
    # Foreign-key relationships
    # --------------------------------------------------------

    changed = True

    while changed:

        changed = False

        for table in tables:

            try:
                fks = get_foreign_keys(conn, table)

                for fk in fks:

                    referenced_table = str(fk[2])
                    referenced_lower = referenced_table.lower()

                    # If this table points to an already identified
                    # target table, it is a dependent table.
                    if referenced_table in related:

                        if table not in related:
                            related.add(table)
                            changed = True

                    # Also detect direct keyword matches.
                    elif any(
                        keyword in referenced_lower
                        for keyword in keywords
                    ):

                        if table not in related:
                            related.add(table)
                            changed = True

            except sqlite3.Error:
                pass

    return sorted(related)


# ============================================================
# DISCOVER ALL TARGETS
# ============================================================

def discover_targets(conn):

    claim_keywords = [
        "claim"
    ]

    claim_ids = [
        "claim_id",
        "medical_claim_id"
    ]

    price_keywords = [
        "price",
        "pricelist",
        "price_list"
    ]

    price_ids = [
        "price_list_id",
        "pricelist_id",
        "price_id",
        "price_list_item_id"
    ]

    institution_keywords = [
        "institution"
    ]

    institution_ids = [
        "institution_id"
    ]

    claims = find_related_tables(
        conn,
        claim_keywords,
        claim_ids
    )

    price_lists = find_related_tables(
        conn,
        price_keywords,
        price_ids
    )

    institutions = find_related_tables(
        conn,
        institution_keywords,
        institution_ids
    )

    return {
        "claims": claims,
        "price_lists": price_lists,
        "institutions": institutions
    }


# ============================================================
# SHOW DISCOVERY
# ============================================================

def print_discovered(conn, targets):

    print("=" * 80)
    print("DISCOVERED DATA TO PURGE")
    print("=" * 80)

    total = 0

    for category, tables in targets.items():

        print()
        print(category.upper())
        print("-" * 80)

        if not tables:
            print("  No tables discovered.")
            continue

        for table in tables:

            rows = count_rows(conn, table)
            total += rows

            print(
                f"  {table:<55} "
                f"{rows:>10} rows"
            )

    print()
    print("-" * 80)
    print(f"Total rows across discovered tables: {total}")
    print("=" * 80)
    print()


# ============================================================
# DETERMINE SAFE DELETE ORDER
# ============================================================

def calculate_delete_order(conn, tables):
    """
    Child tables must be deleted before parent tables.

    We repeatedly place tables that reference another target
    table before the referenced table.
    """

    tables = list(dict.fromkeys(tables))

    dependencies = {
        table: set()
        for table in tables
    }

    table_set = set(tables)

    for table in tables:

        for fk in get_foreign_keys(conn, table):

            referenced = str(fk[2])

            if referenced in table_set and referenced != table:
                dependencies[table].add(referenced)

    ordered = []

    remaining = set(tables)

    while remaining:

        progress = False

        for table in list(remaining):

            # Delete table when all tables it depends on
            # are either already scheduled after it.
            unresolved = dependencies[table].intersection(remaining)

            if not unresolved:

                ordered.append(table)
                remaining.remove(table)
                progress = True

        if not progress:
            # Circular dependency.
            # In this case foreign_keys are already disabled,
            # so we can safely continue.
            ordered.extend(sorted(remaining))
            break

    return ordered


# ============================================================
# RESET AUTOINCREMENT
# ============================================================

def reset_sequences(conn, tables):

    try:

        for table in tables:

            conn.execute(
                "DELETE FROM sqlite_sequence WHERE name = ?",
                (table,)
            )

    except sqlite3.Error:

        # sqlite_sequence does not exist if the database has
        # no AUTOINCREMENT tables.
        pass


# ============================================================
# MAIN CLEANUP
# ============================================================

def clean_database():

    if not os.path.isfile(DB_PATH):
        raise FileNotFoundError(
            f"Database not found: {DB_PATH}"
        )

    print("=" * 80)
    print("MEDICAL REIMBURSEMENT DATABASE - FULL DATA CLEANUP")
    print("=" * 80)
    print()
    print(f"Database:")
    print(f"  {DB_PATH}")
    print()

    # --------------------------------------------------------
    # BACKUP
    # --------------------------------------------------------

    backup_path = backup_database()

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row

    try:

        # ----------------------------------------------------
        # Disable FK enforcement during controlled cleanup.
        # ----------------------------------------------------

        conn.execute("PRAGMA foreign_keys = OFF")

        # ----------------------------------------------------
        # Discover targets
        # ----------------------------------------------------

        targets = discover_targets(conn)

        print_discovered(conn, targets)

        # ----------------------------------------------------
        # Combine all tables
        # ----------------------------------------------------

        all_tables = []

        for tables in targets.values():

            for table in tables:

                if table not in all_tables:
                    all_tables.append(table)

        if not all_tables:

            print("[INFO] No matching tables were discovered.")
            print()
            print(f"Backup kept at:")
            print(f"  {backup_path}")
            return

        # ----------------------------------------------------
        # Confirmation
        # ----------------------------------------------------

        confirmation = input(
            "TYPE DELETE CLAIMS PRICE LISTS INSTITUTIONS TO CONTINUE: "
        ).strip()

        if confirmation != "DELETE CLAIMS PRICE LISTS INSTITUTIONS":

            print()
            print("[CANCELLED] Nothing was deleted.")
            print()
            print(f"Backup kept at:")
            print(f"  {backup_path}")

            return

        # ----------------------------------------------------
        # Calculate child -> parent order
        # ----------------------------------------------------

        ordered = calculate_delete_order(
            conn,
            all_tables
        )

        print()
        print("[INFO] Delete order:")
        print("-" * 80)

        for index, table in enumerate(ordered, start=1):

            print(
                f"{index:>3}. "
                f"{table:<55} "
                f"{count_rows(conn, table):>10} rows"
            )

        print()

        # ----------------------------------------------------
        # Delete
        # ----------------------------------------------------

        print("[INFO] Starting cleanup...")
        print()

        deleted = {}

        for table in ordered:

            before = count_rows(conn, table)

            if before == 0:

                deleted[table] = 0

                print(
                    f"[EMPTY]   {table:<55} "
                    f"{0:>10} rows"
                )

                continue

            conn.execute(
                f'DELETE FROM "{table}"'
            )

            deleted[table] = before

            print(
                f"[DELETED] {table:<55} "
                f"{before:>10} rows"
            )

        # ----------------------------------------------------
        # Reset AUTOINCREMENT
        # ----------------------------------------------------

        reset_sequences(
            conn,
            ordered
        )

        # ----------------------------------------------------
        # Commit
        # ----------------------------------------------------

        conn.commit()

        # ----------------------------------------------------
        # Verification
        # ----------------------------------------------------

        print()
        print("=" * 80)
        print("VERIFICATION")
        print("=" * 80)

        remaining = False

        for table in ordered:

            rows = count_rows(conn, table)

            print(
                f"{table:<55} "
                f"{rows:>10} remaining"
            )

            if rows > 0:
                remaining = True

        print()
        print("=" * 80)

        if remaining:

            print(
                "[WARNING] Some targeted records remain."
            )

        else:

            print(
                "[SUCCESS] All discovered claims, price-list "
                "and institution records were removed."
            )

        print("=" * 80)

        print()
        print("IMPORTANT:")
        print("Unrelated tables were not intentionally modified.")
        print()
        print("Backup kept at:")
        print(f"  {backup_path}")
        print()

    except Exception:

        conn.rollback()

        print()
        print("[ERROR] Cleanup failed.")
        print("[INFO] Transaction was rolled back.")
        print()
        print(f"Backup available at:")
        print(f"  {backup_path}")

        raise

    finally:

        conn.close()


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    clean_database()