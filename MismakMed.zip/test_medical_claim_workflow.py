from pathlib import Path

service = Path('app/services/claim_service.py').read_text()
routes = Path('app/routes/claim.py').read_text()
index = Path('app/templates/claim/index.html').read_text()
view = Path('app/templates/claim/view.html').read_text()

assert 'ClaimService.OPTICS' in service
assert 'ClaimService.PHARMACY' in service
assert 'AuthorizationService.is_medical_officer(current_user)' in routes
assert 'def view(claim_id)' in routes
assert "url_for('claim.view', claim_id=claim.id)" in index
assert 'Uploaded Receipt' in view
assert 'Approve claim' not in view
assert 'Reject claim' not in view
print('Medical claim workflow checks passed.')


assert 'multiple' in Path('app/templates/claim/submit.html').read_text()
assert 'receipt_files' in Path('app/routes/claim.py').read_text()
assert 'MedicalClaimReceipt' in Path('app/models/claim.py').read_text()
assert 'medical_claim_receipts' in Path('migrations/versions/7c4f1b2a9d11_add_multiple_medical_claim_receipts.py').read_text()
assert 'Uploaded Receipts' in Path('app/templates/claim/review.html').read_text()
print('Multiple receipt workflow checks passed.')
