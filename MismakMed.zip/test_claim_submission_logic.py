import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def test_claim_service_has_price_list_gate():
    source = (ROOT / "app/services/claim_service.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    text = source
    assert "can_submit_normal_claim" in text
    assert "get_active_batch(institution_id)" in text
    assert "AuthorizationService.is_hr(current_user)" in text
    assert "AuthorizationService.is_medical_officer(current_user)" in text

def test_dashboard_exposes_submission_flag():
    source = (ROOT / "app/routes/main.py").read_text(encoding="utf-8")
    assert "can_submit_normal_claim" in source

def test_medical_officer_dashboard_has_submit_action():
    source = (ROOT / "app/templates/main/index.html").read_text(encoding="utf-8")
    marker = "MEDICAL OFFICER DASHBOARD"
    section = source.split(marker, 1)[1]
    assert "Submit Normal Claim" in section

def test_normal_matching_rejects_specific_variant_cross_match():
    source = (ROOT / "app/services/claim_service.py").read_text(encoding="utf-8")
    assert "SERVICE_VARIANT_PATTERNS" in source
    assert '"sub_consultation"' in source
    assert "_service_variant_compatible" in source
    assert "best_score < cls.SERVICE_MATCH_THRESHOLD" in source
    # Automatic mode must no longer return an arbitrary lowest-quality row.
    assert "return best_row, best_score" in source


def test_receipt_service_name_keeps_code_and_price_separate():
    source = (ROOT / "app/services/ollama_claim_extraction_service.py").read_text(encoding="utf-8")
    assert '"service_code": null' in source
    assert "service_name` MUST contain only the medical service/procedure/product name" in source
    assert "Do NOT append quantity, unit price, line total" in source
