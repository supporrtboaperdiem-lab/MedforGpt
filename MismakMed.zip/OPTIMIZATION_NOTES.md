# Medical claim optimization

This archive preserves the original project tree and files. The following targeted changes were made:

- Receipt extraction concurrency defaults to 8 (configurable with `OLLAMA_MAX_CONCURRENT_REQUESTS`).
- AI HTTP connections are reused per worker thread instead of opening a fresh connection for every receipt.
- Multimodal prompt was compacted while preserving the full structured extraction contract.
- Receipt images are capped at 1800px and JPEG quality 88 to reduce vision-token/network overhead without changing the source file.
- AI output is bounded to 768 tokens by default (`OLLAMA_MAX_OUTPUT_TOKENS`) to reduce wasted generation/context pressure.
- The date fallback probe is limited to two focused image variants instead of four.
- Service matching is identity-first. Receipt price can only break a genuinely near-equal service tie; a clearly better service cannot lose to a cheaper price-list row.
- The unresolved-match confirmation page now exposes competing price-list candidates and their approved prices/scores.
- Claim review explicitly lists each deducted reimbursable item under the affected employee, in addition to employee-level totals.
- Duplicate blocking now follows the requested 99% visual rule: exact file hashes are still hard 100% duplicates, while pHash blocking requires >=99% similarity (zero Hamming distance for a 64-bit pHash) plus receipt identity evidence. Metadata fingerprint alone no longer blocks a receipt.
- The Kaggle notebook is included as `olama_optimized.ipynb`: llama.cpp uses `-c 16384`, `--parallel 8`, and `--n-predict 768`.

The included source tests pass. Actual GPU throughput must still be measured on the two-T4 Kaggle runtime because the development environment here does not contain the production Flask/GPU stack.
